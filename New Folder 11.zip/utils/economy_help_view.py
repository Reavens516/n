import discord

class EconomyHelpView(discord.ui.View):
    def __init__(self, ctx, current_prefix, main_embed):
        super().__init__(timeout=300)
        self.ctx = ctx
        self.current_prefix = current_prefix
        self.main_embed = main_embed
        self.add_item(EconomyHelpDropdown(ctx, current_prefix, main_embed))

class EconomyHelpDropdown(discord.ui.Select):
    def __init__(self, ctx, current_prefix, main_embed):
        self.ctx = ctx
        self.current_prefix = current_prefix
        self.main_embed = main_embed

        options = [
            discord.SelectOption(
                label="💰 Currency Commands",
                value="currency",
                description="Check balance, give money, leaderboards",
                emoji="💰"
            ),
            discord.SelectOption(
                label="💼 Earning Commands", 
                value="earning",
                description="Work, beg, daily rewards, trivia",
                emoji="💼"
            ),
            discord.SelectOption(
                label="🎰 Gambling Commands",
                value="gambling", 
                description="Slots, coinflip, blackjack games",
                emoji="🎰"
            ),
            discord.SelectOption(
                label="🛒 Shop & Items",
                value="shop",
                description="Buy rings, manage inventory",
                emoji="🛒"
            ),
            discord.SelectOption(
                label="🏦 Banking & Finance",
                value="banking",
                description="Bank deposits, withdrawals, interest",
                emoji="🏦"
            ),
            discord.SelectOption(
                label="💼 Job System",
                value="jobs",
                description="Apply for jobs, work, study",
                emoji="👔"
            ),
            discord.SelectOption(
                label="📈 Stock Market",
                value="stocks",
                description="Buy/sell stocks, portfolios, charts",
                emoji="📈"
            ),
            discord.SelectOption(
                label="💰 Cryptocurrency",
                value="crypto",
                description="Trade crypto, view charts",
                emoji="💰"
            ),
            discord.SelectOption(
                label="🦁 Zoo System",
                value="zoo",
                description="Hunt animals, manage zoo",
                emoji="🦁"
            ),
            discord.SelectOption(
                label="💕 Social Commands",
                value="social",
                description="Marriage, pray, curse, cookies",
                emoji="💕"
            ),
            discord.SelectOption(
                label="😊 Roleplay & Actions",
                value="roleplay",
                description="Hug, kiss, dance, emotes",
                emoji="😊"
            ),
            discord.SelectOption(
                label="⚙️ Utility Commands",
                value="utility",
                description="Avatar, emoji, sysify, prefix",
                emoji="⚙️"
            ),
            discord.SelectOption(
                label="🏠 Main Menu",
                value="main",
                description="Return to main help menu",
                emoji="🏠"
            )
        ]

        super().__init__(
            placeholder="Choose a category to explore...",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            await interaction.response.send_message("Only the command user can use this dropdown!", ephemeral=True)
            return

        category = self.values[0]

        if category == "main":
            await interaction.response.edit_message(embed=self.main_embed, view=EconomyHelpView(self.ctx, self.current_prefix, self.main_embed))
            return

        embed = discord.Embed(color=0x000000)

        if category == "currency":
            embed.title = "💰 Currency Commands"
            embed.description = "Manage your cowoncy and check balances"
            embed.add_field(
                name="Commands",
                value=f"`{self.current_prefix} cash [user]` - Check cowoncy balance\n"
                      f"`{self.current_prefix} give <amount> <user>` - Give cowoncy to another user\n"
                      f"`{self.current_prefix} baltop` - View server wealth leaderboard\n"
                      f"`{self.current_prefix} cookie [user]` - Give or check cookies",
                inline=False
            )

        elif category == "earning":
            embed.title = "💼 Earning Commands"
            embed.description = "Various ways to earn cowoncy"
            embed.add_field(
                name="Commands",
                value=f"`{self.current_prefix} work` - Work jobs for cowoncy (1h cooldown)\n"
                      f"`{self.current_prefix} beg` - Beg for cowoncy (30min cooldown)\n"
                      f"`{self.current_prefix} daily` - Daily reward with streaks\n"
                      f"`{self.current_prefix} trivia` - Answer questions for rewards\n"
                      f"`{self.current_prefix} lottery` - Buy lottery tickets",
                inline=False
            )

        elif category == "gambling":
            embed.title = "🎰 Gambling Commands"
            embed.description = "Test your luck with gambling games"
            embed.add_field(
                name="Commands",
                value=f"`{self.current_prefix} slots <amount>` - Play slot machine\n"
                      f"`{self.current_prefix} coinflip <amount> [choice]` - Flip a coin\n"
                      f"`{self.current_prefix} blackjack <amount>` - Play blackjack\n\n"
                      f"**Aliases:** `slots` → `s` | `coinflip` → `cf` | `blackjack` → `bj`",
                inline=False
            )

        elif category == "shop":
            embed.title = "🛒 Shop & Items"
            embed.description = "Purchase items and manage your inventory"
            embed.add_field(
                name="Commands",
                value=f"`{self.current_prefix} shop` - View the ring shop\n"
                      f"`{self.current_prefix} buy <id>` - Buy a ring from shop\n"
                      f"`{self.current_prefix} sell <id>` - Sell a ring for 75% price\n"
                      f"`{self.current_prefix} inventory [user]` - Check inventory\n"
                      f"`{self.current_prefix} marry <user> <ring_id>` - Propose to someone",
                inline=False
            )

        elif category == "banking":
            embed.title = "🏦 Banking & Finance"
            embed.description = "Secure banking with interest earnings"
            embed.add_field(
                name="Commands",
                value=f"`{self.current_prefix} bank` - View bank account info\n"
                      f"`{self.current_prefix} bank deposit <amount>` - Store cowoncy safely\n"
                      f"`{self.current_prefix} bank withdraw <amount>` - Take out cowoncy\n"
                      f"`{self.current_prefix} bank all` - Deposit all wallet cowoncy",
                inline=False
            )
            embed.add_field(
                name="Interest Rate",
                value="**2% daily** on deposited amounts",
                inline=False
            )

        elif category == "jobs":
            embed.title = "💼 Job System"
            embed.description = "Build your career and earn steady income"
            embed.add_field(
                name="Commands",
                value=f"`{self.current_prefix} job` - View job center and career info\n"
                      f"`{self.current_prefix} job list` - View all available jobs\n"
                      f"`{self.current_prefix} job apply <job>` - Apply for a job\n"
                      f"`{self.current_prefix} job work` - Work your current job (2h cooldown)\n"
                      f"`{self.current_prefix} job quit` - Quit your current job\n"
                      f"`{self.current_prefix} job study` - Study to increase education (6h cooldown)",
                inline=False
            )
            embed.add_field(
                name="Available Jobs",
                value="📋 Intern → 💰 Cashier → 💻 Programmer → 👔 Manager → 👩‍⚕️ Doctor → 🎩 CEO",
                inline=False
            )

        elif category == "stocks":
            embed.title = "📈 Stock Market"
            embed.description = "Invest in the stock market for profit"
            embed.add_field(
                name="Commands",
                value=f"`{self.current_prefix} stocks` - View market and portfolio\n"
                      f"`{self.current_prefix} stocks buy <symbol> <amount>` - Buy stocks\n"
                      f"`{self.current_prefix} stocks sell <symbol> <amount>` - Sell stocks\n"
                      f"`{self.current_prefix} stocks graph <symbol>` - View price chart\n"
                      f"`{self.current_prefix} stocks info <symbol>` - Company information\n"
                      f"`{self.current_prefix} stocks portfolio` - Detailed portfolio view\n"
                      f"`{self.current_prefix} stocks leaderboard` - Top investors\n"
                      f"`{self.current_prefix} stocks watchlist` - Track favorite stocks",
                inline=False
            )
            embed.add_field(
                name="Available Stocks",
                value="💻 TECH | 🍔 FOOD | 🚗 AUTO | 🏦 BANK | 🏥 MEDI | 🎮 GAME",
                inline=False
            )

        elif category == "crypto":
            embed.title = "₿ Cryptocurrency"
            embed.description = "Trade cryptocurrencies with live market data"
            embed.add_field(
                name="Commands",
                value=f"`{self.current_prefix} crypto` - View crypto market overview\n"
                      f"`{self.current_prefix} crypto buy <symbol> <amount>` - Buy cryptocurrency\n"
                      f"`{self.current_prefix} crypto sell <symbol> <amount>` - Sell cryptocurrency\n"
                      f"`{self.current_prefix} crypto chart <symbol>` - View price charts",
                inline=False
            )
            embed.add_field(
                name="Available Cryptocurrencies",
                value="₿ BTC | ⟠ ETH | 🔷 ADA | 🐕 DOGE | ◎ SOL | ⚫ DOT",
                inline=False
            )

        elif category == "zoo":
            embed.title = "🦁 Zoo System"
            embed.description = "Hunt and collect animals for your zoo"
            embed.add_field(
                name="Commands",
                value=f"`{self.current_prefix} zoo [user]` - View your zoo collection\n"
                      f"`{self.current_prefix} hunt` - Hunt for animals (15min cooldown)\n"
                      f"`{self.current_prefix} sell <animal>` - Sell animals for cowoncy\n"
                      f"`{self.current_prefix} sell all` - Sell all animals",
                inline=False
            )
            embed.add_field(
                name="Animal Rarities",
                value="🟢 Common → 🔵 Uncommon → 🟣 Rare → 🟠 Epic → 🔴 Mythic",
                inline=False
            )

        elif category == "social":
            embed.title = "💕 Social Commands"
            embed.description = "Interact with other users and build relationships"
            embed.add_field(
                name="Commands",
                value=f"`{self.current_prefix} marry <user> <ring_id>` - Propose to someone\n"
                      f"`{self.current_prefix} pray [user]` - Pray for luck points\n"
                      f"`{self.current_prefix} curse <user>` - Curse someone to steal luck\n"
                      f"`{self.current_prefix} cookie [user]` - Give or check cookies",
                inline=False
            )

        elif category == "roleplay":
            embed.title = "😊 Roleplay & Actions"
            embed.description = "Express yourself with animated actions"
            embed.add_field(
                name="Emotes",
                value=f"`{self.current_prefix} blush` | `{self.current_prefix} smile` | `{self.current_prefix} dance` | `{self.current_prefix} cry`\n"
                      f"`{self.current_prefix} laugh` | `{self.current_prefix} pout` | `{self.current_prefix} wink` | `{self.current_prefix} happy`",
                inline=False
            )
            embed.add_field(
                name="Actions (with user)",
                value=f"`{self.current_prefix} hug [user]` | `{self.current_prefix} kiss [user]` | `{self.current_prefix} pat [user]`\n"
                      f"`{self.current_prefix} cuddle [user]` | `{self.current_prefix} slap [user]` | `{self.current_prefix} poke [user]`\n"
                      f"`{self.current_prefix} tickle [user]` | `{self.current_prefix} wave [user]` | `{self.current_prefix} boop [user]`",
                inline=False
            )

        elif category == "utility":
            embed.title = "⚙️ Utility Commands"
            embed.description = "Helpful utility and customization commands"
            embed.add_field(
                name="Commands",
                value=f"`{self.current_prefix} emoji <emoji>` - Enlarge and show emoji info\n"
                      f"`{self.current_prefix} sysify <text>` - Transform text into cute SyS style\n"
                      f"`{self.current_prefix} avatar [user]` - Show user's avatar in high quality\n"
                      f"`{self.current_prefix} prefix <new_prefix>` - Change economy prefix (Admin only)",
                inline=False
            )

        embed.set_author(
            name=f"{self.ctx.author.display_name}'s Economy Help",
            icon_url=self.ctx.author.display_avatar.url
        )

        embed.set_footer(
            text=f"Current prefix: {self.current_prefix} | Use dropdown to explore other categories",
            icon_url=self.ctx.bot.user.display_avatar.url
        )

        await interaction.response.edit_message(embed=embed, view=EconomyHelpView(self.ctx, self.current_prefix, self.main_embed))
"""
@Author: ! Aegis !
    + Discord: Aegis
    + Community: https://discord.gg/35FqchfVZG (Strelix Studios™)
    + for any queries reach out Community or DM me.
"""
