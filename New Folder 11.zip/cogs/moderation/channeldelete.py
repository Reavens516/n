import discord
from discord.ext import commands
from discord.ui import Button, View
from utils.Tools import *
from core import Cog, Context

class ChannelDelete(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.color = 0x000000

    @commands.hybrid_command(name="channel_delete", 
                           aliases=["del_channel", "delete_channel"],
                           help="Deletes a channel after confirmation",
                           usage="channel_delete [channel]")
    @blacklist_check()
    @ignore_check()
    @commands.has_permissions(manage_channels=True)
    @commands.bot_has_permissions(manage_channels=True)
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def channeldelete(self, ctx: Context, channel: discord.TextChannel = None):
        if channel is None:
            channel = ctx.channel

        # Check if bot has permission to delete the channel
        if not ctx.guild.me.guild_permissions.manage_channels:
            error = discord.Embed(
                color=self.color,
                description="I don't have permission to manage channels!"
            )
            error.set_author(name="Error", icon_url="https://i.ibb.co/TxtQNnyH/2400e46b-9674-4142-b2dc-73244e769c3b.png")
            error.set_footer(text=f"Requested by {ctx.author}",
                            icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
            return await ctx.send(embed=error)

        button = Button(label="Confirm Delete",
                       style=discord.ButtonStyle.danger,
                       emoji="🗑️")
        button1 = Button(label="Cancel",
                        style=discord.ButtonStyle.secondary,
                        emoji="<:icon_cross:1372375094336425986>")

        async def button_callback(interaction: discord.Interaction):
            if interaction.user == ctx.author:
                try:
                    channel_name = channel.name
                    await channel.delete(reason=f"Channel deleted by {ctx.author} (ID: {ctx.author.id})")

                    # If the deleted channel was the current channel, send confirmation elsewhere
                    if channel == ctx.channel:
                        # Try to send to a general channel or the first available text channel
                        target_channel = discord.utils.get(ctx.guild.text_channels, name="general")
                        if not target_channel:
                            target_channel = ctx.guild.text_channels[0] if ctx.guild.text_channels else None

                        if target_channel:
                            success = discord.Embed(
                                color=self.color,
                                description=f"Successfully deleted channel **#{channel_name}**."
                            )
                            success.set_author(name="Channel Deleted", icon_url="https://i.ibb.co/TxtQNnyH/2400e46b-9674-4142-b2dc-73244e769c3b.png")
                            success.set_footer(text=f"Requested by {ctx.author}",
                                             icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
                            await target_channel.send(embed=success)
                    else:
                        success = discord.Embed(
                            color=self.color,
                            description=f"Successfully deleted channel **#{channel_name}**."
                        )
                        success.set_author(name="Channel Deleted", icon_url="https://i.ibb.co/TxtQNnyH/2400e46b-9674-4142-b2dc-73244e769c3b.png")
                        success.set_footer(text=f"Requested by {ctx.author}",
                                         icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)
                        await interaction.response.edit_message(embed=success, view=None)

                except discord.Forbidden:
                    error = discord.Embed(
                        color=self.color,
                        description="I don't have permission to delete this channel!"
                    )
                    error.set_author(name="Error", icon_url="https://i.ibb.co/TxtQNnyH/2400e46b-9674-4142-b2dc-73244e769c3b.png")
                    await interaction.response.edit_message(embed=error, view=None)
                except Exception as e:
                    error = discord.Embed(
                        color=self.color,
                        description=f"An error occurred while trying to delete the channel: {str(e)}"
                    )
                    error.set_author(name="Error", icon_url="https://i.ibb.co/TxtQNnyH/2400e46b-9674-4142-b2dc-73244e769c3b.png")
                    await interaction.response.edit_message(embed=error, view=None)
            else:
                await interaction.response.send_message("Oops! It looks like that message isn't from you. You need to run the command yourself to interact with it.",
                                                       embed=None,
                                                       view=None,
                                                       ephemeral=True)

        async def button1_callback(interaction: discord.Interaction):
            if interaction.user == ctx.author:
                embed2 = discord.Embed(
                    color=self.color,
                    description="Cancelled, I won't delete the channel."
                )
                embed2.set_author(name="Cancelled", icon_url="https://i.ibb.co/TxtQNnyH/2400e46b-9674-4142-b2dc-73244e769c3b.png")
                await interaction.response.edit_message(embed=embed2, view=None)
            else:
                await interaction.response.send_message("Oops! It looks like that message isn't from you. You need to run the command yourself to interact with it.",
                                                       embed=None,
                                                       view=None,
                                                       ephemeral=True)

        embed = discord.Embed(
            color=self.color,
            description=f'**Are you sure you want to delete {channel.mention}?**\n\n<:icon_danger:1372375135604047902> This action cannot be undone!'
        )
        embed.set_author(name="Confirm Channel Deletion", icon_url="https://i.ibb.co/TxtQNnyH/2400e46b-9674-4142-b2dc-73244e769c3b.png")
        embed.set_footer(text="Please click either 'Confirm Delete' or 'Cancel' to proceed. You have 30 seconds to decide!")

        view = View(timeout=30)
        button.callback = button_callback
        button1.callback = button1_callback
        view.add_item(button)
        view.add_item(button1)

        await ctx.reply(embed=embed, view=view, mention_author=False, delete_after=30)
"""
@Author: ! Aegis !
    + Discord: Aegis
    + Community: https://discord.gg/35FqchfVZG (Strelix Studios™)
    + for any queries reach out Community or DM me.
"""
