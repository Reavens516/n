import discord
from discord.ext import commands, tasks
import asyncio

class StatusCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.channel_id = 1388747532313825360
        self.message_id = None # Will store message ID after first send
        self.status_task.start()

    def cog_unload(self):
        self.status_task.cancel()

    @tasks.loop(seconds=30)
    async def status_task(self):
        channel = self.bot.get_channel(self.channel_id)
        if not channel:
            return

        uptime = discord.utils.utcnow() - self.bot.launch_time
        uptime_str = str(uptime).split('.')[0]  # Remove microseconds

        embed = discord.Embed(title="Zyron Live Stats", color=0x2f3136)  # Default gray color

        # By default embed red & offline if bot not ready
        if not self.bot.is_ready():
            embed.color = 0xff0000  # Red
            embed.description = "**Status:** <a:online:1400493658289213631> Offline / Starting..."
        else:
            embed.color = 0x00ff00  # Green
            embed.description = "**Status:** <a:online:1400493658289213631>  Online"

            # Add stats only if online
            embed.add_field(name="Uptime <:uptime:1400501831561379932> ", value=uptime_str, inline=False)
            embed.add_field(name="Ping <a:ping:1400500254268199023>", value=f"{round(self.bot.latency * 1000)} ms", inline=False)
            embed.add_field(name="Guilds <:Guilds:1400501599520166049>", value=str(len(self.bot.guilds)), inline=False)
            embed.add_field(name="Users <:users:1400501124263579709>", value=str(len(self.bot.users)), inline=False)
            embed.add_field(name="Commands <:Commands:1400501395798622218>", value=str(len(self.bot.commands)), inline=False)  
            embed.add_field(name="Invite Link <:invite:1378788896967491666>", value="[Click Here](https://discord.com/oauth2/authorize?client_id=1387495824195321938&permissions=0&integration_type=0&scope=bot+applications.commands)", inline=False)
            embed.add_field(name="Website <:website:1400500771958821125>", value="[Visit zyron](https://zyron.dpdns.orh)", inline=False)
            

        embed.set_footer(text="By Zyron Team")
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.set_image(url="https://cdn.discordapp.com/banners/1387495824195321938/4bccea1970da66bef38f047bb1f6eeb0.png?size=512")

        # Send or edit message
        if self.message_id is None:
            msg = await channel.send(embed=embed)
            self.message_id = msg.id
        else:
            try:
                msg = await channel.fetch_message(self.message_id)
                await msg.edit(embed=embed)
            except discord.NotFound:
                # Message deleted, send new one
                msg = await channel.send(embed=embed)
                self.message_id = msg.id

    @status_task.before_loop
    async def before_status(self):
        await self.bot.wait_until_ready()

async def setup(bot):
    # Store bot launch time for uptime calc
    bot.launch_time = discord.utils.utcnow()
    await bot.add_cog(StatusCog(bot))
