
import discord
import logging
import asyncio
import traceback
from discord.ext import commands
from utils.Tools import get_ignore_data
from core import Strelizia, Cog, Context

# Global flag to suppress other error handlers
_error_handled = set()

# Configure logging
logger = logging.getLogger(__name__)
if not logger.handlers:
    handler = logging.FileHandler('bot_errors.log')
    handler.setLevel(logging.ERROR)
    formatter = logging.Formatter('%(asctime)s %(levelname)s:%(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.ERROR)

# Disable Discord.py's command error logging for CheckFailure
discord_logger = logging.getLogger('discord')
class CheckFailureFilter(logging.Filter):
    def filter(self, record):
        message = record.getMessage().lower()
        
        # Allow embed-related messages to pass through
        if any(embed_phrase in message for embed_phrase in [
            'embed',
            'discord.embed',
            'embeds',
            'embed_',
            'set_embed'
        ]):
            return True
        
        # Block specific error messages and check failure messages
        if any(phrase in message for phrase in [
            'check functions for command',
            'failed',
            'command raised an exception'
        ]):
            return False
            
        # Block messages that contain 'error' but only if they're not embed-related
        if 'error' in message and not any(embed_phrase in message for embed_phrase in [
            'embed',
            'discord.embed',
            'embeds'
        ]):
            return False
            
        return True

# Apply filter to both discord logger and its children
discord_logger.addFilter(CheckFailureFilter())
for handler in discord_logger.handlers:
    handler.addFilter(CheckFailureFilter())

# Also filter the discord.ext.commands logger specifically
commands_logger = logging.getLogger('discord.ext.commands')
commands_logger.addFilter(CheckFailureFilter())
for handler in commands_logger.handlers:
    handler.addFilter(CheckFailureFilter())

class Errors(Cog):
    def __init__(self, client: Strelizia):
        self.client = client
        self._error_cache = set()
        self._processing_errors = set()
        self._sent_errors = set()  # Track errors that already sent a user message

    @commands.Cog.listener()
    async def on_error(self, event, *args, **kwargs):
        """Handle general bot errors"""
        logger.error(f"Error in event {event}: {traceback.format_exc()}")

    async def cog_load(self):
        """Called when the cog is loaded"""
        logger.info("Error handling cog loaded successfully")
        # Start cleanup task
        self.client.loop.create_task(self._cleanup_task())

    async def _cleanup_task(self):
        """Periodically clean up old error tracking data"""
        while True:
            try:
                await asyncio.sleep(300)  # Clean every 5 minutes
                # Clear tracking sets to prevent memory buildup
                if len(self._sent_errors) > 50:
                    self._sent_errors.clear()
                if len(self._processing_errors) > 50:
                    self._processing_errors.clear()
            except Exception:
                pass

    @commands.Cog.listener()
    async def on_command_error(self, ctx: Context, error):
        if ctx.command is None:
            return

        # Create unique identifier for this specific command invocation
        command_key = (ctx.message.id, ctx.command.name)
        error_key = (ctx.message.id, ctx.command.name, type(error).__name__)
        
        # Prevent ANY duplicate processing or messaging for the same command
        if command_key in self._sent_errors or error_key in self._processing_errors:
            return
        
        # Mark this error as handled globally to suppress other handlers
        _error_handled.add(command_key)
        
        self._processing_errors.add(error_key)
        self._sent_errors.add(command_key)
        
        try:
            # Handle specific command invoke errors first
            if isinstance(error, commands.CommandInvokeError):
                error = error.original

            # Handle CheckFailure FIRST - before any logging or processing
            if isinstance(error, commands.CheckFailure):
                # Check if it's an ignore-related failure first
                try:
                    data = await get_ignore_data(ctx.guild.id)
                    ch = data.get("channel", [])
                    iuser = data.get("user", [])
                    cmd = data.get("command", [])
                    buser = data.get("bypassuser", [])

                    if str(ctx.author.id) in buser:
                        return

                    if str(ctx.channel.id) in ch:
                        await ctx.reply(
                            f"{ctx.author.mention} This **channel** is on the **ignored** list. Please try my commands in another channel.",
                            delete_after=8
                        )
                        return

                    if str(ctx.author.id) in iuser:
                        await ctx.reply(
                            f"{ctx.author.mention} You are set as an **ignored user** for this guild. Please try my commands or modules in a different guild.",
                            delete_after=8
                        )
                        return

                    if ctx.command.name in cmd or any(alias in cmd for alias in ctx.command.aliases):
                        await ctx.reply(
                            f"{ctx.author.mention} This **command is ignored** in this guild. Please use other commands or try this command in a different guild.",
                            delete_after=8
                        )
                        return
                except Exception:
                    # If there's an error getting ignore data, just silently ignore
                    pass

                # For any other CheckFailure (like blacklist, topcheck, etc.), silently ignore
                return

            # Log the error for debugging (but don't send user message yet)
            logger.error(f"Error in command {ctx.command} invoked by {ctx.author} ({ctx.author.id}): {error}", exc_info=True)

            # Handle specific error types with single response each
            if isinstance(error, commands.MissingRequiredArgument):
                await ctx.send_help(ctx.command)
                ctx.command.reset_cooldown(ctx)
                return

            if isinstance(error, commands.NoPrivateMessage):
                embed = discord.Embed(
                    color=0x000000,
                    description="You can't use my commands in DMs."
                )
                embed.set_author(
                    name=ctx.author,
                    icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
                )
                embed.set_thumbnail(
                    url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
                )
                await ctx.reply(embed=embed, delete_after=20)
                return

            if isinstance(error, commands.TooManyArguments):
                await ctx.send_help(ctx.command)
                ctx.command.reset_cooldown(ctx)
                return

            if isinstance(error, commands.CommandOnCooldown):
                embed = discord.Embed(
                    color=0x000000,
                    description=f"{ctx.author.mention} Whoa, slow down there! You can run the command again in **{error.retry_after:.2f}** seconds."
                )
                embed.set_author(name="Cooldown", icon_url=self.client.user.avatar.url)
                embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/1339632539354136701.png")
                embed.set_footer(
                    text=f"Requested by {ctx.author}",
                    icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
                )
                await ctx.reply(embed=embed, delete_after=10)
                return

            if isinstance(error, commands.MaxConcurrencyReached):
                embed = discord.Embed(
                    color=0x000000,
                    description=f"{ctx.author.mention} This command is already in progress. Please let it finish and try again afterward."
                )
                embed.set_author(name="Command in Progress", icon_url=self.client.user.avatar.url)
                embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/1339632539354136701.png")
                embed.set_footer(
                    text=f"Requested by {ctx.author}",
                    icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
                )
                await ctx.reply(embed=embed, delete_after=10)
                ctx.command.reset_cooldown(ctx)
                return

            if isinstance(error, commands.MissingPermissions):
                missing = [perm.replace("_", " ").replace("guild", "server").title() for perm in error.missing_permissions]
                fmt = "{}, and {}".format(", ".join(missing[:-1]), missing[-1]) if len(missing) > 2 else " and ".join(missing)
                embed = discord.Embed(
                    color=0x000000,
                    description=f"You lack the **{fmt}** permission(s) to run the **{ctx.command.name}** command!"
                )
                embed.set_author(name="Missing Permissions", icon_url=self.client.user.avatar.url)
                embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/1339632539354136701.png")
                embed.set_footer(
                    text=f"Requested by {ctx.author}",
                    icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
                )
                await ctx.reply(embed=embed, delete_after=10)
                ctx.command.reset_cooldown(ctx)
                return

            if isinstance(error, commands.BadArgument):
                await ctx.send_help(ctx.command)
                ctx.command.reset_cooldown(ctx)
                return

            if isinstance(error, commands.BotMissingPermissions):
                missing = [perm.replace("_", " ").replace("guild", "server").title() for perm in error.missing_permissions]
                fmt = "{}, and {}".format(", ".join(missing[:-1]), missing[-1]) if len(missing) > 2 else " and ".join(missing)
                embed = discord.Embed(
                    color=0x000000,
                    description=f"I need the **{fmt}** permission(s) to run the **{ctx.command.qualified_name}** command!"
                )
                embed.set_author(name="Bot Missing Permissions", icon_url=self.client.user.avatar.url)
                embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/1339632539354136701.png")
                embed.set_footer(
                    text=f"Requested by {ctx.author}",
                    icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
                )
                await ctx.reply(embed=embed, delete_after=10)
                return

            # Handle Discord API errors
            if isinstance(error, discord.Forbidden):
                embed = discord.Embed(
                    color=0x000000,
                    description="I don't have permission to perform this action."
                )
                embed.set_author(name="Permission Error", icon_url=self.client.user.avatar.url)
                embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/1339632539354136701.png")
                embed.set_footer(
                    text=f"Requested by {ctx.author}",
                    icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
                )
                await ctx.reply(embed=embed, delete_after=10)
                return

            if isinstance(error, discord.HTTPException):
                embed = discord.Embed(
                    color=0x000000,
                    description="A Discord API error occurred. Please try again later."
                )
                embed.set_author(name="API Error", icon_url=self.client.user.avatar.url)
                embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/1339632539354136701.png")
                embed.set_footer(
                    text=f"Requested by {ctx.author}",
                    icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
                )
                await ctx.reply(embed=embed, delete_after=10)
                return

            # Handle database errors
            if "database" in str(error).lower() or "sqlite" in str(error).lower():
                embed = discord.Embed(
                    color=0x000000,
                    description="A database error occurred. Please try again later."
                )
                embed.set_author(name="Database Error", icon_url=self.client.user.avatar.url)
                embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/1339632539354136701.png")
                embed.set_footer(
                    text=f"Requested by {ctx.author}",
                    icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
                )
                await ctx.reply(embed=embed, delete_after=10)
                return

            # Handle all other unhandled errors with a single generic message
            embed = discord.Embed(
                color=0x000000,
                description="An unexpected error occurred. Please try again later."
            )
            embed.set_author(name="Unexpected Error", icon_url=self.client.user.avatar.url)
            embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/1339632539354136701.png")
            embed.set_footer(
                text=f"Requested by {ctx.author}",
                icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url
            )
            await ctx.reply(embed=embed, delete_after=15)

        except Exception as send_error:
            # If we can't send the error message, log it but don't try again
            logger.error(f"Failed to send error message for command {ctx.command}: {send_error}")
        
        finally:
            # Always clean up the processing set
            self._processing_errors.discard(error_key)
            
            # Clean cache periodically to prevent memory buildup
            if len(self._processing_errors) > 100:
                self._processing_errors.clear()
            if len(self._sent_errors) > 200:
                self._sent_errors.clear()

    @commands.Cog.listener()
    async def on_application_command_error(self, interaction: discord.Interaction, error):
        """Handle slash command errors"""
        logger.error(f"Application command error: {error}", exc_info=True)

        # Create error embed for consistency
        embed = discord.Embed(color=0x000000)
        embed.set_thumbnail(url="https://cdn.discordapp.com/emojis/1339632539354136701.png")

        if isinstance(error, commands.MissingPermissions):
            missing = [perm.replace("_", " ").replace("guild", "server").title() for perm in error.missing_permissions]
            fmt = "{}, and {}".format(", ".join(missing[:-1]), missing[-1]) if len(missing) > 2 else " and ".join(missing)
            embed.title = "Missing Permissions"
            embed.description = f"You need the **{fmt}** permission(s) to use this command."
        elif isinstance(error, commands.BotMissingPermissions):
            missing = [perm.replace("_", " ").replace("guild", "server").title() for perm in error.missing_permissions]
            fmt = "{}, and {}".format(", ".join(missing[:-1]), missing[-1]) if len(missing) > 2 else " and ".join(missing)
            embed.title = "Bot Missing Permissions"
            embed.description = f"I need the **{fmt}** permission(s) to run this command."
        elif isinstance(error, discord.Forbidden):
            embed.title = "Permission Error"
            embed.description = "I don't have permission to perform this action."
        elif isinstance(error, discord.NotFound):
            embed.title = "Not Found"
            embed.description = "The requested resource was not found."
        else:
            embed.title = "Unexpected Error"
            embed.description = "An unexpected error occurred. Please try again later."

        try:
            if interaction.response.is_done():
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            logger.error(f"Failed to send slash command error message: {e}")

"""
@Author: ! Aegis !
    + Discord: Aegis
    + Community: https://discord.gg/35FqchfVZG (Strelix Studios™)
    + for any queries reach out Community or DM me.
"""
