import discord
from discord.ext import commands
from discord import app_commands, Interaction
from core import Context
from core.Strelizia import Strelizia
from core.Cog import Cog
from utils.Tools import getConfig, ignore_check, blacklist_check
from utils import help as vhelp
import asyncio

color = 0x000000

class HelpSlash(Cog, name="helpslash"):
    def __init__(self, client: Strelizia):
        self.bot = client

    @app_commands.command(name="help", description="Shows help about the bot and commands")
    async def help_slash(self, interaction: Interaction):
        try:
            if interaction.guild:
                try:
                    data = await getConfig(interaction.guild.id)
                    prefix = data.get("prefix", "/")
                except:
                    prefix = "/"
            else:
                prefix = "/"

            await interaction.response.defer()

            embed = discord.Embed(
                title="📁 Zyron-bot Command Suite",
                description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
                color=color
            )

            embed.add_field(
                name="⚙️ System Info",
                value="Commands: `157`\nModules: `104`\nPrefix: `/`"
            )

            embed.add_field(
                name="❔ How To Use",
                value="```Use /help <category> or /help <command>\nExample: /help automod```"
            )

            embed.add_field(
                name="🌐 Website",
                value="Click the link below to master every command:\n🔗 [Zyron Web](https://zyron.dpdns.org)"
            )

            embed.add_field(
                name="🏠 __**General Features**__",
                value=">>> 🔉 Voice\n🎮 Games\n🚀 Welcomer\n🎫 Ticketing\n✏️ Auto Setup\n🗨️ Autorole\n🧩 Fun\n❌ Ignore Channels\n📔 Logging\n⏲️ Counting\n⏫ Leveling\n🖲️ Tracking\n📺 Roleplay\n👨 Staff Application"
            )

            embed.add_field(
                name="🪐 __**Bot Features**__",
                value=">>> 🔐 Security\n🤖 Automod\n🔧 Utility\n🎧 Music\n🛠️ Moderation\n📁 General\n🎉 Giveaway\n👾 Artificial Intelligence\n🗄️ Backup"
            )

            embed.add_field(
                name="🔗 Useful Links",
                value="[**Support Server**](https://discord.gg/2Q9FqYubSf)\n[**Add Me**](https://discord.com/oauth2/authorize?client_id=1387495824195321938)"
            )

            embed.set_footer(text=f"Requested By {interaction.user}")
            embed.set_thumbnail(url=interaction.user.avatar.url if interaction.user.avatar else interaction.user.default_avatar.url)

            class FakeContext:
                def __init__(self, interaction):
                    self.author = interaction.user
                    self.guild = interaction.guild
                    self.bot = interaction.client
                    self.prefix = prefix
                    self.interaction = interaction

            fake_ctx = FakeContext(interaction)

            mapping = {}
            for cog in self.bot.cogs.values():
                if cog.get_commands():
                    mapping[cog] = cog.get_commands()

            view = vhelp.View(mapping=mapping, ctx=fake_ctx, homeembed=embed, ui=2)
            await interaction.followup.send(embed=embed, view=view)

        except Exception as e:
            print(f"Error in slash help command: {e}")
            if not interaction.response.is_done():
                await interaction.response.send_message(f"An error occurred: {str(e)}", ephemeral=True)
            else:
                await interaction.followup.send(f"An error occurred: {str(e)}", ephemeral=True)

async def setup(client):
    await client.add_cog(HelpSlash(client))