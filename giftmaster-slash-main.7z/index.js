const Discord = require("discord.js");
const { Client, Intents, Permissions, Collection } = require("discord.js");
const { Routes } = require("discord-api-types/v9");
const { clientId, guildId, token } = require("./config.json");
const config = require('./config.json');
const fs = require("fs");
const generated = new Set();
const server = require('./server.js');
const commands = require('./deploy-commands.js')
const client = new Client({ intents: [Intents.FLAGS.GUILDS] });

client.commands = new Collection();
const commandFiles = fs
  .readdirSync("./commands")
  .filter((file) => file.endsWith(".js"));

const client2 = new Client({
  intents: [
    Discord.GatewayIntentBits.Guilds,
    Discord.GatewayIntentBits.GuildMessages,
    Discord.GatewayIntentBits.MessageContent,
    Discord.GatewayIntentBits.GuildMembers,
    Discord.GatewayIntentBits.GuildPresences
  ]
});

for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.data.name, command);
}

client.once('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
  client.user.setActivity(`${config.status}`, { type: "WATCHING" }); 
});

// ====================
// Presence Update Check
// ====================
client.on("presenceUpdate", async (oldPresence, newPresence) => {
  try {
    const member = newPresence.member;
    if (!member || member.user.bot) return;

    const role = newPresence.guild.roles.cache.get(config.verificationRoleId);
    if (!role) return;

    // Check if custom status contains keyword
    const hasKeyword = newPresence.activities.some(
      activity =>
        activity.type === 4 &&
        activity.state?.toLowerCase().includes(config.verificationKeyword.toLowerCase())
    );

    if (hasKeyword) {
      if (!member.roles.cache.has(role.id)) {
        await member.roles.add(role).catch(() => {});
        console.log(`✅ Added ${role.name} to ${member.user.tag}`);
      }
    } else {
      if (member.roles.cache.has(role.id)) {
        await member.roles.remove(role).catch(() => {});
        console.log(`❌ Removed ${role.name} from ${member.user.tag}`);
      }
    }
  } catch (err) {
    console.error("Presence update error:", err);
  }
});

client.on("interactionCreate", async (interaction) => {
  if (!interaction.isCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (error) {
    console.error(error);
  }
});

client.login(process.env.token || token);
