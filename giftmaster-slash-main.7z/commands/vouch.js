const { SlashCommandBuilder } = require('@discordjs/builders');
const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('../config.json');

const vouchedFile = path.join(__dirname, '..', 'data', 'vouchedUsers.json');

function loadVouched() {
  if (!fs.existsSync(vouchedFile)) return [];
  return JSON.parse(fs.readFileSync(vouchedFile, 'utf8'));
}

function saveVouched(data) {
  fs.writeFileSync(vouchedFile, JSON.stringify(data, null, 2));
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('vouch')
    .setDescription('Vouch for a user')
    .addUserOption(option =>
      option.setName('user')
        .setDescription('The user to vouch')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('reason')
        .setDescription('Reason for vouching')
        .setRequired(false)),
  
  async execute(interaction) {
    if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
      return interaction.reply({ content: "You don’t have permission to use this command.", ephemeral: true });
    }

    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || "No reason provided";

    let vouchedUsers = loadVouched();

    // prevent duplicates
    if (vouchedUsers.some(v => v.userId === target.id)) {
      return interaction.reply({ content: `${target.username} is already vouched.`, ephemeral: true });
    }

    const entry = {
      userId: target.id,
      vouchedBy: interaction.user.id,
      reason: reason,
      timestamp: Date.now()
    };

    vouchedUsers.push(entry);
    saveVouched(vouchedUsers);

    const embed = new EmbedBuilder()
      .setColor(0x00ff00)
      .setTitle("✅ Vouch Recorded")
      .addFields(
        { name: "User", value: `${target} (${target.id})`, inline: true },
        { name: "Vouched By", value: `${interaction.user}`, inline: true },
        { name: "Reason", value: reason, inline: false }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });

    // Log channel if set
    if (config.vouchLogChannelId) {
      const logChannel = interaction.guild.channels.cache.get(config.vouchLogChannelId);
      if (logChannel) logChannel.send({ embeds: [embed] });
    }
  }
};
