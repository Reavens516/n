const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const config = require("../config.json");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("cstatus")
    .setDescription("Check your status and get verified if it matches"),

  async execute(interaction) {
    const member = interaction.member;

    if (member.user.bot) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor("Red")
          .setTitle("Error")
          .setDescription("Bots cannot use this command.")],
        ephemeral: true
      });
    }

    const presence = member.presence;
    if (!presence || !presence.activities) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor("Red")
          .setTitle("Not Verified")
          .setDescription(`You don't have a our status. Please set your status to include **${config.verificationKeyword}**.`)],
        ephemeral: true
      });
    }

    const hasKeyword = presence.activities.some(
      activity => activity.type === 4 && activity.state?.toLowerCase().includes(config.verificationKeyword.toLowerCase())
    );

    if (!hasKeyword) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor("Red")
          .setTitle("Not Verified")
          .setDescription(`Your status does not include **${config.verificationKeyword}**. Please update it and try again.`)],
        ephemeral: true
      });
    }

    const role = interaction.guild.roles.cache.get(config.verificationRoleId);
    if (!role) {
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor("Red")
          .setTitle("Error")
          .setDescription("Verification role not found. Please ask an admin to configure it.")],
        ephemeral: true
      });
    }

    try {
      await member.roles.add(role);
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor("Green")
          .setTitle("Verified")
          .setDescription(`You have been verified and given the **${role.name}** role!`)]
      });
    } catch (error) {
      console.error(error);
      return interaction.reply({
        embeds: [new EmbedBuilder()
          .setColor("Red")
          .setTitle("Error")
          .setDescription("I was unable to assign your verification role. Please contact an admin.")],
        ephemeral: true
      });
    }
  }
};
