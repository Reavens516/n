# 🚀 Crastro Panel

A powerful, modern web-based VPS management panel built with PHP and Docker. Crastro Panel allows you to easily create, manage, and monitor Docker containers through a beautiful, user-friendly interface.

## ✨ Features

- **🔐 Secure Authentication System** - Login with username/email and password, optional Discord OAuth
- **🐳 Docker Container Management** - Create, start, stop, restart, and delete containers
- **👥 Multi-User Support** - Admin and regular user roles with proper permissions
- **🎨 Beautiful Dark Theme** - Modern UI with snowflake effects and animations  
- **📊 Real-time Monitoring** - Container status tracking and system statistics
- **🖼️ Custom Docker Images** - Upload and manage your own Dockerfiles
- **🌐 Port Forwarding** - Integrated serveo.net support for external access
- **🔧 tmate Integration** - Direct terminal access to containers
- **⚙️ Admin Panel** - Complete system configuration and user management
- **📱 Responsive Design** - Works perfectly on desktop and mobile devices

## 🛠️ Technologies

- **Backend**: PHP 8.1+, MySQL 8.0
- **Frontend**: Bootstrap 5, jQuery, CSS3 Animations
- **Containerization**: Docker, Docker Compose
- **Web Server**: Nginx
- **Terminal**: tmate for container access

## 🚀 Quick Installation

### Method 1: Automated Installation (Recommended)

```bash
# Download and run the installation script
curl -sSL https://raw.githubusercontent.com/FrancisRozario760/crastro-panel/main/install.sh | sudo bash

# Or download first, then run
wget https://raw.githubusercontent.com/FrancisRozario760/crastro-panel/main/install.sh
chmod +x install.sh
sudo ./install.sh
```

The installer will:
1. Welcome you to Crastro Panel
2. Ask for admin credentials (username, email, password)  
3. Detect your server IP automatically
4. Allow customization of company name
5. Install all dependencies automatically
6. Configure nginx, PHP, MySQL, and Docker
7. Set up the database with default settings

### Method 2: Docker Compose (Development)

```bash
# Clone the repository
git clone https://github.com/FrancisRozario760/crastro-panel.git
cd crastro-panel

# Build and start services
docker-compose up -d

# Access at http://localhost
```

### Method 3: Manual Installation

```bash
# Install dependencies
sudo apt update
sudo apt install -y nginx php8.1-fpm php8.1-mysql php8.1-curl mysql-server docker.io tmate

# Clone repository
git clone https://github.com/yourusername/crastro-panel.git
cd crastro-panel

# Copy files to web directory
sudo cp -r web/* /var/www/html/

# Configure nginx (see config/nginx.conf)
# Configure database (see install.sh for schema)
# Set up admin user
```

## 📋 Requirements

- **OS**: Ubuntu 20.04+ (recommended), CentOS 8+, Debian 11+
- **RAM**: 2GB minimum, 4GB+ recommended
- **Storage**: 20GB minimum
- **Software**:
  - Docker & Docker Compose
  - nginx
  - PHP 8.1+ (with mysqli, pdo, curl, json, mbstring)
  - MySQL 8.0+
  - tmate

## 🔧 Configuration

### Environment Settings

After installation, you can configure the panel through:

1. **Admin Settings Panel** - Web interface configuration
2. **config/config.php** - Core application settings
3. **config/database.php** - Database connection settings

### Default Admin Account

The installer creates an admin account with credentials you provide during setup.

### Discord OAuth (Optional)

To enable Discord login:
1. Go to Admin Settings
2. Enable Discord authentication  
3. Add your Discord application credentials
4. Set the redirect URL

## 🐳 Container Management

### Supported Features

- ✅ **Create Containers** from predefined Docker images
- ✅ **Start/Stop/Restart** containers with one click
- ✅ **Real-time Status** monitoring and updates
- ✅ **Terminal Access** through tmate sessions
- ✅ **Port Forwarding** via serveo.net
- ✅ **Custom Images** - upload your own Dockerfiles
- ✅ **Resource Limits** - CPU and memory controls

### Default Container Image

Comes with Ubuntu 22.04 pre-configured with:
- tmate for terminal access
- SSH server with root access
- Common networking tools
- SystemD support
- Firewall configuration (ports 80, 443)

## 👥 User Management

### Admin Features
- Create, edit, and delete users
- Promote users to admin
- Set container creation permissions
- View all containers across users
- System-wide configuration

### User Features  
- Create and manage own containers (if permitted)
- View personal container statistics
- Access terminal sessions
- Port forwarding configuration

## 🎨 Customization

### Themes
- Default dark theme with animations
- Snowflake effect (can be disabled)
- Custom background image support
- Company branding options

### Effects
- Snowflake animation
- Particle effects on login page
- Smooth transitions and hover effects
- Loading animations

## 🔒 Security Features

- **Password Hashing** - BCrypt encryption
- **Session Management** - Secure session handling
- **Input Sanitization** - XSS protection
- **SQL Injection Prevention** - Prepared statements
- **Admin-Only Areas** - Role-based access control
- **Maintenance Mode** - Disable user access during updates

## 📊 Monitoring & Statistics

- Real-time container status
- System uptime tracking
- User and container counts
- Resource usage (planned)
- Activity logging (planned)

## 🌐 Networking

### Port Forwarding
Integrated serveo.net support allows users to expose container ports to the internet:
```bash
# Automatic setup for web services
ssh -R 80:localhost:8080 serveo.net
```

### Container Networking
- Isolated container networks
- Port mapping and forwarding
- DNS resolution between containers

## 🚨 Troubleshooting

### Common Issues

**Installation fails:**
```bash
# Check if running as root
sudo whoami

# Verify Docker is running
sudo systemctl status docker

# Check nginx configuration
sudo nginx -t
```

**Containers won't start:**
```bash
# Check Docker daemon
sudo systemctl status docker

# View Docker logs
sudo docker logs <container_id>
```

**Database connection issues:**
```bash
# Test MySQL connection
mysql -u crastro -p crastro_panel

# Check PHP MySQL extension
php -m | grep mysql
```

### Support

- 📖 **Documentation**: [GitHub Wiki](https://github.com/FrancisRozario760/crastro-panel/wiki)
- 🐛 **Bug Reports**: [GitHub Issues](https://github.com/FrancisRozario760/crastro-panel/issues)  
- 💬 **Community**: [Discord Server](https://discord.gg/your-server)
- 📺 **Tutorials**: [YouTube Channel](https://youtube.com/your-channel)

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with ❤️ by [@Notlol95](https://github.com/FrancisRozario760)
- Inspired by Pterodactyl Panel
- Thanks to all contributors and users

## 📸 Screenshots

### Dashboard
![Dashboard](screenshots/dashboard.png)

### Container Management  
![Container Management](screenshots/containers.png)

### Admin Panel
![Admin Panel](screenshots/admin.png)

---

## 📈 Roadmap

- [ ] **Resource Monitoring** - CPU, RAM, disk usage
- [ ] **Backup System** - Container backups and restoration
- [ ] **Template System** - Pre-configured container templates
- [ ] **API Integration** - RESTful API for automation
- [ ] **Proxmox Integration** - VM management capabilities
- [ ] **LXD Support** - Linux container management
- [ ] **Clustering** - Multi-node support
- [ ] **Monitoring Alerts** - Email/Discord notifications

---

⭐ **Star this repository if you found it helpful!**

Made with ❤️ by [@Notlol95](https://github.com/FrancisRozario760) | **Free & Open Source** 🚀
