<?php
// Main Configuration File for Crastro Panel
// Made by @Notlol95

// Start session
session_start();

// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Timezone
date_default_timezone_set('UTC');

// Site configuration
define('SITE_URL', 'http://localhost');
define('SITE_NAME', 'Crastro Panel');
define('VERSION', '1.0.0');
define('AUTHOR', '@Notlol95');

// Path constants
define('ROOT_PATH', dirname(dirname(__FILE__)));
define('WEB_PATH', ROOT_PATH . '/web');
define('CONFIG_PATH', ROOT_PATH . '/config');
define('INCLUDES_PATH', WEB_PATH . '/includes');
define('PAGES_PATH', WEB_PATH . '/pages');
define('API_PATH', WEB_PATH . '/api');
define('ASSETS_PATH', WEB_PATH . '/assets');

// Include database configuration
require_once CONFIG_PATH . '/database.php';

// Docker configuration
define('DOCKER_SOCKET', '/var/run/docker.sock');
define('TMATE_BINARY', '/usr/bin/tmate');

// Serveo.net configuration for port forwarding
define('SERVEO_HOST', 'serveo.net');
define('SERVEO_SSH_KEY_PATH', ROOT_PATH . '/config/serveo_key');

// Security settings
define('PASSWORD_MIN_LENGTH', 6);
define('SESSION_TIMEOUT', 3600); // 1 hour
define('MAX_LOGIN_ATTEMPTS', 5);
define('LOGIN_BLOCK_TIME', 300); // 5 minutes

// Container limits
define('MAX_CONTAINERS_PER_USER', 10);
define('DEFAULT_CONTAINER_RAM', '512m');
define('DEFAULT_CONTAINER_CPU', '0.5');

// File upload settings
define('MAX_DOCKERFILE_SIZE', 1048576); // 1MB
define('ALLOWED_IMAGE_TYPES', ['png', 'jpg', 'jpeg', 'gif']);

// Default settings (can be overridden from database)
$default_settings = [
    'company_name' => 'Crastro Panel',
    'theme_background' => 'default',
    'snowflake_effect' => 'true',
    'discord_enabled' => 'false',
    'discord_client_id' => '',
    'discord_client_secret' => '',
    'discord_redirect_url' => '',
    'maintenance_mode' => 'false',
    'user_can_create' => 'true',
    'discord_invite' => '',
    'youtube_link' => '',
    'other_links' => ''
];

// Helper functions
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function generate_random_string($length = 10) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}

function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function is_admin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: /login.php');
        exit();
    }
}

function require_admin() {
    require_login();
    if (!is_admin()) {
        header('Location: /dashboard.php');
        exit();
    }
}

function get_setting($key, $default = null) {
    global $db;
    
    $stmt = $db->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
    $stmt->execute([$key]);
    $result = $stmt->fetch();
    
    if ($result) {
        return $result['setting_value'];
    }
    
    return $default;
}

function set_setting($key, $value) {
    global $db;
    
    $stmt = $db->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    return $stmt->execute([$key, $value, $value]);
}

function log_action($action, $details = '') {
    global $db;
    
    $user_id = $_SESSION['user_id'] ?? null;
    $stmt = $db->prepare("INSERT INTO audit_logs (user_id, action, details) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $action, $details]);
}

function format_uptime($seconds) {
    $days = floor($seconds / 86400);
    $hours = floor(($seconds % 86400) / 3600);
    $minutes = floor(($seconds % 3600) / 60);
    
    if ($days > 0) {
        return "{$days}d {$hours}h {$minutes}m";
    } elseif ($hours > 0) {
        return "{$hours}h {$minutes}m";
    } else {
        return "{$minutes}m";
    }
}

function get_user_container_count($user_id) {
    global $db;
    
    $stmt = $db->prepare("SELECT COUNT(*) FROM containers WHERE user_id = ?");
    $stmt->execute([$user_id]);
    return $stmt->fetchColumn();
}

function can_user_create_container($user_id) {
    if (get_setting('maintenance_mode') === 'true') {
        return false;
    }
    
    if (!is_admin() && get_setting('user_can_create') !== 'true') {
        return false;
    }
    
    $container_count = get_user_container_count($user_id);
    return $container_count < MAX_CONTAINERS_PER_USER;
}

// Load settings from database
function load_settings() {
    global $db, $default_settings;
    
    try {
        $stmt = $db->query("SELECT setting_key, setting_value FROM settings");
        $db_settings = $stmt->fetchAll();
        
        foreach ($db_settings as $setting) {
            $GLOBALS['settings'][$setting['setting_key']] = $setting['setting_value'];
        }
        
        // Fill in any missing settings with defaults
        foreach ($default_settings as $key => $value) {
            if (!isset($GLOBALS['settings'][$key])) {
                $GLOBALS['settings'][$key] = $value;
            }
        }
    } catch (Exception $e) {
        // If settings table doesn't exist yet, use defaults
        $GLOBALS['settings'] = $default_settings;
    }
}

// Initialize settings
load_settings();

// Check if maintenance mode is enabled
if (get_setting('maintenance_mode') === 'true' && !is_admin() && basename($_SERVER['PHP_SELF']) !== 'maintenance.php') {
    header('Location: /maintenance.php');
    exit();
}

?>