#!/bin/bash

# Crastro Panel Installation Script
# Made by @Notlol95
# Free Version

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# Function to print colored text
print_colored() {
    local color=$1
    local text=$2
    echo -e "${color}${text}${NC}"
}

# Function to print banner
print_banner() {
    clear
    print_colored $CYAN "
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║    ██████╗██████╗  █████╗ ███████╗████████╗██████╗  ██████╗   ║
║   ██╔════╝██╔══██╗██╔══██╗██╔════╝╚══██╔══╝██╔══██╗██╔═══██╗  ║
║   ██║     ██████╔╝███████║███████╗   ██║   ██████╔╝██║   ██║  ║
║   ██║     ██╔══██╗██╔══██║╚════██║   ██║   ██╔══██╗██║   ██║  ║
║   ╚██████╗██║  ██║██║  ██║███████║   ██║   ██║  ██║╚██████╔╝  ║
║    ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝   ║
║                                                               ║
║                    P A N E L   I N S T A L L E R             ║
║                                                               ║
║                      Made By @Notlol95                       ║
║                        FREE VERSION                          ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
"
}

# Function to detect IP address
detect_ip() {
    local ip
    # Try different methods to get IP
    ip=$(curl -s ifconfig.me 2>/dev/null) || \
    ip=$(curl -s icanhazip.com 2>/dev/null) || \
    ip=$(curl -s ipecho.net/plain 2>/dev/null) || \
    ip=$(hostname -I | awk '{print $1}' 2>/dev/null) || \
    ip="127.0.0.1"
    echo $ip
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to install dependencies
install_dependencies() {
    print_colored $YELLOW "Installing dependencies..."
    
    if command_exists apt-get; then
        apt-get update
        apt-get install -y curl wget git docker.io docker-compose nginx php8.1 php8.1-fpm php8.1-mysql php8.1-curl php8.1-json php8.1-mbstring mysql-server tmate
        systemctl enable docker
        systemctl start docker
    elif command_exists yum; then
        yum update -y
        yum install -y curl wget git docker docker-compose nginx php php-fpm php-mysql php-curl php-json php-mbstring mysql-server tmate
        systemctl enable docker
        systemctl start docker
    elif command_exists pacman; then
        pacman -Syu --noconfirm
        pacman -S --noconfirm curl wget git docker docker-compose nginx php php-fpm mariadb tmate
        systemctl enable docker
        systemctl start docker
    else
        print_colored $RED "Unsupported package manager. Please install dependencies manually."
        exit 1
    fi
}

# Function to setup MySQL database
setup_database() {
    print_colored $YELLOW "Setting up MySQL database..."
    
    mysql -e "CREATE DATABASE IF NOT EXISTS crastro_panel;"
    mysql -e "CREATE USER IF NOT EXISTS 'crastro'@'localhost' IDENTIFIED BY 'crastro_secure_2024';"
    mysql -e "GRANT ALL PRIVILEGES ON crastro_panel.* TO 'crastro'@'localhost';"
    mysql -e "FLUSH PRIVILEGES;"
    
    # Create database schema
    mysql crastro_panel << EOF
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL
);

CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS docker_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    dockerfile TEXT NOT NULL,
    is_default BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS containers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    container_id VARCHAR(64) UNIQUE,
    name VARCHAR(100) NOT NULL,
    user_id INT,
    image_id INT,
    status ENUM('creating', 'running', 'stopped', 'error') DEFAULT 'creating',
    tmate_session VARCHAR(255),
    port_forward VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (image_id) REFERENCES docker_images(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS proxmox_nodes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    host VARCHAR(255) NOT NULL,
    username VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
EOF
}

# Function to setup web files
setup_web_files() {
    print_colored $YELLOW "Setting up web files..."
    
    mkdir -p /var/www/crastro-panel
    cp -r ./* /var/www/crastro-panel/
    chown -R www-data:www-data /var/www/crastro-panel
    chmod -R 755 /var/www/crastro-panel
}

# Function to setup nginx
setup_nginx() {
    print_colored $YELLOW "Configuring Nginx..."
    
    cat > /etc/nginx/sites-available/crastro-panel << EOF
server {
    listen 80;
    server_name ${SERVER_IP};
    root /var/www/crastro-panel;
    index index.php index.html;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME \$realpath_root\$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.ht {
        deny all;
    }
}
EOF

    ln -sf /etc/nginx/sites-available/crastro-panel /etc/nginx/sites-enabled/
    rm -f /etc/nginx/sites-enabled/default
    
    nginx -t && systemctl reload nginx
}

# Function to create initial admin user
create_admin_user() {
    print_colored $YELLOW "Creating admin user..."
    
    password_hash=$(php -r "echo password_hash('$ADMIN_PASSWORD', PASSWORD_DEFAULT);")
    
    mysql crastro_panel << EOF
INSERT INTO users (username, email, password_hash, is_admin) 
VALUES ('$ADMIN_USERNAME', '$ADMIN_EMAIL', '$password_hash', TRUE)
ON DUPLICATE KEY UPDATE 
    email = '$ADMIN_EMAIL',
    password_hash = '$password_hash',
    is_admin = TRUE;
EOF
}

# Function to insert default settings
insert_default_settings() {
    print_colored $YELLOW "Inserting default settings..."
    
    mysql crastro_panel << EOF
INSERT INTO settings (setting_key, setting_value) VALUES 
('company_name', '$COMPANY_NAME'),
('theme_background', 'default'),
('snowflake_effect', 'true'),
('discord_enabled', 'false'),
('discord_client_id', ''),
('discord_client_secret', ''),
('discord_redirect_url', ''),
('maintenance_mode', 'false'),
('user_can_create', 'true'),
('discord_invite', ''),
('youtube_link', ''),
('other_links', '')
ON DUPLICATE KEY UPDATE 
setting_value = VALUES(setting_value);

INSERT INTO docker_images (name, dockerfile, is_default) VALUES 
('Ubuntu 22.04 Default', 'FROM ubuntu:22.04
RUN apt-get update
RUN apt-get install -y tmate openssh-server openssh-client
RUN sed -i ''s/^#\\?\\s*PermitRootLogin\\s\\+.*/PermitRootLogin yes/'' /etc/ssh/sshd_config
RUN echo ''root:root'' | chpasswd
RUN printf ''#!/bin/sh\\nexit 0'' > /usr/sbin/policy-rc.d
RUN apt-get install -y systemd systemd-sysv dbus dbus-user-session
RUN printf "systemctl start systemd-logind" >> /etc/profile
RUN apt install curl -y
RUN apt install ufw -y && ufw allow 80 && ufw allow 443 && apt install net-tools -y
RUN apt-get update && apt-get install -y \\
    iproute2 \\
    hostname \\
    && rm -rf /var/lib/apt/lists/*
CMD ["bash"]
ENTRYPOINT ["/sbin/init"]', TRUE);
EOF
}

# Main installation function
main() {
    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        print_colored $RED "This script must be run as root (use sudo)"
        exit 1
    fi

    print_banner
    
    print_colored $WHITE "Welcome to Crastro Panel Installation!"
    print_colored $CYAN "Made By @Notlol95 - FREE VERSION"
    echo
    
    # Ask for installation confirmation
    while true; do
        read -p "$(print_colored $YELLOW 'Do you want to install Crastro Panel? (Y/N or Yes/No): ')" yn
        case $yn in
            [Yy]* | [Yy][Ee][Ss]* ) break;;
            [Nn]* | [Nn][Oo]* ) 
                print_colored $RED "User cancelled the installation"
                exit 0
                ;;
            * ) print_colored $RED "Please answer Y/N or Yes/No.";;
        esac
    done
    
    echo
    print_colored $GREEN "Great! Let's set up your Crastro Panel."
    echo
    
    # Collect admin information
    while true; do
        read -p "$(print_colored $CYAN 'Enter Username for Panel Admin Login: ')" ADMIN_USERNAME
        if [[ -n "$ADMIN_USERNAME" ]]; then
            break
        fi
        print_colored $RED "Username cannot be empty!"
    done
    
    while true; do
        read -p "$(print_colored $CYAN 'Enter Email for Admin: ')" ADMIN_EMAIL
        if [[ "$ADMIN_EMAIL" =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
            break
        fi
        print_colored $RED "Please enter a valid email address!"
    done
    
    while true; do
        read -s -p "$(print_colored $CYAN 'Enter Password for Admin: ')" ADMIN_PASSWORD
        echo
        if [[ ${#ADMIN_PASSWORD} -ge 6 ]]; then
            break
        fi
        print_colored $RED "Password must be at least 6 characters long!"
    done
    
    # Detect IP address
    print_colored $YELLOW "Detecting IPv4 address..."
    SERVER_IP=$(detect_ip)
    print_colored $GREEN "Detected IP: $SERVER_IP"
    
    # Ask for company name
    read -p "$(print_colored $CYAN 'Enter Company Name (default: Crastro Panel): ')" COMPANY_NAME
    COMPANY_NAME=${COMPANY_NAME:-"Crastro Panel"}
    
    echo
    print_colored $WHITE "=== Installation Summary ==="
    print_colored $CYAN "Admin Username: $ADMIN_USERNAME"
    print_colored $CYAN "Admin Email: $ADMIN_EMAIL"
    print_colored $CYAN "Server IP: $SERVER_IP"
    print_colored $CYAN "Company Name: $COMPANY_NAME"
    print_colored $CYAN "Web Port: 80"
    echo
    
    # Final confirmation
    while true; do
        read -p "$(print_colored $YELLOW 'Do you want to continue with these settings? (Y/N): ')" yn
        case $yn in
            [Yy]* ) break;;
            [Nn]* ) 
                print_colored $RED "Installation cancelled by user"
                exit 0
                ;;
            * ) print_colored $RED "Please answer Y or N.";;
        esac
    done
    
    echo
    print_colored $GREEN "Starting Crastro Panel installation..."
    echo
    
    # Installation steps
    install_dependencies
    setup_database
    setup_web_files
    setup_nginx
    create_admin_user
    insert_default_settings
    
    print_colored $GREEN "
╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║              🎉 INSTALLATION COMPLETED! 🎉                    ║
║                                                               ║
║  Crastro Panel has been successfully installed!              ║
║                                                               ║
║  Access your panel at: http://$SERVER_IP                     ║
║  Admin Username: $ADMIN_USERNAME                              ║
║  Admin Email: $ADMIN_EMAIL                                    ║
║                                                               ║
║  Don't forget to:                                            ║
║  1. Configure your firewall to allow port 80                ║
║  2. Set up SSL certificate for production use               ║
║  3. Configure Discord OAuth if needed                       ║
║                                                               ║
║              Made with ❤️  by @Notlol95                      ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝
"
    
    systemctl restart nginx
    systemctl restart php8.1-fpm
    systemctl restart docker
    
    print_colored $YELLOW "Services restarted. Your panel should now be accessible!"
}

# Run the main function
main "$@"