// Crastro Panel - Snowflake Effect
// Made by @Notlol95

class SnowflakeEffect {
    constructor() {
        this.container = document.getElementById('snowflakes-container');
        this.snowflakes = [];
        this.maxSnowflakes = 50;
        this.snowflakeChars = ['❄', '❅', '❆', '✢', '✣', '✤', '✥', '✦'];
        
        if (this.container) {
            this.init();
        }
    }
    
    init() {
        // Create initial snowflakes
        for (let i = 0; i < this.maxSnowflakes; i++) {
            setTimeout(() => {
                this.createSnowflake();
            }, i * 200);
        }
        
        // Continuously create new snowflakes
        setInterval(() => {
            if (this.snowflakes.length < this.maxSnowflakes) {
                this.createSnowflake();
            }
        }, 800);
    }
    
    createSnowflake() {
        const snowflake = document.createElement('div');
        snowflake.className = 'snowflake';
        snowflake.innerHTML = this.getRandomChar();
        
        // Random starting position
        snowflake.style.left = Math.random() * window.innerWidth + 'px';
        
        // Random properties
        const fontSize = Math.random() * 0.8 + 0.6; // 0.6rem to 1.4rem
        const duration = Math.random() * 8 + 5; // 5s to 13s
        const opacity = Math.random() * 0.6 + 0.3; // 0.3 to 0.9
        const drift = (Math.random() - 0.5) * 100; // -50px to 50px
        
        snowflake.style.fontSize = fontSize + 'rem';
        snowflake.style.opacity = opacity;
        snowflake.style.animationDuration = duration + 's';
        
        // Add drift animation
        snowflake.style.setProperty('--drift', drift + 'px');
        snowflake.style.animation = `fall ${duration}s linear, drift ${duration * 0.7}s ease-in-out infinite alternate`;
        
        this.container.appendChild(snowflake);
        this.snowflakes.push(snowflake);
        
        // Remove snowflake after animation
        setTimeout(() => {
            this.removeSnowflake(snowflake);
        }, duration * 1000);
    }
    
    removeSnowflake(snowflake) {
        const index = this.snowflakes.indexOf(snowflake);
        if (index > -1) {
            this.snowflakes.splice(index, 1);
        }
        
        if (snowflake.parentNode) {
            snowflake.parentNode.removeChild(snowflake);
        }
    }
    
    getRandomChar() {
        return this.snowflakeChars[Math.floor(Math.random() * this.snowflakeChars.length)];
    }
}

// Add drift keyframe animation to CSS
const driftCSS = `
@keyframes drift {
    0% { transform: translateX(0px); }
    100% { transform: translateX(var(--drift, 0px)); }
}
`;

// Insert CSS
const style = document.createElement('style');
style.textContent = driftCSS;
document.head.appendChild(style);

// Initialize snowflake effect when page loads
document.addEventListener('DOMContentLoaded', function() {
    new SnowflakeEffect();
});

// Restart effect when window is resized
let resizeTimer;
window.addEventListener('resize', function() {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function() {
        const container = document.getElementById('snowflakes-container');
        if (container) {
            container.innerHTML = '';
            new SnowflakeEffect();
        }
    }, 500);
});