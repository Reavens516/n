// Crastro Panel - Main JavaScript
// Made by @Notlol95

// Global variables
let refreshInterval = null;

// Document ready
$(document).ready(function() {
    initializeApp();
});

// Initialize application
function initializeApp() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Auto-refresh container status
    if (window.location.search.includes('page=dashboard') || window.location.search.includes('page=servers')) {
        startAutoRefresh();
    }
    
    // Initialize file input custom labels
    initializeFileInputs();
    
    // Initialize form validation
    initializeFormValidation();
}

// Container management functions
function startContainer(containerId) {
    showLoading();
    $.ajax({
        url: 'api/container.php',
        method: 'POST',
        data: {
            action: 'start',
            container_id: containerId
        },
        success: function(response) {
            if (response.success) {
                showAlert('success', 'Container started successfully!');
                refreshContainerStatus();
            } else {
                showAlert('danger', response.message || 'Failed to start container');
            }
        },
        error: function() {
            showAlert('danger', 'Network error occurred');
        },
        complete: function() {
            hideLoading();
        }
    });
}

function stopContainer(containerId) {
    if (confirm('Are you sure you want to stop this container?')) {
        showLoading();
        $.ajax({
            url: 'api/container.php',
            method: 'POST',
            data: {
                action: 'stop',
                container_id: containerId
            },
            success: function(response) {
                if (response.success) {
                    showAlert('success', 'Container stopped successfully!');
                    refreshContainerStatus();
                } else {
                    showAlert('danger', response.message || 'Failed to stop container');
                }
            },
            error: function() {
                showAlert('danger', 'Network error occurred');
            },
            complete: function() {
                hideLoading();
            }
        });
    }
}

function restartContainer(containerId) {
    if (confirm('Are you sure you want to restart this container?')) {
        showLoading();
        $.ajax({
            url: 'api/container.php',
            method: 'POST',
            data: {
                action: 'restart',
                container_id: containerId
            },
            success: function(response) {
                if (response.success) {
                    showAlert('success', 'Container restarted successfully!');
                    refreshContainerStatus();
                } else {
                    showAlert('danger', response.message || 'Failed to restart container');
                }
            },
            error: function() {
                showAlert('danger', 'Network error occurred');
            },
            complete: function() {
                hideLoading();
            }
        });
    }
}

function deleteContainer(containerId) {
    if (confirm('Are you sure you want to delete this container? This action cannot be undone!')) {
        showLoading();
        $.ajax({
            url: 'api/container.php',
            method: 'POST',
            data: {
                action: 'delete',
                container_id: containerId
            },
            success: function(response) {
                if (response.success) {
                    showAlert('success', 'Container deleted successfully!');
                    location.reload(); // Refresh page to remove deleted container
                } else {
                    showAlert('danger', response.message || 'Failed to delete container');
                }
            },
            error: function() {
                showAlert('danger', 'Network error occurred');
            },
            complete: function() {
                hideLoading();
            }
        });
    }
}

// Refresh container status
function refreshContainerStatus() {
    $.ajax({
        url: 'api/containers.php',
        method: 'GET',
        success: function(response) {
            if (response.success && response.containers) {
                updateContainerCards(response.containers);
                updateDashboardStats(response.stats);
            }
        },
        error: function() {
            console.log('Failed to refresh container status');
        }
    });
}

// Update container cards
function updateContainerCards(containers) {
    containers.forEach(function(container) {
        const card = $(`[data-container-id="${container.id}"]`);
        if (card.length) {
            // Update status badge
            const statusBadge = card.find('.status-badge');
            statusBadge.removeClass().addClass('status-badge status-' + container.status);
            statusBadge.text(container.status.toUpperCase());
            
            // Update buttons based on status
            const startBtn = card.find('.btn-start');
            const stopBtn = card.find('.btn-stop');
            const restartBtn = card.find('.btn-restart');
            
            if (container.status === 'running') {
                startBtn.hide();
                stopBtn.show();
                restartBtn.show();
            } else {
                startBtn.show();
                stopBtn.hide();
                restartBtn.hide();
            }
        }
    });
}

// Update dashboard statistics
function updateDashboardStats(stats) {
    if (stats) {
        $('#total-containers').text(stats.total || 0);
        $('#running-containers').text(stats.running || 0);
        $('#stopped-containers').text(stats.stopped || 0);
        $('#total-users').text(stats.users || 0);
    }
}

// Start auto-refresh
function startAutoRefresh() {
    // Clear existing interval
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }
    
    // Start new interval (refresh every 30 seconds)
    refreshInterval = setInterval(refreshContainerStatus, 30000);
}

// Stop auto-refresh
function stopAutoRefresh() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
        refreshInterval = null;
    }
}

// File input custom labels
function initializeFileInputs() {
    $('.custom-file-input').on('change', function() {
        const fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').html(fileName || 'Choose file...');
    });
}

// Form validation
function initializeFormValidation() {
    // Bootstrap validation
    $('form.needs-validation').on('submit', function(e) {
        if (!this.checkValidity()) {
            e.preventDefault();
            e.stopPropagation();
        }
        $(this).addClass('was-validated');
    });
    
    // Password confirmation validation
    $('input[name="confirm_password"]').on('input', function() {
        const password = $('input[name="password"]').val();
        const confirmPassword = $(this).val();
        
        if (password !== confirmPassword) {
            this.setCustomValidity('Passwords do not match');
        } else {
            this.setCustomValidity('');
        }
    });
}

// Alert functions
function showAlert(type, message, permanent = false) {
    const alertClass = permanent ? 'alert alert-permanent' : 'alert';
    const alert = $(`
        <div class="${alertClass} alert-${type} alert-dismissible fade show" role="alert">
            <i class="fas fa-${getAlertIcon(type)}"></i> ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `);
    
    $('#alert-container, .alert-container').first().append(alert);
    
    if (!permanent) {
        setTimeout(function() {
            alert.fadeOut();
        }, 5000);
    }
}

function getAlertIcon(type) {
    const icons = {
        'success': 'check-circle',
        'danger': 'exclamation-triangle',
        'warning': 'exclamation-circle',
        'info': 'info-circle'
    };
    return icons[type] || 'info-circle';
}

// Loading functions
function showLoading(message = 'Loading...') {
    const loadingModal = $(`
        <div class="modal fade" id="loadingModal" data-bs-backdrop="static" data-bs-keyboard="false">
            <div class="modal-dialog modal-sm modal-dialog-centered">
                <div class="modal-content bg-transparent border-0">
                    <div class="modal-body text-center">
                        <div class="spinner-border text-primary mb-3" role="status">
                            <span class="visually-hidden">Loading...</span>
                        </div>
                        <div class="text-white">${message}</div>
                    </div>
                </div>
            </div>
        </div>
    `);
    
    $('body').append(loadingModal);
    $('#loadingModal').modal('show');
}

function hideLoading() {
    $('#loadingModal').modal('hide');
    setTimeout(function() {
        $('#loadingModal').remove();
    }, 300);
}

// Copy to clipboard function
function copyToClipboard(text, element = null) {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(function() {
            showAlert('success', 'Copied to clipboard!');
            if (element) {
                const originalText = element.innerHTML;
                element.innerHTML = '<i class="fas fa-check"></i> Copied!';
                setTimeout(function() {
                    element.innerHTML = originalText;
                }, 2000);
            }
        });
    } else {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        showAlert('success', 'Copied to clipboard!');
    }
}

// Format bytes
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// Format uptime
function formatUptime(seconds) {
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (days > 0) {
        return `${days}d ${hours}h ${minutes}m`;
    } else if (hours > 0) {
        return `${hours}h ${minutes}m`;
    } else {
        return `${minutes}m`;
    }
}

// Confirm dialog
function confirmDialog(title, message, callback) {
    const modal = $(`
        <div class="modal fade" id="confirmModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">${title}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>${message}</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-danger" id="confirmBtn">Confirm</button>
                    </div>
                </div>
            </div>
        </div>
    `);
    
    $('body').append(modal);
    
    $('#confirmBtn').on('click', function() {
        callback();
        $('#confirmModal').modal('hide');
    });
    
    $('#confirmModal').on('hidden.bs.modal', function() {
        $(this).remove();
    });
    
    $('#confirmModal').modal('show');
}

// WebSocket connection for real-time updates (if needed)
function initWebSocket() {
    // Implementation for real-time container status updates
    // This can be added later if needed
}

// Export functions for global use
window.crastroPanel = {
    startContainer: startContainer,
    stopContainer: stopContainer,
    restartContainer: restartContainer,
    deleteContainer: deleteContainer,
    refreshContainerStatus: refreshContainerStatus,
    showAlert: showAlert,
    showLoading: showLoading,
    hideLoading: hideLoading,
    copyToClipboard: copyToClipboard,
    formatBytes: formatBytes,
    formatUptime: formatUptime,
    confirmDialog: confirmDialog
};