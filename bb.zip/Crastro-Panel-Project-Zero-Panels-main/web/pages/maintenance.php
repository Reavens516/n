<?php
// Don't require login for maintenance page
$page_title = "Maintenance Mode";
?>

<div class="login-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-5">
                <div class="card login-card">
                    <div class="card-body text-center py-5">
                        <div class="mb-4">
                            <i class="fas fa-tools fa-4x text-warning mb-3"></i>
                            <h2 class="h3 mb-3">System Maintenance</h2>
                            <p class="text-muted mb-4">
                                <?php echo get_setting('company_name', 'Crastro Panel'); ?> is currently under maintenance. 
                                We'll be back shortly!
                            </p>
                        </div>
                        
                        <div class="mb-4">
                            <div class="spinner-border text-primary me-2" role="status">
                                <span class="visually-hidden">Loading...</span>
                            </div>
                            <small class="text-muted">Please check back in a few minutes</small>
                        </div>
                        
                        <div class="mt-4">
                            <p class="text-muted mb-2">Need immediate assistance?</p>
                            <?php if (!empty(get_setting('discord_invite'))): ?>
                                <a href="<?php echo get_setting('discord_invite'); ?>" class="btn btn-outline-primary btn-sm me-2" target="_blank">
                                    <i class="fab fa-discord"></i> Discord
                                </a>
                            <?php endif; ?>
                            
                            <?php if (!empty(get_setting('youtube_link'))): ?>
                                <a href="<?php echo get_setting('youtube_link'); ?>" class="btn btn-outline-danger btn-sm" target="_blank">
                                    <i class="fab fa-youtube"></i> YouTube
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-footer text-center">
                        <small class="text-muted">
                            © <?php echo date('Y'); ?> <?php echo get_setting('company_name', 'Crastro Panel'); ?> - 
                            Made with ❤️ by <?php echo AUTHOR; ?>
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.maintenance-pulse {
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.05); opacity: 0.7; }
    100% { transform: scale(1); opacity: 1; }
}
</style>

<script>
// Auto-refresh every 30 seconds to check if maintenance is disabled
setInterval(function() {
    window.location.reload();
}, 30000);

// Add pulsing animation to the tools icon
document.querySelector('.fa-tools').classList.add('maintenance-pulse');
</script>