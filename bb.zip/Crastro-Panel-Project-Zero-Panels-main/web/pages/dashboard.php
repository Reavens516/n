<?php
$page_title = "Dashboard";

// Get user's containers
$user_id = $_SESSION['user_id'];
$is_admin = is_admin();

if ($is_admin) {
    $containers_query = "SELECT c.*, u.username, di.name as image_name 
                        FROM containers c 
                        LEFT JOIN users u ON c.user_id = u.id 
                        LEFT JOIN docker_images di ON c.image_id = di.id 
                        ORDER BY c.created_at DESC LIMIT 10";
    $containers_stmt = $db->query($containers_query);
} else {
    $containers_query = "SELECT c.*, di.name as image_name 
                        FROM containers c 
                        LEFT JOIN docker_images di ON c.image_id = di.id 
                        WHERE c.user_id = ? 
                        ORDER BY c.created_at DESC LIMIT 10";
    $containers_stmt = $db->prepare($containers_query);
    $containers_stmt->execute([$user_id]);
}
$containers = $containers_stmt->fetchAll();

// Get statistics
if ($is_admin) {
    // Admin stats
    $total_containers = $db->query("SELECT COUNT(*) FROM containers")->fetchColumn();
    $running_containers = $db->query("SELECT COUNT(*) FROM containers WHERE status = 'running'")->fetchColumn();
    $stopped_containers = $db->query("SELECT COUNT(*) FROM containers WHERE status = 'stopped'")->fetchColumn();
    $total_users = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $total_images = $db->query("SELECT COUNT(*) FROM docker_images")->fetchColumn();
} else {
    // User stats
    $total_containers = $db->prepare("SELECT COUNT(*) FROM containers WHERE user_id = ?");
    $total_containers->execute([$user_id]);
    $total_containers = $total_containers->fetchColumn();
    
    $running_containers = $db->prepare("SELECT COUNT(*) FROM containers WHERE user_id = ? AND status = 'running'");
    $running_containers->execute([$user_id]);
    $running_containers = $running_containers->fetchColumn();
    
    $stopped_containers = $db->prepare("SELECT COUNT(*) FROM containers WHERE user_id = ? AND status = 'stopped'");
    $stopped_containers->execute([$user_id]);
    $stopped_containers = $stopped_containers->fetchColumn();
    
    $total_users = 1; // Current user
    $total_images = $db->query("SELECT COUNT(*) FROM docker_images")->fetchColumn();
}

// Get system uptime (mock data - would be real system uptime in production)
$uptime = time() - strtotime('2024-01-01'); // Mock uptime since Jan 1, 2024
?>

<div class="container-fluid">
    <div class="row mb-4">
        <div class="col">
            <h1 class="h2 mb-0">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </h1>
            <p class="text-muted">
                Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>! 
                <?php if ($is_admin): ?><span class="badge bg-danger">Administrator</span><?php endif; ?>
            </p>
        </div>
        <div class="col-auto">
            <div class="btn-group">
                <?php if (can_user_create_container($user_id)): ?>
                <a href="?page=create-instance" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Create Instance
                </a>
                <?php endif; ?>
                <button type="button" class="btn btn-outline-primary" onclick="refreshContainerStatus()">
                    <i class="fas fa-sync-alt"></i> Refresh
                </button>
            </div>
        </div>
    </div>
    
    <!-- Alert Container -->
    <div id="alert-container"></div>
    
    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3 mb-3">
            <div class="card stats-card">
                <div class="card-body position-relative">
                    <h5 class="stats-value" id="total-containers"><?php echo $total_containers; ?></h5>
                    <p class="stats-label mb-0">
                        <?php echo $is_admin ? 'Total Containers' : 'My Containers'; ?>
                    </p>
                    <i class="fas fa-server stats-icon"></i>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card stats-card bg-success">
                <div class="card-body position-relative">
                    <h5 class="stats-value" id="running-containers"><?php echo $running_containers; ?></h5>
                    <p class="stats-label mb-0">Running</p>
                    <i class="fas fa-play stats-icon"></i>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card stats-card bg-danger">
                <div class="card-body position-relative">
                    <h5 class="stats-value" id="stopped-containers"><?php echo $stopped_containers; ?></h5>
                    <p class="stats-label mb-0">Stopped</p>
                    <i class="fas fa-stop stats-icon"></i>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-3">
            <div class="card stats-card bg-info">
                <div class="card-body position-relative">
                    <h5 class="stats-value"><?php echo $is_admin ? $total_users : $total_images; ?></h5>
                    <p class="stats-label mb-0"><?php echo $is_admin ? 'Total Users' : 'Available Images'; ?></p>
                    <i class="fas fa-<?php echo $is_admin ? 'users' : 'images'; ?> stats-icon"></i>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row">
        <!-- Recent Containers -->
        <div class="col-lg-8 mb-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="fas fa-list"></i> 
                        <?php echo $is_admin ? 'Recent Containers' : 'My Containers'; ?>
                    </h5>
                    <?php if (!$is_admin): ?>
                    <small class="text-muted">
                        <?php echo $total_containers; ?>/<?php echo MAX_CONTAINERS_PER_USER; ?> containers
                    </small>
                    <?php endif; ?>
                </div>
                <div class="card-body p-0">
                    <?php if (empty($containers)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-server fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">No containers yet</h5>
                        <p class="text-muted">Create your first container to get started!</p>
                        <?php if (can_user_create_container($user_id)): ?>
                        <a href="?page=create-instance" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Create Container
                        </a>
                        <?php endif; ?>
                    </div>
                    <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead class="table-dark">
                                <tr>
                                    <th>Container</th>
                                    <?php if ($is_admin): ?><th>User</th><?php endif; ?>
                                    <th>Image</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($containers as $container): ?>
                                <tr data-container-id="<?php echo $container['id']; ?>">
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-server text-primary me-2"></i>
                                            <div>
                                                <div class="fw-bold"><?php echo htmlspecialchars($container['name']); ?></div>
                                                <small class="text-muted font-monospace"><?php echo substr($container['container_id'] ?? 'pending', 0, 12); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <?php if ($is_admin): ?>
                                    <td>
                                        <span class="badge bg-secondary">
                                            <?php echo htmlspecialchars($container['username'] ?? 'Unknown'); ?>
                                        </span>
                                    </td>
                                    <?php endif; ?>
                                    <td><?php echo htmlspecialchars($container['image_name'] ?? 'Unknown'); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $container['status']; ?>">
                                            <?php echo strtoupper($container['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span data-bs-toggle="tooltip" title="<?php echo $container['created_at']; ?>">
                                            <?php echo date('M j, H:i', strtotime($container['created_at'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group btn-group-sm">
                                            <?php if ($container['status'] === 'running'): ?>
                                                <button class="btn btn-warning btn-stop" onclick="stopContainer(<?php echo $container['id']; ?>)" 
                                                        data-bs-toggle="tooltip" title="Stop Container">
                                                    <i class="fas fa-stop"></i>
                                                </button>
                                                <button class="btn btn-info btn-restart" onclick="restartContainer(<?php echo $container['id']; ?>)" 
                                                        data-bs-toggle="tooltip" title="Restart Container">
                                                    <i class="fas fa-redo"></i>
                                                </button>
                                            <?php else: ?>
                                                <button class="btn btn-success btn-start" onclick="startContainer(<?php echo $container['id']; ?>)" 
                                                        data-bs-toggle="tooltip" title="Start Container">
                                                    <i class="fas fa-play"></i>
                                                </button>
                                            <?php endif; ?>
                                            <a href="?page=container&id=<?php echo $container['id']; ?>" class="btn btn-primary" 
                                               data-bs-toggle="tooltip" title="Manage Container">
                                                <i class="fas fa-cog"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
                <?php if (!empty($containers) && count($containers) >= 10): ?>
                <div class="card-footer text-center">
                    <a href="?page=<?php echo $is_admin ? 'servers' : 'instances'; ?>" class="btn btn-outline-primary">
                        <i class="fas fa-list"></i> View All Containers
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- System Information -->
        <div class="col-lg-4 mb-4">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-info-circle"></i> System Information
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-6">
                            <div class="text-center">
                                <i class="fas fa-clock fa-2x text-primary mb-2"></i>
                                <h6>Uptime</h6>
                                <p class="mb-0"><?php echo format_uptime($uptime); ?></p>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="text-center">
                                <i class="fas fa-server fa-2x text-success mb-2"></i>
                                <h6>Status</h6>
                                <p class="mb-0 text-success">Online</p>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="text-center">
                                <i class="fas fa-code-branch fa-2x text-info mb-2"></i>
                                <h6>Version</h6>
                                <p class="mb-0"><?php echo VERSION; ?></p>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="text-center">
                                <i class="fas fa-user fa-2x text-warning mb-2"></i>
                                <h6>Author</h6>
                                <p class="mb-0"><?php echo AUTHOR; ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-bolt"></i> Quick Actions
                    </h5>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2">
                        <?php if (can_user_create_container($user_id)): ?>
                        <a href="?page=create-instance" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Create New Instance
                        </a>
                        <?php endif; ?>
                        
                        <?php if ($is_admin): ?>
                        <a href="?page=users" class="btn btn-secondary">
                            <i class="fas fa-users"></i> Manage Users
                        </a>
                        <a href="?page=admin-settings" class="btn btn-secondary">
                            <i class="fas fa-cog"></i> Panel Settings
                        </a>
                        <a href="?page=images" class="btn btn-secondary">
                            <i class="fas fa-images"></i> Docker Images
                        </a>
                        <?php endif; ?>
                        
                        <a href="?page=status" class="btn btn-info">
                            <i class="fas fa-chart-line"></i> System Status
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php if ($is_admin): ?>
    <!-- Recent Activity -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="fas fa-history"></i> Recent Activity
                    </h5>
                </div>
                <div class="card-body">
                    <div class="text-center py-4">
                        <i class="fas fa-history fa-3x text-muted mb-3"></i>
                        <h6 class="text-muted">Activity logging will be available soon</h6>
                        <p class="text-muted mb-0">User actions and system events will be displayed here.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
// Page-specific JavaScript
$(document).ready(function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Auto-refresh every 30 seconds
    setInterval(refreshContainerStatus, 30000);
});

// Custom refresh function for dashboard
function refreshContainerStatus() {
    // This would be implemented to refresh the container status
    // For now, we'll just show a loading indicator
    console.log('Refreshing container status...');
}
</script>