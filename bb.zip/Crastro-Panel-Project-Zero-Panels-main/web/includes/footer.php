    <?php if (is_logged_in() && $page !== 'maintenance'): ?>
    </div> <!-- Close main-content -->
    <?php endif; ?>
    
    <!-- Footer -->
    <footer class="footer mt-auto py-3 bg-dark text-light">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <span class="text-muted">© 2024 <?php echo get_setting('company_name', 'Crastro Panel'); ?> v<?php echo VERSION; ?></span>
                </div>
                <div class="col-md-6 text-end">
                    <span class="text-muted">Made with ❤️ by <?php echo AUTHOR; ?></span>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- JavaScript Files -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="assets/js/main.js"></script>
    
    <!-- Snowflake Effect Script -->
    <?php if (get_setting('snowflake_effect') === 'true'): ?>
    <script src="assets/js/snowflakes.js"></script>
    <?php endif; ?>
    
    <!-- Page-specific scripts -->
    <?php if (isset($page_scripts)): ?>
        <?php foreach ($page_scripts as $script): ?>
            <script src="<?php echo $script; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <!-- Inline scripts -->
    <script>
        // Global AJAX setup
        $.ajaxSetup({
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        });
        
        // Auto-refresh container status every 30 seconds
        if (typeof refreshContainerStatus === 'function') {
            setInterval(refreshContainerStatus, 30000);
        }
        
        // Show loading spinner for forms
        $('form').on('submit', function() {
            $(this).find('button[type="submit"]').html('<i class="fas fa-spinner fa-spin"></i> Please wait...');
        });
        
        // Auto-hide alerts after 5 seconds
        setTimeout(function() {
            $('.alert:not(.alert-permanent)').fadeOut();
        }, 5000);
    </script>
    
    <!-- Custom background theme -->
    <?php if (get_setting('theme_background') !== 'default' && !empty(get_setting('theme_background'))): ?>
    <style>
        body.crastro-theme {
            background-image: url('<?php echo htmlspecialchars(get_setting('theme_background')); ?>');
            background-size: cover;
            background-attachment: fixed;
            background-repeat: no-repeat;
        }
        
        .main-content {
            background-color: rgba(0, 0, 0, 0.8);
            min-height: 100vh;
        }
    </style>
    <?php endif; ?>
    
</body>
</html>