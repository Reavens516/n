<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' : ''; ?><?php echo get_setting('company_name', 'Crastro Panel'); ?></title>
    
    <!-- CSS Files -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="assets/images/favicon.ico">
</head>
<body class="crastro-theme">
    <!-- Snowflake Effect -->
    <?php if (get_setting('snowflake_effect') === 'true'): ?>
    <div id="snowflakes-container"></div>
    <?php endif; ?>
    
    <!-- Navigation -->
    <?php if (is_logged_in() && $page !== 'maintenance'): ?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand d-flex align-items-center" href="?page=dashboard">
                <i class="fas fa-server me-2"></i>
                <?php echo get_setting('company_name', 'Crastro Panel'); ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $page === 'dashboard' ? 'active' : ''; ?>" href="?page=dashboard">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>
                    
                    <?php if (is_admin()): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $page === 'servers' ? 'active' : ''; ?>" href="?page=servers">
                            <i class="fas fa-server"></i> Servers
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $page === 'users' ? 'active' : ''; ?>" href="?page=users">
                            <i class="fas fa-users"></i> Users
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <li class="nav-item">
                        <a class="nav-link <?php echo $page === 'create-instance' ? 'active' : ''; ?>" href="?page=create-instance">
                            <i class="fas fa-plus"></i> Create Instance
                        </a>
                    </li>
                    
                    <?php if (is_admin()): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $page === 'admin-settings' ? 'active' : ''; ?>" href="?page=admin-settings">
                            <i class="fas fa-cog"></i> Admin Settings
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $page === 'images' ? 'active' : ''; ?>" href="?page=images">
                            <i class="fas fa-images"></i> Images
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $page === 'proxmox' ? 'active' : ''; ?>" href="?page=proxmox">
                            <i class="fas fa-cloud"></i> Proxmox
                        </a>
                    </li>
                    <?php endif; ?>
                    
                    <li class="nav-item">
                        <a class="nav-link <?php echo $page === 'status' ? 'active' : ''; ?>" href="?page=status">
                            <i class="fas fa-chart-line"></i> Status
                        </a>
                    </li>
                </ul>
                
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['username'] ?? 'User'); ?>
                            <?php if (is_admin()): ?><span class="badge bg-danger ms-1">Admin</span><?php endif; ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="#"><i class="fas fa-user-edit"></i> Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="?page=logout"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    
    <!-- Main Content Container -->
    <div class="main-content">
    <?php endif; ?>
    
    <?php if (!is_logged_in() || $page === 'maintenance'): ?>
    <!-- Login/Maintenance page content will start here -->
    <?php endif; ?>