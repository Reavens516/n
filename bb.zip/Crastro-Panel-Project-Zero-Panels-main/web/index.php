<?php
require_once '../config/config.php';

// Simple routing
$page = $_GET['page'] ?? 'login';

// Check if user is logged in
if (!is_logged_in() && $page !== 'login' && $page !== 'register' && $page !== 'maintenance') {
    header('Location: ?page=login');
    exit();
}

// If logged in and trying to access login page, redirect to dashboard
if (is_logged_in() && $page === 'login') {
    header('Location: ?page=dashboard');
    exit();
}

// Include header
include 'includes/header.php';

// Route to appropriate page
switch ($page) {
    case 'login':
        include 'pages/login.php';
        break;
    case 'dashboard':
        require_login();
        include 'pages/dashboard.php';
        break;
    case 'servers':
        require_admin();
        include 'pages/servers.php';
        break;
    case 'users':
        require_admin();
        include 'pages/users.php';
        break;
    case 'create-instance':
        require_login();
        include 'pages/create-instance.php';
        break;
    case 'admin-settings':
        require_admin();
        include 'pages/admin-settings.php';
        break;
    case 'images':
        require_admin();
        include 'pages/images.php';
        break;
    case 'status':
        require_login();
        include 'pages/status.php';
        break;
    case 'proxmox':
        require_admin();
        include 'pages/proxmox.php';
        break;
    case 'container':
        require_login();
        include 'pages/container.php';
        break;
    case 'maintenance':
        include 'pages/maintenance.php';
        break;
    case 'logout':
        session_destroy();
        header('Location: ?page=login');
        exit();
        break;
    default:
        if (is_logged_in()) {
            header('Location: ?page=dashboard');
        } else {
            header('Location: ?page=login');
        }
        exit();
}

// Include footer
include 'includes/footer.php';
?>