# WARP.md

This file provides guidance to WARP (me.the.warp.dev) when working with code in this repository.

## Project Overview

Crastro Panel is a web-based VPS management panel built with PHP 8.1+ that provides Docker container management through a user-friendly interface. It uses MySQL for data persistence, supports multi-user authentication with admin/user roles, and integrates with external services like tmate for terminal access and serveo.net for port forwarding.

## Development Commands

### Installation & Setup

```bash
# Automated installation (production)
curl -sSL https://raw.githubusercontent.com/yourusername/crastro-panel/main/install.sh | sudo bash

# Development with Docker Compose
docker-compose up -d

# Manual development setup
sudo apt install -y nginx php8.1-fpm php8.1-mysql php8.1-curl mysql-server docker.io tmate
```

### Development Workflow

```bash
# Start development environment
docker-compose up -d

# View container logs
docker-compose logs -f [nginx|php|mysql|redis]

# Stop development environment
docker-compose down

# Rebuild containers after changes
docker-compose up -d --build

# Access MySQL database
mysql -u crastro -p crastro_panel
# Password: crastro_secure_2024

# Check nginx configuration
nginx -t

# Restart services
systemctl restart nginx php8.1-fpm docker
```

### Testing & Debugging

```bash
# Check Docker daemon status
systemctl status docker

# View Docker container logs
docker logs <container_id>

# Test database connection
mysql -u crastro -p crastro_panel

# Monitor PHP-FPM
systemctl status php8.1-fpm

# Check PHP modules
php -m | grep -E "mysql|pdo|curl"
```

## Architecture Overview

### Application Structure

- **Frontend**: Bootstrap 5 + jQuery with dark theme and CSS3 animations
- **Backend**: PHP 8.1 with PDO for database access and procedural/functional programming style
- **Database**: MySQL 8.0 with 5 core tables (users, settings, docker_images, containers, proxmox_nodes)
- **Containerization**: Docker containers managed via Docker socket integration
- **Web Server**: Nginx with PHP-FPM configuration

### Key Components

**Configuration Layer (`config/`)**
- `config.php`: Central configuration with constants, helper functions, and security settings
- `database.php`: PDO database connection class with error handling

**Web Layer (`web/`)**
- `index.php`: Simple router with authentication middleware
- `pages/`: Individual page components (dashboard, login, admin-settings, etc.)
- `includes/`: Shared header and footer templates

**Installation & Deployment**
- `install.sh`: Complete automated installation script with MySQL schema setup
- `docker-compose.yml`: Multi-service development environment

### Authentication & Authorization

The application uses a simple session-based authentication system:

- `is_logged_in()`: Checks for active user session
- `is_admin()`: Verifies admin privileges
- `require_login()` and `require_admin()`: Middleware functions for route protection
- Role-based access control with admin-only sections

### Docker Integration

Container management is handled through direct Docker socket communication:

- **Docker Socket**: `/var/run/docker.sock` mounted in PHP container
- **tmate Integration**: `/usr/bin/tmate` for terminal access to containers
- **Port Forwarding**: serveo.net SSH tunneling for external container access
- **Resource Limits**: Configurable CPU and memory constraints per container

### Database Schema

Core tables structure:
- `users`: Authentication and role management
- `settings`: Dynamic application configuration
- `docker_images`: Custom Docker image templates with Dockerfile storage
- `containers`: Active container tracking with status and metadata
- `proxmox_nodes`: Proxmox VE integration for VM management

### Security Features

- **Password Hashing**: BCrypt with minimum length requirements
- **Input Sanitization**: `sanitize_input()` function for XSS prevention
- **SQL Injection Protection**: PDO prepared statements throughout
- **Session Management**: Timeout controls and maintenance mode support
- **Role-Based Access**: Admin/user separation with proper authorization checks

## Development Guidelines

### Adding New Features

1. **Database Changes**: Update schema in `install.sh` and add migration logic
2. **Route Registration**: Add new cases to the router in `web/index.php`
3. **Page Components**: Create new PHP files in `web/pages/` following existing patterns
4. **Configuration**: Add settings to `$default_settings` array in `config.php`
5. **Authentication**: Use `require_login()` or `require_admin()` as needed

### Docker Management Features

When working with container-related functionality:
- Use the Docker socket path: `DOCKER_SOCKET` constant
- Respect container limits: `MAX_CONTAINERS_PER_USER`
- Implement proper status tracking in the containers table
- Handle tmate session creation and cleanup
- Consider serveo.net integration for port forwarding

### Database Operations

- Always use PDO prepared statements via the global `$db` connection
- Utilize helper functions: `get_setting()`, `set_setting()`, `log_action()`
- Handle database errors gracefully with try/catch blocks
- Follow the existing table relationships for foreign key constraints

### UI/UX Considerations

- Maintain the dark theme aesthetic with Bootstrap 5 classes
- Preserve snowflake effects and animations where appropriate
- Use consistent error/success message patterns
- Ensure mobile responsiveness for all new pages
- Follow the existing navigation structure in header/footer includes
