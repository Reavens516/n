import os

TOKEN = os.environ.get("TOKEN")
NAME = "Zyron-Bot"
server = "https://discord.gg/2Q9FqYubSf"
ch = "https://discord.com/channels/1324668335069331477/1324668336470102143"
OWNER_IDS = [875671806609084428]
BotName = "Zyron-bot"
serverLink = "https://discord.gg/2Q9FqYubSf"
"""
@Author: ! Aegis !
    + Discord: Aegis
    + Community: https://discord.gg/35FqchfVZG (Strelix Studios™)
    + for any queries reach out Community or DM me.
"""
