
def suppress_local_errors(func):
    """Decorator to suppress local error handlers in favor of centralized error handling"""
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            # Silently pass - let centralized error handler deal with it
            pass
    return wrapper

class ErrorSuppressor:
    """Context manager to suppress local error messages"""
    def __init__(self):
        self.suppressed = False
    
    def __enter__(self):
        self.suppressed = True
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            # Suppress the exception by returning True
            return True
        return False

"""
@Author: ! Aegis !
    + Discord: Aegis
    + Community: https://discord.gg/35FqchfVZG (Strelix Studios™)
    + for any queries reach out Community or DM me.
"""
