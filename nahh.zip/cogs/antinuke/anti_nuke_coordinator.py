# This file has been removed as it was causing issues with the antinuke system
# The antinuke modules will work independently without coordination
pass
"""
@Author: ! Aegis !
    + Discord: Aegis
    + Community: https://discord.gg/35FqchfVZG (Strelix Studios™)
    + for any queries reach out Community or DM me.
"""
