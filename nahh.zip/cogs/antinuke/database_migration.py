
import aiosqlite
import asyncio

async def migrate_whitelist_table():
    """Migrate whitelist table to include all necessary columns"""
    try:
        async with aiosqlite.connect('db/anti.db') as db:
            # Add missing columns if they don't exist
            columns_to_add = [
                'rlcr BOOLEAN DEFAULT 0',
                'rldl BOOLEAN DEFAULT 0', 
                'rlup BOOLEAN DEFAULT 0',
                'mngweb BOOLEAN DEFAULT 0',
                'prune BOOLEAN DEFAULT 0'
            ]
            
            for column in columns_to_add:
                try:
                    await db.execute(f'ALTER TABLE whitelisted_users ADD COLUMN {column}')
                except:
                    # Column already exists, skip
                    pass
            
            await db.commit()
            print("Database migration completed successfully")
    except Exception as e:
        print(f"Database migration error: {e}")

# Run migration on import
asyncio.create_task(migrate_whitelist_table())

"""
@Author: ! Aegis !
    + Discord: Aegis
    + Community: https://discord.gg/35FqchfVZG (Strelix Studios™)
    + for any queries reach out Community or DM me.
"""
