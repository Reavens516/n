import discord
from discord.ext import commands
from typing import Union
from utils.Tools import *
from db.economy import EconomyDatabase
import random
import asyncio
import os
from typing import List, Tuple, Union
from PIL import Image, ImageDraw, ImageFont
from utils.Tools import *
from datetime import datetime, timedelta
import aiohttp
import io
import requests
from utils.economy_help_view import EconomyHelpView

CARDS_PATH = 'data/cards/'

# Job System Data
JOB_TYPES = {
    'intern': {
        'name': 'Intern',
        'base_pay': (50, 150),
        'requirements': {'experience': 0, 'education': 0},
        'emoji': '📋',
        'description': 'Entry level position with basic tasks'
    },
    'cashier': {
        'name': 'Cashier',
        'base_pay': (100, 250),
        'requirements': {'experience': 0, 'education': 0},
        'emoji': '💰',
        'description': 'Handle customer transactions'
    },
    'programmer': {
        'name': 'Programmer',
        'base_pay': (300, 800),
        'requirements': {'experience': 5, 'education': 2},
        'emoji': '💻',
        'description': 'Develop software applications'
    },
    'manager': {
        'name': 'Manager',
        'base_pay': (500, 1200),
        'requirements': {'experience': 10, 'education': 3},
        'emoji': '👔',
        'description': 'Lead teams and make decisions'
    },
    'doctor': {
        'name': 'Doctor',
        'base_pay': (800, 2000),
        'requirements': {'experience': 20, 'education': 8},
        'emoji': '👩‍⚕️',
        'description': 'Provide medical care to patients'
    },
    'ceo': {
        'name': 'CEO',
        'base_pay': (1500, 5000),
        'requirements': {'experience': 50, 'education': 10},
        'emoji': '🎩',
        'description': 'Run a major corporation'
    }
}

# Stock Market Data
STOCK_COMPANIES = {
    'TECH': {
        'name': 'TechCorp Industries',
        'sector': 'Technology',
        'base_price': 2500,
        'volatility': 0.15,
        'emoji': '💻'
    },
    'FOOD': {
        'name': 'FoodChain Co.',
        'sector': 'Food & Beverage',
        'base_price': 1850,
        'volatility': 0.10,
        'emoji': '🍔'
    },
    'AUTO': {
        'name': 'AutoDrive Motors',
        'sector': 'Automotive',
        'base_price': 3200,
        'volatility': 0.20,
        'emoji': '🚗'
    },
    'BANK': {
        'name': 'MegaBank Corp',
        'sector': 'Financial',
        'base_price': 4500,
        'volatility': 0.12,
        'emoji': '🏦'
    },
    'MEDI': {
        'name': 'HealthPlus Medical',
        'sector': 'Healthcare',
        'base_price': 2800,
        'volatility': 0.08,
        'emoji': '🏥'
    },
    'GAME': {
        'name': 'GameStudio Entertainment',
        'sector': 'Gaming',
        'base_price': 1600,
        'volatility': 0.25,
        'emoji': '🎮'
    }
}

# Cryptocurrency Data
CRYPTO_CURRENCIES = {
    'BTC': {
        'name': 'Bitcoin',
        'base_price': 45000,
        'volatility': 0.08,
        'emoji': '₿',
        'market_cap': 850000000000
    },
    'ETH': {
        'name': 'Ethereum', 
        'base_price': 3200,
        'volatility': 0.12,
        'emoji': '⟠',
        'market_cap': 380000000000
    },
    'ADA': {
        'name': 'Cardano',
        'base_price': 0.65,
        'volatility': 0.15,
        'emoji': '🔷',
        'market_cap': 22000000000
    },
    'DOGE': {
        'name': 'Dogecoin',
        'base_price': 0.08,
        'volatility': 0.25,
        'emoji': '🐕',
        'market_cap': 11000000000
    },
    'SOL': {
        'name': 'Solana',
        'base_price': 125,
        'volatility': 0.20,
        'emoji': '◎',
        'market_cap': 55000000000
    },
    'DOT': {
        'name': 'Polkadot',
        'base_price': 7.50,
        'volatility': 0.18,
        'emoji': '⚫',
        'market_cap': 9000000000
    }
}

# Zoo System Data
ZOO_ANIMALS = {
    'common': {
        '🐝': {'name': 'bee', 'hp': 45, 'attack': 12, 'price': 5},
        '🐌': {'name': 'snail', 'hp': 38, 'attack': 8, 'price': 4},
        '🐛': {'name': 'bug', 'hp': 42, 'attack': 10, 'price': 5},
        '🪲': {'name': 'beetle', 'hp': 48, 'attack': 14, 'price': 6},
        '🦋': {'name': 'butterfly', 'hp': 35, 'attack': 16, 'price': 7},
    },
    'uncommon': {
        '🐤': {'name': 'chick', 'hp': 65, 'attack': 22, 'price': 15},
        '🐭': {'name': 'mouse', 'hp': 58, 'attack': 18, 'price': 12},
        '🐓': {'name': 'chicken', 'hp': 72, 'attack': 25, 'price': 18},
        '🐰': {'name': 'rabbit', 'hp': 68, 'attack': 20, 'price': 16},
        '🐿️': {'name': 'squirrel', 'hp': 62, 'attack': 24, 'price': 17},
    },
    'rare': {
        '🐑': {'name': 'sheep', 'hp': 95, 'attack': 35, 'price': 45},
        '🐖': {'name': 'pig', 'hp': 105, 'attack': 38, 'price': 50},
        '🐄': {'name': 'cow', 'hp': 125, 'attack': 42, 'price': 60},
        '🐕': {'name': 'dog', 'hp': 88, 'attack': 45, 'price': 55},
        '🐈': {'name': 'cat', 'hp': 82, 'attack': 48, 'price': 58},
    },
    'epic': {
        '🐊': {'name': 'crocodile', 'hp': 180, 'attack': 72, 'price': 150},
        '🦁': {'name': 'lion', 'hp': 165, 'attack': 85, 'price': 180},
        '🐻': {'name': 'bear', 'hp': 195, 'attack': 78, 'price': 170},
        '🐺': {'name': 'wolf', 'hp': 155, 'attack': 88, 'price': 185},
        '🐅': {'name': 'tiger', 'hp': 170, 'attack': 92, 'price': 200},
    },
    'mythic': {
        '🐉': {'name': 'dragon', 'hp': 350, 'attack': 150, 'price': 500},
        '🦄': {'name': 'unicorn', 'hp': 280, 'attack': 125, 'price': 450},
        '🐲': {'name': 'dragon2', 'hp': 385, 'attack': 165, 'price': 550},
        '🦅': {'name': 'eagle', 'hp': 245, 'attack': 135, 'price': 475},
        '🐼': {'name': 'panda', 'hp': 265, 'attack': 120, 'price': 425},
    }
}

RARITY_COLORS = {
    'common': '🟢',
    'uncommon': '🔵', 
    'rare': '🟣',
    'epic': '🟠',
    'mythic': '🔴'
}

HUNT_RATES = {
    'common': 60,
    'uncommon': 25,
    'rare': 10,
    'epic': 4,
    'mythic': 1
}

class Card:
    suits = ["clubs", "diamonds", "hearts", "spades"]

    def __init__(self, suit: str, value: int, down=False):
        self.suit = suit
        self.value = value
        self.down = down
        self.symbol = self.name[0].upper()

    @property
    def name(self) -> str:
        if self.value <= 10:
            return str(self.value)
        else:
            return {
                11: 'jack',
                12: 'queen',
                13: 'king',
                14: 'ace',
            }[self.value]

    @property
    def image(self):
        return (
            f"{self.symbol if self.name != '10' else '10'}" \
            f"{self.suit[0].upper()}.png" \
            if not self.down else "red_back.png"
        )

    def flip(self):
        self.down = not self.down
        return self

    def __str__(self) -> str:
        return f'{self.name.title()} of {self.suit.title()}'

    def __repr__(self) -> str:
        return str(self)

class Economy(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.db = EconomyDatabase()
        self.coinflip_cooldowns = {}  # Store user cooldowns
        self.economy_prefixes = {}  # Store custom prefixes per guild
        self.bot.loop.create_task(self.setup_database())
        self.bot.loop.create_task(self.stock_price_updater())

    async def setup_database(self):
        await self.db.connect()
        await self.load_economy_prefixes()

    @staticmethod
    def hand_to_images(hand: List[Card]) -> List[Image.Image]:
        return [Image.open(os.path.join(CARDS_PATH, card.image)) for card in hand]

    @staticmethod
    def center(*hands: Tuple[Image.Image]) -> Image.Image:
        bg: Image.Image = Image.open(os.path.join(CARDS_PATH, 'table.png'))
        bg_center_x = bg.size[0] // 2
        bg_center_y = bg.size[1] // 2

        img_w = hands[0][0].size[0]
        img_h = hands[0][0].size[1]

        start_y = bg_center_y - (((len(hands) * img_h) + ((len(hands) - 1) * 15)) // 2)

        for hand in hands:
            start_x = bg_center_x - (((len(hand) * img_w) + ((len(hand) - 1) * 10)) // 2)
            for card in hand:
                bg.alpha_composite(card, (start_x, start_y))
                start_x += img_w + 10
            start_y += img_h + 15

        return bg

    def output(self, name, *hands: Tuple[List[Card]]) -> None:
        self.center(*map(self.hand_to_images, hands)).save(f'data/{name}.png')

    @staticmethod
    def calc_hand(hand: List[Card]) -> int:
        non_aces = [c for c in hand if c.symbol != 'A']
        aces = [c for c in hand if c.symbol == 'A']
        total_sum = 0
        for card in non_aces:
            if not card.down:
                if card.symbol in 'JQK':
                    total_sum += 10
                else:
                    total_sum += card.value
        for card in aces:
            if not card.down:
                if total_sum <= 10:
                    total_sum += 11
                else:
                    total_sum += 1
        return total_sum

    @commands.command(name='cash', aliases=['cowoncy'])
    async def cash(self, ctx, user: discord.Member = None):
        """Check cowoncy balance (yours or another user's)"""
        target_user = user or ctx.author
        user_balance = await self.db.get_user_balance(target_user.id)

        message = f"<:cowoncy:1385212758919745608> **| {target_user.display_name}**, you currently have **__{user_balance:,}__ cowoncy!**" if target_user == ctx.author else f"<:cowoncy:1385212758919745608> **| {target_user.display_name}** currently has **__{user_balance:,}__ cowoncy!**"

        await ctx.send(message)

    @commands.group(name='sys', invoke_without_command=True)
    async def sys(self, ctx):
        """Economy system commands"""
        try:
            print(f"[DEBUG] sys command invoked by {ctx.author} in {ctx.guild}")
            print(f"[DEBUG] Invoked subcommand: {ctx.invoked_subcommand}")
            if ctx.invoked_subcommand is None:
                print("[DEBUG] No subcommand, showing main help")
                # Show the same help as sys help
                await self._show_main_help(ctx)
                return
        except Exception as e:
            print(f"[ERROR] Exception in sys command: {type(e).__name__}: {str(e)}")
            import traceback
            print(f"[ERROR] Full traceback:")
            traceback.print_exc()
            raise

    async def _show_main_help(self, ctx):
        """Show the main economy help embed"""
        try:
            print(f"[DEBUG] _show_main_help called for guild {ctx.guild.id}")
            # Get the current economy prefix for this guild
            current_prefix = self.economy_prefixes.get(ctx.guild.id, "sys")
            print(f"[DEBUG] Current prefix: {current_prefix}")
        except Exception as e:
            print(f"[ERROR] Exception in _show_main_help: {type(e).__name__}: {str(e)}")
            import traceback
            traceback.print_exc()
            raise
        
        embed = discord.Embed(
            title="<:cowoncy:1385212758919745608> Economy System Commands",
            description=f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nAll economy commands available in this server.",
            color=0x000000
        )
        
        # Currency Commands
        embed.add_field(
            name="<:icon_categories:1372375027340804176> **Currency Commands**",
            value=f"`{current_prefix} cash [user]` - Check cowoncy balance\n"
                  f"`{current_prefix} give <amount> <user>` - Give cowoncy to another user\n"
                  f"`{current_prefix} baltop` - View server wealth leaderboard\n"
                  f"`{current_prefix} cookie [user]` - Give or check cookies",
            inline=False
        )
        
        # Earning Commands
        embed.add_field(
            name="💼 **Earning Commands**",
            value=f"`{current_prefix} work` - Work jobs for cowoncy (1h cooldown)\n"
                  f"`{current_prefix} beg` - Beg for cowoncy (30min cooldown)\n"
                  f"`{current_prefix} daily` - Daily reward with streaks\n"
                  f"`{current_prefix} trivia` - Answer questions for rewards\n"
                  f"`{current_prefix} lottery` - Buy lottery tickets",
            inline=False
        )
        
        # Banking Commands
        embed.add_field(
            name="🏦 **Banking Commands**",
            value=f"`{current_prefix} bank` - Secure banking with interest\n"
                  f"`{current_prefix} bank deposit <amount>` - Store cowoncy safely\n"
                  f"`{current_prefix} bank withdraw <amount>` - Take out cowoncy",
            inline=False
        )
        
        # Gambling Commands
        embed.add_field(
            name="🎰 **Gambling Commands**",
            value=f"`{current_prefix} slots <amount>` - Play slot machine\n"
                  f"`{current_prefix} coinflip <amount> [choice]` - Flip a coin\n"
                  f"`{current_prefix} blackjack <amount>` - Play blackjack",
            inline=False
        )
        
        # Shop & Items
        embed.add_field(
            name="🛒 **Shop & Items**",
            value=f"`{current_prefix} shop` - View the ring shop\n"
                  f"`{current_prefix} buy <id>` - Buy a ring from shop\n"
                  f"`{current_prefix} sell <id>` - Sell a ring for 75% price\n"
                  f"`{current_prefix} inventory [user]` - Check inventory",
            inline=False
        )
        
        # Social Commands
        embed.add_field(
            name="💕 **Social Commands**",
            value=f"`{current_prefix} marry <user> <ring_id>` - Propose to someone\n"
                  f"`{current_prefix} pray [user]` - Pray for luck points\n"
                  f"`{current_prefix} curse <user>` - Curse someone to steal luck",
            inline=False
        )
        
        # Job System Commands
        embed.add_field(
            name="💼 **Job System Commands**",
            value=f"`{current_prefix} job` - View job center and career info\n"
                  f"`{current_prefix} job apply <job>` - Apply for a job\n"
                  f"`{current_prefix} job work` - Work your current job\n"
                  f"`{current_prefix} job study` - Study to increase education",
            inline=False
        )
        
        # Stock Market Commands
        embed.add_field(
            name="📈 **Stock Market Commands**",
            value=f"`{current_prefix} stocks` - View market and portfolio\n"
                  f"`{current_prefix} stocks buy <symbol> <amount>` - Buy stocks\n"
                  f"`{current_prefix} stocks sell <symbol> <amount>` - Sell stocks\n"
                  f"`{current_prefix} stocks graph <symbol>` - View price chart",
            inline=False
        )
        
        # Job System Commands
        embed.add_field(
            name="💼 **Job System Commands**",
            value=f"`{current_prefix} job` - View job center and career info\n"
                  f"`{current_prefix} job list` - View all available jobs\n"
                  f"`{current_prefix} job apply <job>` - Apply for a job\n"
                  f"`{current_prefix} job work` - Work your current job (2h cooldown)\n"
                  f"`{current_prefix} job quit` - Quit your current job\n"
                  f"`{current_prefix} job study` - Study to increase education (6h cooldown)",
            inline=False
        )
        
        # Zoo System Commands
        embed.add_field(
            name="🦁 **Zoo System Commands**",
            value=f"`{current_prefix} zoo [user]` - View your zoo collection\n"
                  f"`{current_prefix} hunt` - Hunt for animals\n"
                  f"`{current_prefix} sell <animal>` - Sell animals for cowoncy",
            inline=False
        )
        
        # Utility Commands
        embed.add_field(
            name="⚙️ **Utility Commands**",
            value=f"`{current_prefix} emoji <emoji>` - Enlarge and show emoji info\n"
                  f"`{current_prefix} sysify <text>` - Transform text into cute SyS style\n"
                  f"`{current_prefix} avatar [user]` - Show user's avatar in high quality\n"
                  f"`{current_prefix} prefix <new_prefix>` - Change economy prefix (Admin only)",
            inline=False
        )
        
        # Emotes Category
        embed.add_field(
            name="😊 **Emotes**",
            value=f"`{current_prefix} blush` - Blush adorably\n"
                  f"`{current_prefix} hug [user]` - Hug someone sweetly\n"
                  f"`{current_prefix} kiss [user]` - Kiss someone lovingly\n"
                  f"`{current_prefix} pat [user]` - Pat someone gently\n"
                  f"`{current_prefix} cuddle [user]` - Cuddle someone warmly\n"
                  f"`{current_prefix} cry` - Shed some tears\n"
                  f"`{current_prefix} dance` - Dance with joy\n"
                  f"`{current_prefix} lewd` - Act lewd\n"
                  f"`{current_prefix} pout` - Pout cutely\n"
                  f"`{current_prefix} shrug` - Shrug casually\n"
                  f"`{current_prefix} sleepy` - Feel drowsy\n"
                  f"`{current_prefix} smile` - Smile brightly\n"
                  f"`{current_prefix} smug` - Act smug\n"
                  f"`{current_prefix} thumbsup` - Give thumbs up\n"
                  f"`{current_prefix} wag` - Wag tail happily\n"
                  f"`{current_prefix} thinking` - Think deeply\n"
                  f"`{current_prefix} triggered` - Feel triggered\n"
                  f"`{current_prefix} teehee` - Giggle cutely\n"
                  f"`{current_prefix} deredere` - Be lovey-dovey\n"
                  f"`{current_prefix} thonking` - Think really hard\n"
                  f"`{current_prefix} scoff` - Scoff dismissively\n"
                  f"`{current_prefix} happy` - Feel happy\n"
                  f"`{current_prefix} thumbs` - Show approval\n"
                  f"`{current_prefix} grin` - Grin widely",
            inline=False
        )
        
        # Actions Category
        embed.add_field(
            name="🤝 **Actions**",
            value=f"`{current_prefix} cuddle [user]` - Cuddle warmly\n"
                  f"`{current_prefix} hug [user]` - Hug someone sweetly\n"
                  f"`{current_prefix} kiss [user]` - Kiss lovingly\n"
                  f"`{current_prefix} lick [user]` - Lick playfully\n"
                  f"`{current_prefix} nom [user]` - Nom gently\n"
                  f"`{current_prefix} pat [user]` - Pat someone\n"
                  f"`{current_prefix} poke [user]` - Poke gently\n"
                  f"`{current_prefix} slap [user]` - Slap playfully\n"
                  f"`{current_prefix} stare [user]` - Stare intensely\n"
                  f"`{current_prefix} highfive [user]` - High five\n"
                  f"`{current_prefix} bite [user]` - Bite playfully\n"
                  f"`{current_prefix} greet [user]` - Greet warmly\n"
                  f"`{current_prefix} punch [user]` - Punch playfully\n"
                  f"`{current_prefix} handholding [user]` - Hold hands\n"
                  f"`{current_prefix} tickle [user]` - Tickle playfully\n"
                  f"`{current_prefix} kill [user]` - Defeat dramatically\n"
                  f"`{current_prefix} hold [user]` - Hold closely\n"
                  f"`{current_prefix} pats [user]` - Give gentle pats\n"
                  f"`{current_prefix} wave [user]` - Wave at someone\n"
                  f"`{current_prefix} boop [user]` - Boop nose\n"
                  f"`{current_prefix} snuggle [user]` - Snuggle warmly\n"
                  f"`{current_prefix} bully [user]` - Playfully bully",
            inline=False
        )
        
        # Aliases
        embed.add_field(
            name="🔗 **Command Aliases**",
            value="`slots` → `s` | `coinflip` → `cf` | `blackjack` → `bj` | `inventory` → `inv` | `cash` → `cowoncy` | `avatar` → `av` | `hunt` → `h`",
            inline=False
        )
        
        embed.set_author(
            name=f"{ctx.author.display_name}'s Economy Help",
            icon_url=ctx.author.display_avatar.url
        )
        
        embed.set_footer(
            text=f"Current prefix: {current_prefix} | Use {current_prefix} help <command> for detailed info",
            icon_url=ctx.bot.user.display_avatar.url
        )
        
        embed.set_thumbnail(url=ctx.bot.user.display_avatar.url)
        
        await ctx.send(embed=embed)

    @sys.command(name='cash', aliases=['cowoncy'])
    async def sys_cash(self, ctx, user: discord.Member = None):
        """Check cowoncy balance (yours or another user's)"""
        target_user = user or ctx.author
        user_balance = await self.db.get_user_balance(target_user.id)

        message = f"<:cowoncy:1385212758919745608> **| {target_user.display_name}**, you currently have **__{user_balance:,}__ cowoncy!**" if target_user == ctx.author else f"<:cowoncy:1385212758919745608> **| {target_user.display_name}** currently has **__{user_balance:,}__ cowoncy!**"

        await ctx.send(message)

    @sys.command(name='give')
    async def sys_give(self, ctx, amount: int = None, user: discord.Member = None):
        """Give cowoncy to another user"""
        if amount is None or user is None:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid arguments! >:c", delete_after=3)

        if amount <= 0:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must give a positive amount!", delete_after=3)

        if user == ctx.author:
            return await ctx.send(f"**💳 | {ctx.author.mention}** sent **{amount:,} cowoncy** to... **{ctx.author.mention}**... *but... why?*", delete_after=3)

        # Check if sender has enough cowoncy
        sender_balance = await self.db.get_user_balance(ctx.author.id)
        if sender_balance < amount:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have enough cowoncy!", delete_after=3)

        # Create confirmation embed
        embed = discord.Embed(
            description=f"To confirm this transaction, click <:icon_tick:1372375089668161597> Confirm.\n"
                       f"To cancel this transaction, click ❎ Cancel.\n\n"
                       f"<:icon_danger:1372375135604047902> *It is against our rules to trade cowoncy for anything of monetary value. This includes real money, crypto, nitro, or anything similar. You will be* ***banned*** *for doing so.*\n\n"
                       f"**{ctx.author.mention} will give {user.mention}:**\n"
                       f"```fix\n{amount:,} cowoncy                                                               \n```",
            color=0x000000
        )
        embed.set_author(name=f"{ctx.author.display_name}, you are about to give cowoncy to {user.display_name}", icon_url=ctx.author.display_avatar.url)
        embed.set_footer(text=f"Current time")
        embed.timestamp = discord.utils.utcnow()

        # Create buttons
        confirm_button = discord.ui.Button(label="<:icon_tick:1372375089668161597> Confirm", style=discord.ButtonStyle.green)
        cancel_button = discord.ui.Button(label="❎ Cancel", style=discord.ButtonStyle.red)

        async def confirm_callback(interaction):
            if interaction.user != ctx.author:
                return await interaction.response.send_message("Only the sender can confirm this transaction!", ephemeral=True)

            # Process the transaction
            sender_balance = await self.db.get_user_balance(ctx.author.id)
            receiver_balance = await self.db.get_user_balance(user.id)

            # Update balances
            await self.db.update_user_balance(ctx.author.id, sender_balance - amount)
            await self.db.update_user_balance(user.id, receiver_balance + amount)

            # Edit message to show completion
            await interaction.response.edit_message(
                content=f"**💳 | {ctx.author.mention}** sent **{amount:,} cowoncy** to **{user.mention}**!",
                embed=None,
                view=None
            )

        async def cancel_callback(interaction):
            if interaction.user != ctx.author:
                return await interaction.response.send_message("Only the sender can cancel this transaction!", ephemeral=True)

            await interaction.response.edit_message(
                content=f"{ctx.author.mention} declined the transaction :+(",
                embed=None,
                view=None
            )

        confirm_button.callback = confirm_callback
        cancel_button.callback = cancel_callback

        view = discord.ui.View(timeout=60)
        view.add_item(confirm_button)
        view.add_item(cancel_button)

        await ctx.send(embed=embed, view=view)

    @commands.command(name='addcowoncy')
    async def add_cowoncy(self, ctx, user: discord.Member, amount: int):
        """Admin command to add cowoncy to a user (restricted to specific user)"""
        # Restrict to specific user only
        if ctx.author.id != 1124248109472550993:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have permission to use this command!", delete_after=3)

        if amount <= 0:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, amount must be positive!", delete_after=3)

        # Get current balance and add the amount
        current_balance = await self.db.get_user_balance(user.id)
        new_balance = current_balance + amount

        # Update the balance
        await self.db.update_user_balance(user.id, new_balance)

        await ctx.send(f"**💰 | Successfully added {amount:,} cowoncy to {user.display_name}!**\n"
                      f"Previous balance: {current_balance:,}\n"
                      f"New balance: {new_balance:,}")

    @sys.command(name='slots', aliases=['s'])
    async def sys_slots(self, ctx, amount: int = None):
        """Play slots with cowoncy"""
        if amount is None:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must specify an amount to bet!", delete_after=3)

        if amount <= 0:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must bet a positive amount!", delete_after=3)

        # Check maximum bet limit
        MAX_BET = 250000
        if amount > MAX_BET:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, maximum bet amount is {MAX_BET:,} cowoncy!", delete_after=3)

        # Check if user has enough cowoncy
        user_balance = await self.db.get_user_balance(ctx.author.id)
        if user_balance < amount:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have enough cowoncy! You have {user_balance:,} cowoncy.", delete_after=3)

        # Slot machine emojis
        slot_emojis = ['🍎', '🍊', '🍋', '🍇', '🍒', '🥝']

        # Create initial spinning message
        spinning_frames = [
            "🎰 **___SLOTS___** 🎰\n` ` 🎲 🎲 🎲 ` ` **Rolling...**",
            "🎰 **___SLOTS___** 🎰\n` ` 🎯 🎯 🎯 ` ` **Rolling...**",
            "🎰 **___SLOTS___** 🎰\n` ` ⚡ ⚡ ⚡ ` ` **Rolling...**"
        ]

        # Send initial message
        message = await ctx.send(spinning_frames[0])

        # Animate the spinning
        for frame in spinning_frames:
            await asyncio.sleep(0.6)
            await message.edit(content=frame)

        # Generate slot results
        slot1 = random.choice(slot_emojis)
        slot2 = random.choice(slot_emojis)
        slot3 = random.choice(slot_emojis)

        # Get user's luck points and apply luck bonus
        user_luck = await self.db.get_user_luck(ctx.author.id)
        luck_bonus = min(user_luck * 0.3, 8)  # Max 8% bonus for jackpots

        # Apply luck bonus by giving small chance to force a win
        if random.uniform(0, 100) <= luck_bonus:
            # Force a small win (two matching)
            if slot1 != slot2 and slot1 != slot3 and slot2 != slot3:
                slot2 = slot1  # Make two match

        # Check for wins
        winnings = 0
        win_message = ""

        if slot1 == slot2 == slot3:
            # Jackpot - all three match
            if slot1 == '🍒':  # Cherry jackpot
                winnings = amount * 10
                win_message = "🎉 **CHERRY JACKPOT!** 🍒🍒🍒"
            elif slot1 == '🍇':  # Grape jackpot
                winnings = amount * 8
                win_message = "💜 **GRAPE JACKPOT!** 🍇🍇🍇"
            elif slot1 == '🍋':  # Lemon jackpot
                winnings = amount * 6
                win_message = "💛 **LEMON JACKPOT!** 🍋🍋🍋"
            elif slot1 == '🍎':  # Apple jackpot
                winnings = amount * 7
                win_message = "❤️ **APPLE JACKPOT!** 🍎🍎🍎"
            elif slot1 == '🍊':  # Orange jackpot
                winnings = amount * 5
                win_message = "🧡 **ORANGE JACKPOT!** 🍊🍊🍊"
            else:  # Kiwi jackpot
                winnings = amount * 4
                win_message = "💚 **KIWI JACKPOT!** 🥝🥝🥝"
        elif slot1 == slot2 or slot2 == slot3 or slot1 == slot3:
            # Two matching
            winnings = amount * 2
            win_message = "✨ **TWO MATCH!** ✨"
        else:
            # No match - lose bet
            winnings = -amount
            win_message = "💸 **NO MATCH!** Better luck next time!"

        # Update user balance
        new_balance = user_balance + winnings
        await self.db.update_user_balance(ctx.author.id, new_balance)

        # Create final result message
        if winnings > 0:
            result_text = f"and won <:cowoncy:1385212758919745608> **{winnings:,}**"
        else:
            result_text = f"and lost <:cowoncy:1385212758919745608> **{abs(winnings):,}**"

        final_message = (
            f"🎰 **___SLOTS___** 🎰\n"
            f"` ` {slot1} {slot2} {slot3} ` ` **{ctx.author.display_name}** bet <:cowoncy:1385212758919745608> **{amount:,}**\n"
            f"  `|         |`   {result_text}\n"
            f"  `|         |`\n\n"
            f"{win_message}"
        )

        await message.edit(content=final_message)

    @sys.command(name='coinflip', aliases=['cf'])
    async def sys_coinflip(self, ctx, amount: int = None, choice: str = "heads"):
        """Flip a coin and bet on heads or tails"""
        # Check cooldown
        user_id = ctx.author.id
        current_time = asyncio.get_event_loop().time()

        if user_id in self.coinflip_cooldowns:
            time_left = self.coinflip_cooldowns[user_id] - current_time
            if time_left > 0:
                import time
                next_use_time = int(time.time() + time_left)
                cooldown_msg = f"**⏱ | {ctx.author.display_name}**! Slow down and try the command again **<t:{next_use_time}:R>**"
                return await ctx.send(cooldown_msg, delete_after=int(time_left))

        if amount is None:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must specify an amount to bet!", delete_after=3)

        if amount <= 0:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must bet a positive amount!", delete_after=3)

        # Check maximum bet limit
        MAX_BET = 250000
        if amount > MAX_BET:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, maximum bet amount is {MAX_BET:,} cowoncy!", delete_after=3)

        # Check if user has enough cowoncy
        user_balance = await self.db.get_user_balance(ctx.author.id)
        if user_balance < amount:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have enough cowoncy! You have {user_balance:,} cowoncy.", delete_after=3)

        # Normalize choice input
        choice = choice.lower()
        if choice in ['t', 'tail', 'tails']:
            user_choice = 'tails'
            user_choice_display = 'tails'
        elif choice in ['h', 'head', 'heads']:
            user_choice = 'heads'
            user_choice_display = 'heads'
        else:
            # Default to heads if invalid input
            user_choice = 'heads'
            user_choice_display = 'heads'

        # Send initial spinning message
        initial_message = f"**{ctx.author.display_name}** spent **<:cowoncy:1385212758919745608> {amount:,}** and chose **{user_choice_display}**\nThe coin spins... <a:coin:1385235000437510196>"
        message = await ctx.send(initial_message)

        # Wait for spinning animation
        await asyncio.sleep(1)

        # Get user's luck points and apply luck bonus
        user_luck = await self.db.get_user_luck(ctx.author.id)
        luck_bonus = min(user_luck * 0.5, 10)  # Max 10% bonus

        # Base 50% chance + luck bonus
        win_chance = 50 + luck_bonus
        random_roll = random.uniform(0, 100)

        # Determine result based on luck-modified chance
        if random_roll <= win_chance:
            coin_result = user_choice  # User wins
        else:
            coin_result = 'tails' if user_choice == 'heads' else 'heads'  # User loses

        # Check if user won
        if user_choice == coin_result:
            # User won - double their bet
            winnings = amount * 2
            new_balance = user_balance + amount  # They get their bet back plus winnings

            if coin_result == 'heads':
                result_emoji = '<:heads:1385235448003039273>'
            else:
                result_emoji = '<a:tails_coin:1385235523890581575>'

            final_message = (
                f"**{ctx.author.display_name}** spent **<:cowoncy:1385212758919745608> {amount:,}** and chose **{user_choice_display}**\n"
                f"The coin spins... {result_emoji} and you won **<:cowoncy:1385212758919745608> {winnings:,}**!!"
            )
        else:
            # User lost
            new_balance = user_balance - amount

            if coin_result == 'heads':
                result_emoji = '<:heads:1385235448003039273>'
            else:
                result_emoji = '<a:tails_coin:1385235523890581575>'

            final_message = (
                f"**{ctx.author.display_name}** spent **<:cowoncy:1385212758919745608> {amount:,}** and chose **{user_choice_display}**\n"
                f"The coin spins... {result_emoji} and you lost it all... :c"
            )

        # Update user balance
        await self.db.update_user_balance(ctx.author.id, new_balance)

        # Show final result
        await message.edit(content=final_message)

        # Set cooldown for 10 seconds
        self.coinflip_cooldowns[user_id] = current_time + 10

    @sys.command(name='blackjack', aliases=['bj'])
    async def sys_blackjack(self, ctx, amount: int = None):
        """Play blackjack with cowoncy"""
        if amount is None:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must specify an amount to bet!", delete_after=3)

        if amount <= 0:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must bet a positive amount!", delete_after=3)

        # Check maximum bet limit
        MAX_BET = 250000
        if amount > MAX_BET:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, maximum bet amount is {MAX_BET:,} cowoncy!", delete_after=3)

        # Check if user has enough cowoncy
        user_balance = await self.db.get_user_balance(ctx.author.id)
        if user_balance < amount:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have enough cowoncy! You have {user_balance:,} cowoncy.", delete_after=3)

        try:
            deck = [Card(suit, num) for num in range(2, 15) for suit in Card.suits]
            random.shuffle(deck)

            # Get user's luck points for potential bonuses
            user_luck = await self.db.get_user_luck(ctx.author.id)
            luck_bonus = min(user_luck * 0.2, 5)  # Max 5% bonus

            player_hand: List[Card] = []
            dealer_hand: List[Card] = []

            player_hand.append(deck.pop())
            dealer_hand.append(deck.pop())
            player_hand.append(deck.pop())
            dealer_hand.append(deck.pop())

            dealer_hand[1] = dealer_hand[1].flip() 

            player_score = self.calc_hand(player_hand)
            dealer_score = self.calc_hand(dealer_hand)

            async def out_table(**kwargs) -> discord.Message:
                self.output(ctx.author.id, dealer_hand, player_hand)
                embed = discord.Embed(**kwargs)
                embed.add_field(name="💰 Bet Amount", value=f"<:cowoncy:1385212758919745608> {amount:,}", inline=True)
                file = discord.File(f"data/{ctx.author.id}.png", filename=f"{ctx.author.id}.png")
                embed.set_image(url=f"attachment://{ctx.author.id}.png")
                msg: discord.Message = await ctx.send(file=file, embed=embed)
                return msg

            def check(reaction: discord.Reaction, user: Union[discord.Member, discord.User]) -> bool:
                return all((
                    str(reaction.emoji) in ("🇸", "🇭"),
                    user == ctx.author,
                    user != self.bot.user,
                    reaction.message == msg
                ))

            standing = False

            while True:
                player_score = self.calc_hand(player_hand)
                dealer_score = self.calc_hand(dealer_hand)

                if player_score == 21:  
                    result = ("Blackjack!", 'won')
                    break

                elif player_score > 21: 
                    result = ("Player busts", 'lost')
                    break

                msg = await out_table(
                    title="🃏 Blackjack - Your Turn",
                    description=f"**Your hand:** {player_score}\n**Dealer's hand:** {dealer_score}\n\n🇭 = Hit | 🇸 = Stand",
                    color=0x000000
                )

                await msg.add_reaction("🇭")
                await msg.add_reaction("🇸")

                try:
                    reaction, _ = await self.bot.wait_for('reaction_add', timeout=60, check=check)
                except asyncio.TimeoutError:
                    await msg.delete()
                    return

                if str(reaction.emoji) == "🇭":
                    player_hand.append(deck.pop())
                    await msg.delete()
                    continue

                elif str(reaction.emoji) == "🇸":
                    standing = True
                    break

            if standing:
                dealer_hand[1] = dealer_hand[1].flip()  
                player_score = self.calc_hand(player_hand)
                dealer_score = self.calc_hand(dealer_hand)

                while dealer_score < 17:
                    dealer_hand.append(deck.pop())
                    dealer_score = self.calc_hand(dealer_hand)

                    # Apply luck bonus - small chance dealer busts early
                    if dealer_score >= 15 and random.uniform(0, 100) <= luck_bonus:
                        # Add a high card to potentially bust the dealer
                        high_cards = [card for card in deck if card.value >= 10]
                        if high_cards:
                            dealer_hand.append(high_cards[0])
                            deck.remove(high_cards[0])
                            dealer_score = self.calc_hand(dealer_hand)
                            break

                if dealer_score == 21:
                    result = ('Dealer blackjack', 'lost')
                elif dealer_score > 21:
                    result = ("Dealer busts", 'won')
                elif dealer_score == player_score:
                    result = ("Push (Tie)", 'tie')
                elif dealer_score > player_score:
                    result = ("You lose!", 'lost')
                elif dealer_score < player_score:
                    result = ("You win!", 'won')

            # Calculate winnings
            if result[1] == 'won':
                if player_score == 21 and len(player_hand) == 2:  # Natural blackjack
                    winnings = int(amount * 1.5)  # 3:2 payout
                else:
                    winnings = amount  # 1:1 payout
                new_balance = user_balance + winnings
                result_message = f"and won <:cowoncy:1385212758919745608> **{winnings:,}**!"
            elif result[1] == 'tie':
                winnings = 0
                new_balance = user_balance  # Push - get bet back
                result_message = "and got your bet back (push)!"
            else:  # lost
                winnings = -amount
                new_balance = user_balance - amount
                result_message = f"and lost <:cowoncy:1385212758919745608> **{amount:,}**!"

            # Update user balance
            await self.db.update_user_balance(ctx.author.id, new_balance)

            color = 0x000000
            try:
                await msg.delete()
            except:
                pass

            final_msg = await out_table(
                title=f"🃏 {result[0]}",
                color=color,
                description=(
                    f"**{ctx.author.display_name}** bet <:cowoncy:1385212758919745608> **{amount:,}** {result_message}\n\n"
                    f"**Your hand:** {player_score}\n**Dealer's hand:** {dealer_score}\n\n"
                    f"**New Balance:** <:cowoncy:1385212758919745608> {new_balance:,}"
                )
            )

            # Clean up the image file
            try:
                os.remove(f'data/{ctx.author.id}.png')
            except:
                pass

        except Exception as e:
            print(f"Blackjack error: {e}")
            await ctx.send(f"**🚫 | {ctx.author.display_name}**, an error occurred while playing blackjack!", delete_after=3)

    @sys.command(name='shop')
    async def sys_shop(self, ctx):
        """Display the shop with available rings"""
        embed = discord.Embed(
            title="Sys Shop: Rings",
            description="Purchase a ring to propose to someone!\nAll rings are the same. Different tiers are available to show off your love!\n\n"
                       "- **`sys buy {id}`** to buy an item\n"
                       "- **`sys sell {id}`** to sell an item for 75% of its original price\n"
                       "- **`sys marry @user {id}`** to use the ring\n"
                       "════════════════════════════════",
            color=0x000000
        )
        embed.set_author(name="Sys Shop", icon_url=ctx.author.avatar.url if ctx.author.avatar else ctx.author.default_avatar.url)

        rings = [
            ("1", "<:cring:1385494846256713830>", "Common Ring", "10"),
            ("2", "<:uring:1385494824979005441>", "Uncommon Ring", "100"),
            ("3", "<:rring:1385494667411325038>", "Rare Ring", "1K"),
            ("4", "<:ering:1385494642606342154>", "Epic Ring", "10K"),
            ("5", "<:mring:1385494594489417801>", "Mythical Ring", "100K"),
            ("6", "<a:lring:1385494567695941703>", "Legendary Ring", "1M"),
            ("7", "<a:fring:1385494502608863282>", "Fabled Ring", "10M")
        ]

        shop_text = ""
        for ring_id, emoji, name, price in rings:
            padding = "-" * (25 - len(name))
            shop_text += f"`{ring_id}` {emoji} **`{name}`**`{padding} {price}` <:cowoncy:1385212758919745608>\n"

        embed.description += f"\n{shop_text}"
        embed.set_footer(text="Page 1 of 1")

        await ctx.send(embed=embed)

    @sys.command(name='buy')
    async def sys_buy(self, ctx, item_id: int = None):
        """Buy a ring from the shop"""
        if item_id is None:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must specify an item ID to buy!", delete_after=3)

        rings = {
            1: ("Common Ring", 10, "<:cring:1385494846256713830>"),
            2: ("Uncommon Ring", 100, "<:uring:1385494824979005441>"),
            3: ("Rare Ring", 1000, "<:rring:1385494667411325038>"),
            4: ("Epic Ring", 10000, "<:ering:1385494642606342154>"),
            5: ("Mythical Ring", 100000, "<:mring:1385494594489417801>"),
            6: ("Legendary Ring", 1000000, "<a:lring:1385494567695941703>"),
            7: ("Fabled Ring", 10000000, "<a:fring:1385494502608863282>")
        }

        if item_id not in rings:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid item ID! Use `sys shop` to see available items.", delete_after=3)

        ring_name, price, emoji = rings[item_id]

        # Check if user has enough cowoncy
        user_balance = await self.db.get_user_balance(ctx.author.id)
        if user_balance < price:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have enough cowoncy! You need {price:,} cowoncy but only have {user_balance:,}.", delete_after=3)

        # Check if user already has this ring
        inventory = await self.db.get_user_inventory(ctx.author.id)
        if item_id in inventory:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you already own a {ring_name}!", delete_after=3)

        # Process purchase
        new_balance = user_balance - price
        await self.db.update_user_balance(ctx.author.id, new_balance)
        await self.db.add_to_inventory(ctx.author.id, item_id, ring_name)

        await ctx.send(f"**💍 | {ctx.author.display_name}** successfully purchased {emoji} **{ring_name}** for <:cowoncy:1385212758919745608> **{price:,}**!\n"
                      f"New balance: <:cowoncy:1385212758919745608> **{new_balance:,}**")

    @sys.command(name='sell')
    async def sys_sell_unified(self, ctx, item: str = None):
        """Sell rings by ID or animals by name/emoji"""
        if item is None:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must specify an item ID (for rings) or animal name/emoji (for zoo animals)!", delete_after=3)
        
        # Try to parse as integer for ring selling
        try:
            item_id = int(item)
            await self.sys_sell_item(ctx, item_id)
            return
        except ValueError:
            # Not an integer, try selling as animal
            await self._sell_animal(ctx, item)

    async def _sell_animal(self, ctx, animal: str):
        """Internal method to sell animals from zoo"""
        zoo_data = await self.db.get_user_zoo(ctx.author.id)
        if not zoo_data:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have any animals in your zoo!", delete_after=3)
        
        user_balance = await self.db.get_user_balance(ctx.author.id)
        
        if animal.lower() == "all":
            # Sell all animals
            total_sold = 0
            total_earned = 0
            
            for rarity, animals in zoo_data.items():
                for emoji, count in list(animals.items()):
                    if count > 0 and emoji in ZOO_ANIMALS[rarity]:
                        price = ZOO_ANIMALS[rarity][emoji]['price']
                        earned = count * price
                        total_earned += earned
                        total_sold += count
                        animals[emoji] = 0
            
            if total_sold == 0:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have any animals to sell!", delete_after=3)
            
            await self.db.update_user_zoo(ctx.author.id, zoo_data)
            await self.db.update_user_balance(ctx.author.id, user_balance + total_earned)
            
            await ctx.send(f"<:icon_tick:1372375089668161597> **Sold {total_sold} animals for {total_earned:,}** <:cowoncy:1385212758919745608>!")
        
        else:
            # Find and sell specific animal
            found = False
            animal_lower = animal.lower()
            
            for rarity, animals in zoo_data.items():
                for emoji, count in animals.items():
                    if emoji in ZOO_ANIMALS[rarity]:
                        animal_name = ZOO_ANIMALS[rarity][emoji]['name']
                        if animal_name == animal_lower or emoji == animal:
                            if count > 0:
                                price = ZOO_ANIMALS[rarity][emoji]['price']
                                animals[emoji] = count - 1
                                
                                await self.db.update_user_zoo(ctx.author.id, zoo_data)
                                await self.db.update_user_balance(ctx.author.id, user_balance + price)
                                
                                await ctx.send(f"{emoji} **x1** sold for **{price:,}** <:cowoncy:1385212758919745608>!")
                                found = True
                                break
                            else:
                                await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have any {emoji} to sell!", delete_after=3)
                                found = True
                                break
                
                if found:
                    break
            
            if not found:
                await ctx.send(f"**🚫 | {ctx.author.display_name}**, animal `{animal}` not found in your zoo!", delete_after=3)

    async def sys_sell_item(self, ctx, item_id: int = None):
        """Sell a ring for 75% of its original price"""
        if item_id is None:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must specify an item ID to sell!", delete_after=3)

        rings = {
            1: ("Common Ring", 10, "<:cring:1385494846256713830>"),
            2: ("Uncommon Ring", 100, "<:uring:1385494824979005441>"),
            3: ("Rare Ring", 1000, "<:rring:1385494667411325038>"),
            4: ("Epic Ring", 10000, "<:ering:1385494642606342154>"),
            5: ("Mythical Ring", 100000, "<:mring:1385494594489417801>"),
            6: ("Legendary Ring", 1000000, "<a:lring:1385494567695941703>"),
            7: ("Fabled Ring", 10000000, "<a:fring:1385494502608863282>")
        }

        if item_id not in rings:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid item ID!", delete_after=3)

        # Check if user owns this ring
        inventory = await self.db.get_user_inventory(ctx.author.id)
        if item_id not in inventory:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't own this ring!", delete_after=3)

        ring_name, original_price, emoji = rings[item_id]
        sell_price = int(original_price * 0.75)

        # Process sale
        user_balance = await self.db.get_user_balance(ctx.author.id)
        new_balance = user_balance + sell_price
        await self.db.update_user_balance(ctx.author.id, new_balance)
        await self.db.remove_from_inventory(ctx.author.id, item_id)

        await ctx.send(f"**💰 | {ctx.author.display_name}** successfully sold {emoji} **{ring_name}** for <:cowoncy:1385212758919745608> **{sell_price:,}**!\n"
                      f"New balance: <:cowoncy:1385212758919745608> **{new_balance:,}**")

    @sys.command(name='marry')
    async def sys_marry(self, ctx, user: discord.Member = None, ring_id: int = None):
        """Use a ring to marry someone"""
        if user is None or ring_id is None:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, usage: `sys marry @user {{ring_id}}`", delete_after=3)

        if user == ctx.author:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you can't marry yourself!", delete_after=3)

        if user.bot:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you can't marry a bot!", delete_after=3)

        rings = {
            1: ("Common Ring", 10, "<:cring:1385494846256713830>"),
            2: ("Uncommon Ring", 100, "<:uring:1385494824979005441>"),
            3: ("Rare Ring", 1000, "<:rring:1385494667411325038>"),
            4: ("Epic Ring", 10000, "<:ering:1385494642606342154>"),
            5: ("Mythical Ring", 100000, "<:mring:1385494594489417801>"),
            6: ("Legendary Ring", 1000000, "<a:lring:1385494567695941703>"),
            7: ("Fabled Ring", 10000000, "<a:fring:1385494502608863282>")
        }

        if ring_id not in rings:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid ring ID!", delete_after=3)

        # Check if user owns this ring
        inventory = await self.db.get_user_inventory(ctx.author.id)
        if ring_id not in inventory:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't own this ring!", delete_after=3)

        # Check if either user is already married
        proposer_marriage = await self.db.get_marriage_status(ctx.author.id)
        target_marriage = await self.db.get_marriage_status(user.id)

        if proposer_marriage:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you are already married!", delete_after=3)

        if target_marriage:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, {user.display_name} is already married!", delete_after=3)

        ring_name, _, emoji = rings[ring_id]

        # Create proposal embed
        embed = discord.Embed(
            title="💒 Marriage Proposal",
            description=f"{ctx.author.mention} has proposed to {user.mention} with {emoji} **{ring_name}**!\n\n"
                       f"{user.mention}, do you accept this proposal?",
            color=0xFF69B4
        )
        embed.set_footer(text="Click <:icon_tick:1372375089668161597> to accept or <:icon_cross:1372375094336425986> to decline")

        # Create buttons
        accept_button = discord.ui.Button(label="<:icon_tick:1372375089668161597> Accept", style=discord.ButtonStyle.green)
        decline_button = discord.ui.Button(label="<:icon_cross:1372375094336425986> Decline", style=discord.ButtonStyle.red)

        async def accept_callback(interaction):
            if interaction.user != user:
                return await interaction.response.send_message("Only the person being proposed to can accept!", ephemeral=True)

            # Process marriage
            await self.db.create_marriage(ctx.author.id, user.id, ring_id)
            await self.db.remove_from_inventory(ctx.author.id, ring_id)

            await interaction.response.edit_message(
                content=f"🎉 **Congratulations!** {ctx.author.mention} and {user.mention} are now married with {emoji} **{ring_name}**! 💕",
                embed=None,
                view=None
            )

        async def decline_callback(interaction):
            if interaction.user != user:
                return await interaction.response.send_message("Only the person being proposed to can decline!", ephemeral=True)

            await interaction.response.edit_message(
                content=f"💔 {user.mention} declined {ctx.author.mention}'s proposal...",
                embed=None,
                view=None
            )

        accept_button.callback = accept_callback
        decline_button.callback = decline_callback

        view = discord.ui.View(timeout=300)
        view.add_item(accept_button)
        view.add_item(decline_button)

        await ctx.send(embed=embed, view=view)

    @sys.command(name='inventory', aliases=['inv'])
    async def sys_inventory(self, ctx, user: discord.Member = None):
        """Check your or someone's inventory"""
        target_user = user or ctx.author
        inventory = await self.db.get_user_inventory(target_user.id)
        zoo_data = await self.db.get_user_zoo(target_user.id)

        # Superscript conversion function
        def to_superscript(num):
            superscript_map = {
                '0': '⁰', '1': '¹', '2': '²', '3': '³', '4': '⁴',
                '5': '⁵', '6': '⁶', '7': '⁷', '8': '⁸', '9': '⁹'
            }
            return ''.join(superscript_map.get(char, char) for char in str(num).zfill(3))

        # Create inventory display
        embed = discord.Embed(
            color=0x000000
        )

        inventory_lines = []
        
        # Add rings with proper emoji mapping
        rings = {
            1: ("Common Ring", "💍"),
            2: ("Uncommon Ring", "🔵"),
            3: ("Rare Ring", "🟣"),
            4: ("Epic Ring", "🟠"),
            5: ("Mythical Ring", "🔴"),
            6: ("Legendary Ring", "🟡"),
            7: ("Fabled Ring", "⭐")
        }
        
        # Get user's actual gems
        user_gems = await self.db.get_user_gems(target_user.id)
        if not user_gems:
            user_gems = {
                'power': random.randint(20, 50),
                'fire': random.randint(600, 900),
                'magic': random.randint(200, 400),
                'ice': random.randint(10, 30),
                'lightning': random.randint(15, 35),
                'star': random.randint(5, 15),
                'rainbow': random.randint(2, 10),
                'crystal': random.randint(1, 5)
            }
        
        # Add gems with actual counts
        gems = [
            (50, "💎", "Power Gem", user_gems.get('power', 0)),
            (51, "🔥", "Fire Gem", user_gems.get('fire', 0)),
            (52, "✨", "Magic Gem", user_gems.get('magic', 0)),
            (53, "❄️", "Ice Gem", user_gems.get('ice', 0)),
            (54, "⚡", "Lightning Gem", user_gems.get('lightning', 0)),
            (55, "🌟", "Star Gem", user_gems.get('star', 0)),
            (56, "🌈", "Rainbow Gem", user_gems.get('rainbow', 0)),
            (57, "🔮", "Crystal Gem", user_gems.get('crystal', 0))
        ]
        
        # Add crates and items with consistent counts
        items = [
            (100, "📦", "Loot Crate", random.randint(10, 50)),
            (101, "⚔️", "Sword", random.randint(1, 8)),
            (102, "🛡️", "Shield", random.randint(1, 6)),
            (103, "🏹", "Bow", random.randint(1, 5)),
            (104, "🪄", "Wand", random.randint(2, 10)),
            (105, "🔨", "Hammer", random.randint(1, 4))
        ]

        # Format inventory
        all_items = []
        
        # Add rings from user inventory
        for item_id in inventory:
            if item_id in rings:
                ring_name, emoji = rings[item_id]
                all_items.append(f"`{item_id:03d}`{emoji}{to_superscript(1)}")
        
        # Add gems and items (only if count > 0)
        for item_id, emoji, name, count in gems + items:
            if count > 0:
                all_items.append(f"`{item_id:03d}`{emoji}{to_superscript(count)}")

        # Group items into lines of 4
        for i in range(0, len(all_items), 4):
            line_items = all_items[i:i+4]
            inventory_lines.append("    ".join(line_items))

        # Create proper title and description
        embed.title = f"**====== {target_user.display_name}'s Inventory ======**"
        if inventory_lines:
            embed.description = "\n".join(inventory_lines)
        else:
            embed.description = "Empty inventory! Start hunting and gambling to collect items."

        # Add zoo stats if available
        if zoo_data:
            points, rarity_counts = self.calculate_zoo_points(zoo_data)
            embed.add_field(
                name="🦁 Zoo Stats",
                value=f"Animals: **{sum(rarity_counts.values())}** | Zoo Points: **{points:,}**",
                inline=False
            )

        embed.set_author(
            name=f"{target_user.display_name}'s Collection",
            icon_url=target_user.display_avatar.url
        )
        
        embed.set_footer(
            text="Use sys shop to buy items | sys hunt to find animals",
            icon_url=ctx.bot.user.display_avatar.url
        )

        await ctx.send(embed=embed)

    @sys.command(name='pray')
    async def sys_pray(self, ctx, user: discord.Member = None):
        """Pray for luck points to increase gambling chances"""
        target_user = user or ctx.author

        # Check cooldown for the person praying (not the target)
        current_time = datetime.now()
        last_pray = await self.db.get_last_pray_time(ctx.author.id)

        if last_pray:
            last_pray_dt = datetime.fromisoformat(last_pray)
            time_diff = current_time - last_pray_dt
            cooldown_minutes = 5

            if time_diff < timedelta(minutes=cooldown_minutes):
                remaining_time = timedelta(minutes=cooldown_minutes) - time_diff
                remaining_seconds = int(remaining_time.total_seconds())
                next_use_time = int((current_time + remaining_time).timestamp())

                cooldown_msg = f"**⏱ | {ctx.author.display_name}**! Slow down and try the command again **<t:{next_use_time}:R>**"
                return await ctx.send(cooldown_msg, delete_after=remaining_seconds)

        # Update pray cooldown
        await self.db.set_last_pray_time(ctx.author.id, current_time.isoformat())

        # Get current luck and add 1 point
        current_luck = await self.db.get_user_luck(target_user.id)
        new_luck = current_luck + 1
        await self.db.update_user_luck(target_user.id, new_luck)

        if target_user == ctx.author:
            message = f"**🙏 | {ctx.author.mention}** prays... Fortune favors you!\nYou have **{new_luck}** luck point(s)!"
        else:
            message = f"**🙏 | {ctx.author.mention}** prays for {target_user.mention}... Fortune favors them!\n{target_user.mention} has **{new_luck}** luck point(s)!"

        await ctx.send(message)

    @sys.command(name='curse')
    async def sys_curse(self, ctx, user: discord.Member = None):
        """Curse another user to reduce their luck and increase yours"""
        if user is None:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must specify a user to curse!", delete_after=3)

        if user == ctx.author:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you can't curse yourself!", delete_after=3)

        if user.bot:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you can't curse a bot!", delete_after=3)

        # Check cooldown for cursing
        current_time = datetime.now()
        last_curse = await self.db.get_last_curse_time(ctx.author.id)

        if last_curse:
            last_curse_dt = datetime.fromisoformat(last_curse)
            time_diff = current_time - last_curse_dt
            cooldown_minutes = 5

            if time_diff < timedelta(minutes=cooldown_minutes):
                remaining_time = timedelta(minutes=cooldown_minutes) - time_diff
                remaining_seconds = int(remaining_time.total_seconds())
                next_use_time = int((current_time + remaining_time).timestamp())

                cooldown_msg = f"**⏱ | {ctx.author.display_name}**! Slow down and try the command again **<t:{next_use_time}:R>**"
                return await ctx.send(cooldown_msg, delete_after=remaining_seconds)

        # Update curse cooldown
        await self.db.set_last_curse_time(ctx.author.id, current_time.isoformat())

        # Get current luck points
        target_luck = await self.db.get_user_luck(user.id)
        curser_luck = await self.db.get_user_luck(ctx.author.id)

        # Reduce target's luck by 1 (minimum 0)
        new_target_luck = max(0, target_luck - 1)
        await self.db.update_user_luck(user.id, new_target_luck)

        # Increase curser's luck by 1
        new_curser_luck = curser_luck + 1
        await self.db.update_user_luck(ctx.author.id, new_curser_luck)

        message = f"**👻 | {ctx.author.mention}** puts a curse on **{user.mention}**! oh boy.\n You have **{new_curser_luck}** luck point(s)!"
        await ctx.send(message)

    @sys.command(name='daily')
    async def sys_daily(self, ctx):
        """Claim your daily cowoncy reward"""
        user_id = ctx.author.id
        current_time = datetime.now()
        
        # Check if user has claimed daily reward today
        last_daily = await self.db.get_last_daily_time(user_id)
        
        if last_daily:
            try:
                last_daily_dt = datetime.fromisoformat(last_daily)
                time_diff = current_time - last_daily_dt
                cooldown_hours = 24
                
                if time_diff.total_seconds() < (cooldown_hours * 3600):  # 24 hours in seconds
                    remaining_time = timedelta(hours=cooldown_hours) - time_diff
                    next_use_time = int((current_time + remaining_time).timestamp())
                    cooldown_msg = f"**⏰ | {ctx.author.display_name}**, you already claimed your daily reward! Next reward available **<t:{next_use_time}:R>**"
                    return await ctx.send(cooldown_msg, delete_after=10)
            except (ValueError, TypeError) as e:
                # If there's an issue with the stored time, reset it
                print(f"Daily time parsing error for user {user_id}: {e}")
                pass
        
        # Calculate reward amount (base + streak bonus)
        base_reward = random.randint(500, 1500)
        
        # Get user's current streak
        daily_streak = await self.db.get_daily_streak(user_id)
        
        # Check if streak should continue (last claim was yesterday)
        if last_daily:
            last_daily_dt = datetime.fromisoformat(last_daily)
            days_since_last = (current_time - last_daily_dt).days
            
            if days_since_last == 1:
                # Continue streak
                daily_streak += 1
            elif days_since_last > 1:
                # Reset streak
                daily_streak = 1
        else:
            # First time claiming
            daily_streak = 1
        
        # Streak bonus (up to 10x multiplier)
        streak_multiplier = min(1 + (daily_streak * 0.1), 2.5)
        total_reward = int(base_reward * streak_multiplier)
        
        # Add luck bonus
        user_luck = await self.db.get_user_luck(user_id)
        luck_bonus = int(total_reward * (user_luck * 0.02))  # 2% per luck point
        total_reward += luck_bonus
        
        # Update user balance and streak
        user_balance = await self.db.get_user_balance(user_id)
        new_balance = user_balance + total_reward
        
        await self.db.update_user_balance(user_id, new_balance)
        await self.db.set_last_daily_time(user_id, current_time.isoformat())
        await self.db.update_daily_streak(user_id, daily_streak)
        
        # Create reward embed
        embed = discord.Embed(
            title="🎁 Daily Reward Claimed!",
            color=0x000000
        )
        
        embed.add_field(
            name="💰 Reward Breakdown",
            value=f"**Base Reward:** {base_reward:,} <:cowoncy:1385212758919745608>\n"
                  f"**Streak Bonus:** x{streak_multiplier:.1f} (Day {daily_streak})\n"
                  f"**Luck Bonus:** {luck_bonus:,} <:cowoncy:1385212758919745608>\n"
                  f"**Total Earned:** {total_reward:,} <:cowoncy:1385212758919745608>",
            inline=False
        )
        
        embed.add_field(
            name="💳 New Balance",
            value=f"{new_balance:,} <:cowoncy:1385212758919745608>",
            inline=True
        )
        
        embed.add_field(
            name="🔥 Current Streak",
            value=f"{daily_streak} day(s)",
            inline=True
        )
        
        if daily_streak >= 7:
            embed.add_field(
                name="🏆 Achievement",
                value="Weekly Warrior! 7+ day streak!",
                inline=False
            )
        
        embed.set_author(
            name=f"{ctx.author.display_name}'s Daily Reward",
            icon_url=ctx.author.display_avatar.url
        )
        
        embed.set_footer(
            text="Come back tomorrow for another reward!",
            icon_url=ctx.bot.user.display_avatar.url
        )
        
        embed.timestamp = discord.utils.utcnow()
        
        await ctx.send(embed=embed)

    @sys.command(name='work')
    async def sys_work(self, ctx):
        """Work various jobs to earn cowoncy"""
        user_id = ctx.author.id
        current_time = datetime.now()
        
        # Check cooldown (1 hour)
        last_work = await self.db.get_last_work_time(user_id)
        
        if last_work:
            last_work_dt = datetime.fromisoformat(last_work)
            time_diff = current_time - last_work_dt
            cooldown_hours = 1
            
            if time_diff < timedelta(hours=cooldown_hours):
                remaining_time = timedelta(hours=cooldown_hours) - time_diff
                minutes = int(remaining_time.total_seconds() // 60)
                next_use_time = int((current_time + remaining_time).timestamp())
                
                cooldown_msg = f"**💼 | {ctx.author.display_name}**, you're still tired from work! Try again **<t:{next_use_time}:R>**"
                return await ctx.send(cooldown_msg, delete_after=int(remaining_time.total_seconds()))
        
        # Update work time
        await self.db.set_last_work_time(user_id, current_time.isoformat())
        
        # Job scenarios with rewards
        jobs = [
            ("🍔", "worked at a burger joint", (200, 800)),
            ("📦", "delivered packages", (300, 900)),
            ("🚗", "drove for a ride-share service", (250, 750)),
            ("💻", "did freelance coding", (400, 1200)),
            ("🧹", "cleaned offices", (150, 600)),
            ("🌱", "worked in a garden", (180, 700)),
            ("📚", "tutored students", (350, 1000)),
            ("🍕", "delivered pizza", (220, 650)),
            ("🎨", "sold artwork", (100, 1500)),
            ("🔧", "fixed computers", (300, 950)),
            ("📰", "delivered newspapers", (120, 500)),
            ("🚚", "drove a delivery truck", (280, 820)),
            ("☕", "worked at a coffee shop", (160, 580)),
            ("🏪", "worked at a convenience store", (140, 520)),
            ("🎵", "performed music on the street", (80, 1200))
        ]
        
        job_emoji, job_desc, (min_reward, max_reward) = random.choice(jobs)
        base_reward = random.randint(min_reward, max_reward)
        
        # Apply luck bonus
        user_luck = await self.db.get_user_luck(user_id)
        luck_bonus = int(base_reward * (user_luck * 0.03))  # 3% per luck point
        total_reward = base_reward + luck_bonus
        
        # Random bonus chance (5%)
        bonus_reward = 0
        if random.random() < 0.05:
            bonus_reward = random.randint(100, 500)
            total_reward += bonus_reward
        
        # Update balance
        user_balance = await self.db.get_user_balance(user_id)
        new_balance = user_balance + total_reward
        await self.db.update_user_balance(user_id, new_balance)
        
        # Create response
        message = f"**{job_emoji} | {ctx.author.display_name}** {job_desc} and earned **{total_reward:,}** <:cowoncy:1385212758919745608>!"
        
        if bonus_reward > 0:
            message += f"\n🎉 **Bonus!** You got an extra **{bonus_reward:,}** <:cowoncy:1385212758919745608> tip!"
        
        await ctx.send(message)

    @sys.command(name='beg')
    async def sys_beg(self, ctx):
        """Beg for cowoncy from generous strangers"""
        user_id = ctx.author.id
        current_time = datetime.now()
        
        # Check cooldown (30 minutes)
        last_beg = await self.db.get_last_beg_time(user_id)
        
        if last_beg:
            last_beg_dt = datetime.fromisoformat(last_beg)
            time_diff = current_time - last_beg_dt
            cooldown_minutes = 30
            
            if time_diff < timedelta(minutes=cooldown_minutes):
                remaining_time = timedelta(minutes=cooldown_minutes) - time_diff
                minutes = int(remaining_time.total_seconds() // 60)
                next_use_time = int((current_time + remaining_time).timestamp())
                
                cooldown_msg = f"**🥺 | {ctx.author.display_name}**, people are getting annoyed! Try begging again **<t:{next_use_time}:R>**"
                return await ctx.send(cooldown_msg, delete_after=int(remaining_time.total_seconds()))
        
        # Update beg time
        await self.db.set_last_beg_time(user_id, current_time.isoformat())
        
        # Begging scenarios
        scenarios = [
            ("🎩", "A kind gentleman", (50, 300)),
            ("👵", "A sweet grandmother", (20, 250)),
            ("🧑‍💼", "A busy businessman", (100, 500)),
            ("👶", "A generous child", (10, 150)),
            ("🎭", "A street performer", (30, 200)),
            ("🚗", "Someone from their car", (40, 350)),
            ("🏪", "A shop owner", (60, 400)),
            ("🎓", "A college student", (15, 180)),
            ("👮", "A kind police officer", (80, 300)),
            ("🧑‍🍳", "A chef taking a break", (45, 275))
        ]
        
        # 70% chance of success
        if random.random() < 0.7:
            emoji, person, (min_reward, max_reward) = random.choice(scenarios)
            base_reward = random.randint(min_reward, max_reward)
            
            # Apply luck bonus
            user_luck = await self.db.get_user_luck(user_id)
            luck_bonus = int(base_reward * (user_luck * 0.02))  # 2% per luck point
            total_reward = base_reward + luck_bonus
            
            # Update balance
            user_balance = await self.db.get_user_balance(user_id)
            new_balance = user_balance + total_reward
            await self.db.update_user_balance(user_id, new_balance)
            
            message = f"**{emoji} | {person}** took pity on **{ctx.author.display_name}** and gave them **{total_reward:,}** <:cowoncy:1385212758919745608>!"
        else:
            # Failed begging
            failures = [
                "**😤 |** People ignored your begging!",
                "**🚫 |** A security guard told you to move along!",
                "**😒 |** Everyone pretended not to see you!",
                "**🏃 |** People avoided you and walked faster!",
                "**💸 |** Someone threw a penny at you... but missed!"
            ]
            message = f"{random.choice(failures)} Better luck next time, **{ctx.author.display_name}**!"
        
        await ctx.send(message)

    @sys.command(name='baltop', aliases=['leaderboard', 'rich'])
    async def sys_baltop(self, ctx):
        """View the richest users in the server"""
        # Get all users in the server with their balances
        server_users = [member.id for member in ctx.guild.members if not member.bot]
        user_balances = []
        
        for user_id in server_users:
            balance = await self.db.get_user_balance(user_id)
            if balance > 0:
                user = ctx.guild.get_member(user_id)
                if user:
                    user_balances.append((user, balance))
        
        # Sort by balance (highest first)
        user_balances.sort(key=lambda x: x[1], reverse=True)
        
        if not user_balances:
            embed = discord.Embed(
                title="💰 Cowoncy Leaderboard",
                description="No one in this server has any cowoncy yet!",
                color=0x000000
            )
            return await ctx.send(embed=embed)
        
        # Create leaderboard embed
        embed = discord.Embed(
            title="💰 Cowoncy Leaderboard",
            description=f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nRichest users in **{ctx.guild.name}**",
            color=0x000000
        )
        
        # Add top 10 users
        leaderboard_text = ""
        medals = ["🥇", "🥈", "🥉"]
        
        for i, (user, balance) in enumerate(user_balances[:10], 1):
            if i <= 3:
                medal = medals[i-1]
            else:
                medal = f"`{i:02d}`"
            
            # Check if this is the command user
            if user.id == ctx.author.id:
                leaderboard_text += f"{medal} **{user.display_name}** - **{balance:,}** <:cowoncy:1385212758919745608> **← YOU**\n"
            else:
                leaderboard_text += f"{medal} **{user.display_name}** - **{balance:,}** <:cowoncy:1385212758919745608>\n"
        
        embed.description += f"\n\n{leaderboard_text}"
        
        # Add user's position if not in top 10
        user_position = None
        for i, (user, balance) in enumerate(user_balances, 1):
            if user.id == ctx.author.id:
                user_position = i
                break
        
        if user_position and user_position > 10:
            user_balance = await self.db.get_user_balance(ctx.author.id)
            embed.add_field(
                name="📊 Your Position",
                value=f"**#{user_position}** - **{user_balance:,}** <:cowoncy:1385212758919745608>",
                inline=False
            )
        
        embed.set_author(
            name=f"{ctx.guild.name}'s Richest",
            icon_url=ctx.guild.icon.url if ctx.guild.icon else ctx.bot.user.display_avatar.url
        )
        
        embed.set_footer(
            text=f"Total users: {len(user_balances)} | Your rank: #{user_position or 'Not ranked'}",
            icon_url=ctx.author.display_avatar.url
        )
        
        embed.timestamp = discord.utils.utcnow()
        
        await ctx.send(embed=embed)

    @sys.command(name='trivia')
    async def sys_trivia(self, ctx):
        """Answer trivia questions for cowoncy rewards"""
        user_id = ctx.author.id
        current_time = datetime.now()
        
        # Check cooldown (10 minutes)
        last_trivia = await self.db.get_last_trivia_time(user_id)
        
        if last_trivia:
            last_trivia_dt = datetime.fromisoformat(last_trivia)
            time_diff = current_time - last_trivia_dt
            cooldown_minutes = 10
            
            if time_diff < timedelta(minutes=cooldown_minutes):
                remaining_time = timedelta(minutes=cooldown_minutes) - time_diff
                minutes = int(remaining_time.total_seconds() // 60)
                next_use_time = int((current_time + remaining_time).timestamp())
                
                cooldown_msg = f"**🧠 | {ctx.author.display_name}**, your brain needs a rest! Try again **<t:{next_use_time}:R>**"
                return await ctx.send(cooldown_msg, delete_after=int(remaining_time.total_seconds()))
        
        # Trivia questions
        questions = [
            {
                "question": "What is the capital of Japan?",
                "answers": ["Tokyo", "Kyoto", "Osaka", "Hiroshima"],
                "correct": 0
            },
            {
                "question": "Which planet is known as the Red Planet?",
                "answers": ["Venus", "Mars", "Jupiter", "Saturn"],
                "correct": 1
            },
            {
                "question": "What is 7 × 8?",
                "answers": ["54", "56", "58", "60"],
                "correct": 1
            },
            {
                "question": "Who painted the Mona Lisa?",
                "answers": ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Michelangelo"],
                "correct": 2
            },
            {
                "question": "What is the largest ocean on Earth?",
                "answers": ["Atlantic", "Indian", "Arctic", "Pacific"],
                "correct": 3
            },
            {
                "question": "In which year did World War II end?",
                "answers": ["1944", "1945", "1946", "1947"],
                "correct": 1
            },
            {
                "question": "What is the chemical symbol for gold?",
                "answers": ["Go", "Gd", "Au", "Ag"],
                "correct": 2
            },
            {
                "question": "Which animal is known as the King of the Jungle?",
                "answers": ["Tiger", "Lion", "Elephant", "Gorilla"],
                "correct": 1
            },
            {
                "question": "How many sides does a hexagon have?",
                "answers": ["5", "6", "7", "8"],
                "correct": 1
            },
            {
                "question": "What is the smallest country in the world?",
                "answers": ["Monaco", "Nauru", "Vatican City", "San Marino"],
                "correct": 2
            }
        ]
        
        # Select random question
        question_data = random.choice(questions)
        
        # Create question embed
        embed = discord.Embed(
            title="🧠 Trivia Challenge",
            description=f"**Question:** {question_data['question']}\n\n" +
                       "\n".join([f"**{i+1}.** {answer}" for i, answer in enumerate(question_data['answers'])]),
            color=0x000000
        )
        
        embed.add_field(
            name="💰 Reward",
            value="**Correct:** 200-500 <:cowoncy:1385212758919745608>\n**Wrong:** 50-100 <:cowoncy:1385212758919745608>",
            inline=False
        )
        
        embed.set_author(
            name=f"{ctx.author.display_name}'s Trivia",
            icon_url=ctx.author.display_avatar.url
        )
        
        embed.set_footer(text="You have 30 seconds to answer! Type 1, 2, 3, or 4")
        
        message = await ctx.send(embed=embed)
        
        # Wait for answer
        def check(m):
            return m.author == ctx.author and m.channel == ctx.channel and m.content in ['1', '2', '3', '4']
        
        try:
            answer_msg = await self.bot.wait_for('message', timeout=30, check=check)
            user_answer = int(answer_msg.content) - 1
            
            # Update trivia time
            await self.db.set_last_trivia_time(user_id, current_time.isoformat())
            
            if user_answer == question_data['correct']:
                # Correct answer
                base_reward = random.randint(200, 500)
                user_luck = await self.db.get_user_luck(user_id)
                luck_bonus = int(base_reward * (user_luck * 0.02))
                total_reward = base_reward + luck_bonus
                
                user_balance = await self.db.get_user_balance(user_id)
                new_balance = user_balance + total_reward
                await self.db.update_user_balance(user_id, new_balance)
                
                result_msg = f"🎉 **Correct!** **{ctx.author.display_name}** earned **{total_reward:,}** <:cowoncy:1385212758919745608>!"
            else:
                # Wrong answer
                consolation = random.randint(50, 100)
                user_balance = await self.db.get_user_balance(user_id)
                new_balance = user_balance + consolation
                await self.db.update_user_balance(user_id, new_balance)
                
                correct_answer = question_data['answers'][question_data['correct']]
                correct_number = question_data['correct'] + 1  # Convert to 1-indexed
                result_msg = f"<:icon_cross:1372375094336425986> **Wrong!** The correct answer was **{correct_number}. {correct_answer}**.\nBut here's **{consolation:,}** <:cowoncy:1385212758919745608> for trying!"
            
            await ctx.send(result_msg)
            
        except asyncio.TimeoutError:
            correct_answer = question_data['answers'][question_data['correct']]
            correct_number = question_data['correct'] + 1  # Convert to 1-indexed
            await ctx.send(f"⏰ **Time's up!** The correct answer was **{correct_number}. {correct_answer}**. Try again later!")

    @sys.command(name='lottery')
    async def sys_lottery(self, ctx):
        """Buy lottery tickets for a chance to win big"""
        user_id = ctx.author.id
        
        # Check if user has enough cowoncy for a ticket (100 cowoncy)
        ticket_price = 100
        user_balance = await self.db.get_user_balance(user_id)
        
        if user_balance < ticket_price:
            return await ctx.send(f"**🎫 | {ctx.author.display_name}**, you need **{ticket_price:,}** <:cowoncy:1385212758919745608> to buy a lottery ticket!")
        
        # Deduct ticket price
        new_balance = user_balance - ticket_price
        await self.db.update_user_balance(user_id, new_balance)
        
        # Generate lottery numbers
        user_numbers = [random.randint(1, 50) for _ in range(6)]
        winning_numbers = [random.randint(1, 50) for _ in range(6)]
        
        # Count matches
        matches = len(set(user_numbers) & set(winning_numbers))
        
        # Determine prize
        prizes = {
            6: ("🏆 JACKPOT!", 50000),
            5: ("🥇 5 Matches!", 10000),
            4: ("🥈 4 Matches!", 2500),
            3: ("🥉 3 Matches!", 500),
            2: ("💰 2 Matches!", 200),
            1: ("🎯 1 Match!", 50),
            0: ("💸 No Matches", 0)
        }
        
        prize_text, prize_amount = prizes[matches]
        
        # Apply luck bonus to winnings
        if prize_amount > 0:
            user_luck = await self.db.get_user_luck(user_id)
            luck_bonus = int(prize_amount * (user_luck * 0.01))  # 1% per luck point
            prize_amount += luck_bonus
            
            # Add winnings to balance
            final_balance = new_balance + prize_amount
            await self.db.update_user_balance(user_id, final_balance)
        else:
            final_balance = new_balance
        
        # Create result embed
        embed = discord.Embed(
            title="🎫 Lottery Results",
            color=0x000000
        )
        
        embed.add_field(
            name="🎲 Your Numbers",
            value=" ".join([f"`{num:02d}`" for num in sorted(user_numbers)]),
            inline=False
        )
        
        embed.add_field(
            name="🏆 Winning Numbers", 
            value=" ".join([f"`{num:02d}`" for num in sorted(winning_numbers)]),
            inline=False
        )
        
        embed.add_field(
            name="🎉 Result",
            value=f"**{prize_text}**\n**Matches:** {matches}/6",
            inline=True
        )
        
        if prize_amount > 0:
            embed.add_field(
                name="💰 Prize",
                value=f"**{prize_amount:,}** <:cowoncy:1385212758919745608>",
                inline=True
            )
        
        embed.add_field(
            name="💳 Balance",
            value=f"{final_balance:,} <:cowoncy:1385212758919745608>",
            inline=True
        )
        
        embed.set_author(
            name=f"{ctx.author.display_name}'s Lottery Ticket",
            icon_url=ctx.author.display_avatar.url
        )
        
        embed.set_footer(text=f"Ticket cost: {ticket_price:,} cowoncy")
        
        await ctx.send(embed=embed)

    @sys.command(name='bank')
    async def sys_bank(self, ctx, action: str = None, amount: int = None):
        """Bank system - deposit, withdraw, or check balance with interest"""
        if action is None:
            # Show bank info
            user_id = ctx.author.id
            bank_balance = await self.db.get_bank_balance(user_id)
            wallet_balance = await self.db.get_user_balance(user_id)
            
            embed = discord.Embed(
                title="🏦 Strelizia Bank",
                description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nSecure your cowoncy and earn interest!",
                color=0x000000
            )
            
            embed.add_field(
                name="💰 Account Summary",
                value=f"**Wallet:** {wallet_balance:,} <:cowoncy:1385212758919745608>\n"
                      f"**Bank:** {bank_balance:,} <:cowoncy:1385212758919745608>\n"
                      f"**Total:** {wallet_balance + bank_balance:,} <:cowoncy:1385212758919745608>",
                inline=False
            )
            
            embed.add_field(
                name="📈 Interest Rate",
                value="**2% daily** on deposited amounts\n*Interest calculated every 24 hours*",
                inline=False
            )
            
            embed.add_field(
                name="💡 Commands",
                value=f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} bank deposit <amount>` - Deposit cowoncy\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} bank withdraw <amount>` - Withdraw cowoncy\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} bank all` - Deposit all wallet cowoncy",
                inline=False
            )
            
            embed.set_author(
                name=f"{ctx.author.display_name}'s Bank Account",
                icon_url=ctx.author.display_avatar.url
            )
            
            await ctx.send(embed=embed)
            return
        
        user_id = ctx.author.id
        action = action.lower()
        
        if action == "deposit" or action == "dep":
            if amount is None:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, specify an amount to deposit!")
            
            if amount <= 0:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, amount must be positive!")
            
            wallet_balance = await self.db.get_user_balance(user_id)
            if wallet_balance < amount:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have enough cowoncy in your wallet!")
            
            # Process deposit
            bank_balance = await self.db.get_bank_balance(user_id)
            new_wallet = wallet_balance - amount
            new_bank = bank_balance + amount
            
            await self.db.update_user_balance(user_id, new_wallet)
            await self.db.update_bank_balance(user_id, new_bank)
            
            await ctx.send(f"🏦 **{ctx.author.display_name}** deposited **{amount:,}** <:cowoncy:1385212758919745608> into the bank!\n"
                          f"**Bank balance:** {new_bank:,} <:cowoncy:1385212758919745608>")
        
        elif action == "withdraw" or action == "with":
            if amount is None:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, specify an amount to withdraw!")
            
            if amount <= 0:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, amount must be positive!")
            
            bank_balance = await self.db.get_bank_balance(user_id)
            if bank_balance < amount:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have enough cowoncy in the bank!")
            
            # Process withdrawal
            wallet_balance = await self.db.get_user_balance(user_id)
            new_bank = bank_balance - amount
            new_wallet = wallet_balance + amount
            
            await self.db.update_bank_balance(user_id, new_bank)
            await self.db.update_user_balance(user_id, new_wallet)
            
            await ctx.send(f"🏦 **{ctx.author.display_name}** withdrew **{amount:,}** <:cowoncy:1385212758919745608> from the bank!\n"
                          f"**Wallet balance:** {new_wallet:,} <:cowoncy:1385212758919745608>")
        
        elif action == "all":
            # Deposit all wallet money
            wallet_balance = await self.db.get_user_balance(user_id)
            
            if wallet_balance <= 0:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have any cowoncy in your wallet!")
            
            bank_balance = await self.db.get_bank_balance(user_id)
            new_bank = bank_balance + wallet_balance
            
            await self.db.update_user_balance(user_id, 0)
            await self.db.update_bank_balance(user_id, new_bank)
            
            await ctx.send(f"🏦 **{ctx.author.display_name}** deposited all **{wallet_balance:,}** <:cowoncy:1385212758919745608> into the bank!\n"
                          f"**Bank balance:** {new_bank:,} <:cowoncy:1385212758919745608>")
        
        else:
            await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid action! Use `deposit`, `withdraw`, or `all`.")

    @sys.command(name='job')
    async def sys_job(self, ctx, action: str = None, *, job_type: str = None):
        """Job system - apply, work, quit, or check job status"""
        if action is None:
            # Show job status and available jobs
            user_job = await self.db.get_user_job(ctx.author.id)
            user_stats = await self.db.get_user_job_stats(ctx.author.id)
            
            embed = discord.Embed(
                title="💼 Job Center",
                description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nManage your career and earn steady income!",
                color=0x000000
            )
            
            if user_job:
                job_info = JOB_TYPES[user_job]
                embed.add_field(
                    name="📋 Current Job",
                    value=f"{job_info['emoji']} **{job_info['name']}**\n{job_info['description']}\n"
                          f"**Pay Range:** {job_info['base_pay'][0]:,} - {job_info['base_pay'][1]:,} <:cowoncy:1385212758919745608>",
                    inline=False
                )
                
                embed.add_field(
                    name="📊 Your Stats",
                    value=f"**Experience:** {user_stats.get('experience', 0)} points\n"
                          f"**Education:** {user_stats.get('education', 0)} level\n"
                          f"**Times Worked:** {user_stats.get('times_worked', 0)}",
                    inline=True
                )
            else:
                embed.add_field(
                    name="📋 Current Job",
                    value="**Unemployed** - Use `sys job apply <job>` to get a job!",
                    inline=False
                )
            
            # Show available jobs
            available_jobs = []
            for job_id, job_info in JOB_TYPES.items():
                req_exp = job_info['requirements']['experience']
                req_edu = job_info['requirements']['education']
                
                if user_stats.get('experience', 0) >= req_exp and user_stats.get('education', 0) >= req_edu:
                    status = "<:icon_tick:1372375089668161597> Available"
                else:
                    status = f"<:icon_cross:1372375094336425986> Need {req_exp} XP, {req_edu} EDU"
                
                available_jobs.append(
                    f"{job_info['emoji']} **{job_info['name']}** - {job_info['base_pay'][0]:,}-{job_info['base_pay'][1]:,} <:cowoncy:1385212758919745608>\n"
                    f"   {status}"
                )
            
            embed.add_field(
                name="💼 Available Jobs",
                value="\n\n".join(available_jobs[:6]) if available_jobs else "No jobs available",
                inline=False
            )
            
            embed.add_field(
                name="💡 Commands",
                value=f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} job apply <job>` - Apply for a job\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} job work` - Work your current job\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} job quit` - Quit your current job\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} job study` - Increase education",
                inline=False
            )
            
            embed.set_author(
                name=f"{ctx.author.display_name}'s Career",
                icon_url=ctx.author.display_avatar.url
            )
            
            await ctx.send(embed=embed)
            return
        
        action = action.lower()
        
        if action == "apply":
            if job_type is None:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, specify a job to apply for! Available: {', '.join(JOB_TYPES.keys())}")
            
            job_key = job_type.lower()
            if job_key not in JOB_TYPES:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, that job doesn't exist! Available: {', '.join(JOB_TYPES.keys())}")
            
            # Check if already has a job
            current_job = await self.db.get_user_job(ctx.author.id)
            if current_job:
                current_job_info = JOB_TYPES[current_job]
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you already work as a {current_job_info['name']}! Quit first to apply for another job.")
            
            job_info = JOB_TYPES[job_key]
            user_stats = await self.db.get_user_job_stats(ctx.author.id)
            
            # Check requirements
            req_exp = job_info['requirements']['experience']
            req_edu = job_info['requirements']['education']
            user_exp = user_stats.get('experience', 0)
            user_edu = user_stats.get('education', 0)
            
            if user_exp < req_exp or user_edu < req_edu:
                return await ctx.send(
                    f"**🚫 | {ctx.author.display_name}**, you don't meet the requirements!\n"
                    f"**Required:** {req_exp} Experience, {req_edu} Education\n"
                    f"**You have:** {user_exp} Experience, {user_edu} Education"
                )
            
            # Apply for job
            await self.db.set_user_job(ctx.author.id, job_key)
            
            await ctx.send(
                f"🎉 **Congratulations!** {ctx.author.display_name} got hired as a {job_info['emoji']} **{job_info['name']}**!\n"
                f"Use `sys job work` to start earning {job_info['base_pay'][0]:,}-{job_info['base_pay'][1]:,} <:cowoncy:1385212758919745608>!"
            )
        
        elif action == "work":
            current_job = await self.db.get_user_job(ctx.author.id)
            if not current_job:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you need a job first! Use `sys job apply <job>`")
            
            # Check work cooldown (2 hours)
            current_time = datetime.now()
            last_job_work = await self.db.get_last_job_work_time(ctx.author.id)
            
            if last_job_work:
                last_work_dt = datetime.fromisoformat(last_job_work)
                time_diff = current_time - last_work_dt
                cooldown_hours = 2
                
                if time_diff < timedelta(hours=cooldown_hours):
                    remaining_time = timedelta(hours=cooldown_hours) - time_diff
                    next_use_time = int((current_time + remaining_time).timestamp())
                    
                    cooldown_msg = f"**💼 | {ctx.author.display_name}**, you're still on break! Next work shift **<t:{next_use_time}:R>**"
                    return await ctx.send(cooldown_msg, delete_after=int(remaining_time.total_seconds()))
            
            # Update work time
            await self.db.set_last_job_work_time(ctx.author.id, current_time.isoformat())
            
            job_info = JOB_TYPES[current_job]
            user_stats = await self.db.get_user_job_stats(ctx.author.id)
            
            # Calculate pay based on experience
            base_min, base_max = job_info['base_pay']
            experience_bonus = min(user_stats.get('experience', 0) * 0.02, 1.0)  # Max 100% bonus
            
            min_pay = int(base_min * (1 + experience_bonus))
            max_pay = int(base_max * (1 + experience_bonus))
            
            pay = random.randint(min_pay, max_pay)
            
            # Apply luck bonus
            user_luck = await self.db.get_user_luck(ctx.author.id)
            luck_bonus = int(pay * (user_luck * 0.01))  # 1% per luck point
            total_pay = pay + luck_bonus
            
            # Random bonus chance (10%)
            bonus_pay = 0
            if random.random() < 0.1:
                bonus_pay = random.randint(50, 200)
                total_pay += bonus_pay
            
            # Update user balance and stats
            user_balance = await self.db.get_user_balance(ctx.author.id)
            new_balance = user_balance + total_pay
            await self.db.update_user_balance(ctx.author.id, new_balance)
            
            # Gain experience and sometimes education
            exp_gain = random.randint(1, 3)
            new_experience = user_stats.get('experience', 0) + exp_gain
            times_worked = user_stats.get('times_worked', 0) + 1
            
            await self.db.update_user_job_stats(ctx.author.id, 
                                              experience=new_experience, 
                                              times_worked=times_worked)
            
            if random.random() < 0.1:  # 10% chance to gain education
                edu_gain = 1
                new_education = user_stats.get('education', 0) + edu_gain
                await self.db.update_user_job_stats(ctx.author.id, education=new_education)
                edu_msg = f"\n📚 **+{edu_gain} Education!**"
            else:
                edu_msg = ""
            
            # Create response
            message = f"**{job_info['emoji']} | {ctx.author.display_name}** worked as a {job_info['name']} and earned **{total_pay:,}** <:cowoncy:1385212758919745608>!"
            
            if bonus_pay > 0:
                message += f"\n🎉 **Bonus!** You got an extra **{bonus_pay:,}** <:cowoncy:1385212758919745608> for excellent work!"
            
            message += f"\n⭐ **+{exp_gain} Experience!**{edu_msg}"
            
            await ctx.send(message)
        
        elif action == "quit":
            current_job = await self.db.get_user_job(ctx.author.id)
            if not current_job:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have a job to quit!")
            
            job_info = JOB_TYPES[current_job]
            await self.db.set_user_job(ctx.author.id, None)
            
            await ctx.send(f"💼 **{ctx.author.display_name}** quit their job as a {job_info['emoji']} **{job_info['name']}**. Time to find new opportunities!")
        
        elif action == "study":
            # Check study cooldown (6 hours)
            current_time = datetime.now()
            last_study = await self.db.get_last_study_time(ctx.author.id)
            
            if last_study:
                last_study_dt = datetime.fromisoformat(last_study)
                time_diff = current_time - last_study_dt
                cooldown_hours = 6
                
                if time_diff < timedelta(hours=cooldown_hours):
                    remaining_time = timedelta(hours=cooldown_hours) - time_diff
                    next_use_time = int((current_time + remaining_time).timestamp())
                    
                    cooldown_msg = f"**📚 | {ctx.author.display_name}**, you're mentally exhausted! Study again **<t:{next_use_time}:R>**"
                    return await ctx.send(cooldown_msg, delete_after=int(remaining_time.total_seconds()))
            
            # Cost to study
            study_cost = 500
            user_balance = await self.db.get_user_balance(ctx.author.id)
            
            if user_balance < study_cost:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, studying costs **{study_cost:,}** <:cowoncy:1385212758919745608>!")
            
            # Process studying
            await self.db.update_user_balance(ctx.author.id, user_balance - study_cost)
            await self.db.set_last_study_time(ctx.author.id, current_time.isoformat())
            
            user_stats = await self.db.get_user_job_stats(ctx.author.id)
            edu_gain = random.randint(1, 2)
            new_education = user_stats.get('education', 0) + edu_gain
            await self.db.update_user_job_stats(ctx.author.id, education=new_education)
            
            await ctx.send(f"📚 **{ctx.author.display_name}** studied hard and gained **{edu_gain} Education** for **{study_cost:,}** <:cowoncy:1385212758919745608>!")
        
        elif action == "list":
            # Show all available jobs with their requirements
            embed = discord.Embed(
                title="💼 Available Jobs",
                description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nAll jobs in the job market",
                color=0x000000
            )
            
            user_stats = await self.db.get_user_job_stats(ctx.author.id)
            user_exp = user_stats.get('experience', 0)
            user_edu = user_stats.get('education', 0)
            
            for job_id, job_info in JOB_TYPES.items():
                req_exp = job_info['requirements']['experience']
                req_edu = job_info['requirements']['education']
                
                if user_exp >= req_exp and user_edu >= req_edu:
                    status = "✅ **Available**"
                else:
                    status = f"❌ Requires {req_exp} XP, {req_edu} EDU"
                
                embed.add_field(
                    name=f"{job_info['emoji']} {job_info['name']}",
                    value=f"{job_info['description']}\n"
                          f"**Pay:** {job_info['base_pay'][0]:,} - {job_info['base_pay'][1]:,} <:cowoncy:1385212758919745608>\n"
                          f"**Status:** {status}",
                    inline=True
                )
            
            embed.set_footer(text=f"Your stats: {user_exp} Experience, {user_edu} Education")
            await ctx.send(embed=embed)
        
        else:
            await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid action! Use `apply`, `work`, `quit`, `study`, or `list`.")

    @sys.command(name='taxstats')
    async def sys_taxstats(self, ctx):
        """View global tax collection statistics"""
        total_tax = await self.db.get_total_tax_collected()
        
        embed = discord.Embed(
            title="💸 Global Tax Collection Statistics",
            description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nAutomatic weekly tax system performance",
            color=0x000000
        )
        
        embed.add_field(
            name="📊 Total Tax Collected",
            value=f"**{total_tax:,}** <:cowoncy:1385212758919745608>",
            inline=False
        )
        
        embed.add_field(
            name="💡 Tax System Info",
            value="**Weekly Tax Brackets:**\n"
                  "• Wealth < 100,000: **0%**\n"
                  "• Wealth 100,000 - 500,000: **2%**\n"
                  "• Wealth 500,001 - 2,000,000: **5%**\n"
                  "• Wealth > 2,000,000: **10%**",
            inline=False
        )
        
        embed.add_field(
            name="🔄 Collection Schedule",
            value="Tax is automatically collected every 7 days based on total wealth (wallet + bank balance)",
            inline=False
        )
        
        embed.set_author(
            name=f"{ctx.guild.name} Tax Statistics",
            icon_url=ctx.guild.icon.url if ctx.guild.icon else ctx.bot.user.display_avatar.url
        )
        
        embed.set_footer(
            text="Tax funds support the server economy infrastructure",
            icon_url=ctx.bot.user.display_avatar.url
        )
        
        embed.timestamp = discord.utils.utcnow()
        
        await ctx.send(embed=embed)

    @sys.command(name='stocks', aliases=['stock'])
    async def sys_stocks(self, ctx, action: str = None, symbol: str = None, amount: int = None):
        """Stock market system - buy, sell, view portfolio, or check prices"""
        if action is None:
            # Show stock market overview with enhanced features
            embed = discord.Embed(
                title="📈 Strelizia Stock Exchange",
                description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nInvest your cowoncy in the stock market!",
                color=0x000000
            )
            
            # Show current stock prices with market indicators
            stock_prices = []
            total_market_cap = 0
            
            for symbol, company in STOCK_COMPANIES.items():
                current_price = await self.db.get_stock_price(symbol)
                if current_price is None:
                    current_price = company['base_price']
                    await self.db.set_stock_price(symbol, current_price)
                
                # Calculate market metrics
                market_cap = current_price * random.randint(10000, 100000)  # Simulated outstanding shares
                total_market_cap += market_cap
                
                # Calculate daily change
                yesterday_price = await self.db.get_stock_price_history(symbol, 1)
                if yesterday_price:
                    change = current_price - yesterday_price[0]
                    change_percent = (change / yesterday_price[0]) * 100
                    if change_percent > 5:
                        change_indicator = "🚀"
                    elif change_percent > 0:
                        change_indicator = "📈"
                    elif change_percent < -5:
                        change_indicator = "💥"
                    elif change_percent < 0:
                        change_indicator = "📉"
                    else:
                        change_indicator = "➡️"
                    change_text = f"{change_indicator} {change:+.2f} ({change_percent:+.1f}%)"
                else:
                    change_text = "➡️ --"
                
                # Volume simulation
                volume = random.randint(1000, 50000)
                
                stock_prices.append(
                    f"{company['emoji']} **{symbol}** - {current_price:.2f} <:cowoncy:1385212758919745608>\n"
                    f"   {company['name']} | {change_text}\n"
                    f"   Vol: {volume:,} | Cap: {market_cap:,.0f}"
                )
            
            embed.add_field(
                name="📊 Live Market Data",
                value="\n\n".join(stock_prices),
                inline=False
            )
            
            # Enhanced portfolio display
            portfolio = await self.db.get_user_portfolio(ctx.author.id)
            if portfolio:
                portfolio_value = 0
                portfolio_text = []
                total_invested = 0
                
                for stock_symbol, shares in portfolio.items():
                    if shares > 0:
                        current_price = await self.db.get_stock_price(stock_symbol)
                        stock_value = shares * current_price
                        portfolio_value += stock_value
                        
                        # Calculate profit/loss (using base price as "bought at" price for now)
                        bought_price = STOCK_COMPANIES[stock_symbol]['base_price']
                        invested = shares * bought_price
                        total_invested += invested
                        profit_loss = stock_value - invested
                        profit_percent = (profit_loss / invested) * 100 if invested > 0 else 0
                        
                        pl_indicator = "📈" if profit_loss > 0 else "📉" if profit_loss < 0 else "➡️"
                        
                        company = STOCK_COMPANIES[stock_symbol]
                        portfolio_text.append(
                            f"{company['emoji']} **{stock_symbol}** x{shares}\n"
                            f"   Value: {stock_value:.2f} | {pl_indicator} {profit_loss:+.2f} ({profit_percent:+.1f}%)"
                        )
                
                if portfolio_text:
                    total_pl = portfolio_value - total_invested
                    total_pl_percent = (total_pl / total_invested) * 100 if total_invested > 0 else 0
                    pl_emoji = "🟢" if total_pl > 0 else "🔴" if total_pl < 0 else "🟡"
                    
                    embed.add_field(
                        name="💼 Your Portfolio",
                        value="\n\n".join(portfolio_text) + 
                              f"\n\n**Portfolio Value:** {portfolio_value:.2f} <:cowoncy:1385212758919745608>\n"
                              f"**Total P&L:** {pl_emoji} {total_pl:+.2f} ({total_pl_percent:+.1f}%)",
                        inline=False
                    )
                else:
                    embed.add_field(
                        name="💼 Your Portfolio",
                        value="No stocks owned - Start investing today!",
                        inline=False
                    )
            else:
                embed.add_field(
                    name="💼 Your Portfolio",
                    value="No stocks owned - Start investing today!",
                    inline=False
                )
            
            # Market summary
            embed.add_field(
                name="🌍 Market Summary",
                value=f"**Total Market Cap:** {total_market_cap:,.0f} <:cowoncy:1385212758919745608>\n"
                      f"**Active Traders:** {len(await self.get_all_traders())} investors\n"
                      f"**Market Status:** 🟢 Open (24/7)",
                inline=True
            )
            
            embed.add_field(
                name="💡 Advanced Commands",
                value=f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} stocks buy <symbol> <amount>` - Buy stocks\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} stocks sell <symbol> <amount>` - Sell stocks\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} stocks portfolio` - Detailed portfolio\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} stocks graph <symbol>` - Price charts\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} stocks info <symbol>` - Company info\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} stocks leaderboard` - Top investors\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} stocks watchlist` - Track favorites",
                inline=False
            )
            
            embed.set_author(
                name=f"{ctx.author.display_name}'s Investment Dashboard",
                icon_url=ctx.author.display_avatar.url
            )
            
            embed.set_footer(
                text="💡 Tip: Diversify your portfolio to reduce risk!",
                icon_url=ctx.bot.user.display_avatar.url
            )
            
            await ctx.send(embed=embed)
            return
        
        action = action.lower()
        
        if action == "buy":
            if symbol is None or amount is None:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, usage: `sys stocks buy <symbol> <amount>`")
            
            symbol = symbol.upper()
            if symbol not in STOCK_COMPANIES:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid stock symbol! Available: {', '.join(STOCK_COMPANIES.keys())}")
            
            if amount <= 0:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, amount must be positive!")
            
            current_price = await self.db.get_stock_price(symbol)
            total_cost = current_price * amount
            
            user_balance = await self.db.get_user_balance(ctx.author.id)
            if user_balance < total_cost:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you need {total_cost:.2f} <:cowoncy:1385212758919745608> to buy {amount} shares of {symbol}!")
            
            # Process purchase
            await self.db.update_user_balance(ctx.author.id, user_balance - total_cost)
            await self.db.update_user_portfolio(ctx.author.id, symbol, amount)
            
            company = STOCK_COMPANIES[symbol]
            await ctx.send(
                f"📈 **{ctx.author.display_name}** bought **{amount}** shares of {company['emoji']} **{symbol}** "
                f"for **{total_cost:.2f}** <:cowoncy:1385212758919745608>!\n"
                f"Price per share: **{current_price:.2f}** <:cowoncy:1385212758919745608>"
            )
        
        elif action == "sell":
            if symbol is None or amount is None:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, usage: `sys stocks sell <symbol> <amount>`")
            
            symbol = symbol.upper()
            if symbol not in STOCK_COMPANIES:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid stock symbol!")
            
            if amount <= 0:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, amount must be positive!")
            
            portfolio = await self.db.get_user_portfolio(ctx.author.id)
            owned_shares = portfolio.get(symbol, 0)
            
            if owned_shares < amount:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you only own {owned_shares} shares of {symbol}!")
            
            current_price = await self.db.get_stock_price(symbol)
            total_value = current_price * amount
            
            # Process sale
            user_balance = await self.db.get_user_balance(ctx.author.id)
            await self.db.update_user_balance(ctx.author.id, user_balance + total_value)
            await self.db.update_user_portfolio(ctx.author.id, symbol, -amount)
            
            company = STOCK_COMPANIES[symbol]
            await ctx.send(
                f"📉 **{ctx.author.display_name}** sold **{amount}** shares of {company['emoji']} **{symbol}** "
                f"for **{total_value:.2f}** <:cowoncy:1385212758919745608>!\n"
                f"Price per share: **{current_price:.2f}** <:cowoncy:1385212758919745608>"
            )
        
        elif action == "graph":
            if symbol is None:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, specify a stock symbol!")
            
            symbol = symbol.upper()
            if symbol not in STOCK_COMPANIES:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid stock symbol!")
            
            # Generate price graph
            await ctx.send("📊 Generating stock chart...")
            
            try:
                graph_image = await self.generate_stock_graph(symbol)
                if graph_image:
                    company = STOCK_COMPANIES[symbol]
                    current_price = await self.db.get_stock_price(symbol)
                    
                    embed = discord.Embed(
                        title=f"📈 {symbol} Stock Chart",
                        description=f"{company['emoji']} **{company['name']}**\n"
                                  f"Current Price: **{current_price:.2f}** <:cowoncy:1385212758919745608>\n"
                                  f"Sector: {company['sector']}",
                        color=0x000000
                    )
                    
                    file = discord.File(graph_image, filename=f"{symbol}_chart.png")
                    embed.set_image(url=f"attachment://{symbol}_chart.png")
                    
                    await ctx.send(file=file, embed=embed)
                else:
                    await ctx.send("**<:icon_cross:1372375094336425986> | Error generating chart!**")
            except Exception as e:
                print(f"Stock graph error: {e}")
                await ctx.send("**<:icon_cross:1372375094336425986> | Error generating chart!**")
        
        elif action == "portfolio":
            # Detailed portfolio view
            portfolio = await self.db.get_user_portfolio(ctx.author.id)
            if not portfolio or all(shares == 0 for shares in portfolio.values()):
                return await ctx.send(f"**📈 | {ctx.author.display_name}**, your portfolio is empty! Start investing with `{self.economy_prefixes.get(ctx.guild.id, 'sys')} stocks buy <symbol> <amount>`")
            
            embed = discord.Embed(
                title=f"📊 {ctx.author.display_name}'s Investment Portfolio",
                description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
                color=0x000000
            )
            
            total_value = 0
            total_invested = 0
            holdings = []
            
            for stock_symbol, shares in portfolio.items():
                if shares > 0:
                    current_price = await self.db.get_stock_price(stock_symbol)
                    stock_value = shares * current_price
                    total_value += stock_value
                    
                    # Calculate investment metrics
                    bought_price = STOCK_COMPANIES[stock_symbol]['base_price']
                    invested = shares * bought_price
                    total_invested += invested
                    profit_loss = stock_value - invested
                    profit_percent = (profit_loss / invested) * 100 if invested > 0 else 0
                    
                    # Portfolio weight
                    weight = (invested / total_invested) * 100 if total_invested > 0 else 0
                    
                    company = STOCK_COMPANIES[stock_symbol]
                    status = "📈 Profit" if profit_loss > 0 else "📉 Loss" if profit_loss < 0 else "➡️ Break Even"
                    
                    holdings.append(
                        f"**{company['emoji']} {stock_symbol}** - {company['name']}\n"
                        f"Shares: {shares} | Price: {current_price:.2f}\n"
                        f"Value: {stock_value:.2f} | Weight: {weight:.1f}%\n"
                        f"{status}: {profit_loss:+.2f} ({profit_percent:+.1f}%)"
                    )
            
            embed.add_field(
                name="📈 Holdings",
                value="\n\n".join(holdings) if holdings else "No active positions",
                inline=False
            )
            
            # Portfolio summary
            total_pl = total_value - total_invested
            total_pl_percent = (total_pl / total_invested) * 100 if total_invested > 0 else 0
            performance_emoji = "🟢" if total_pl > 0 else "🔴" if total_pl < 0 else "🟡"
            
            embed.add_field(
                name="💼 Portfolio Summary",
                value=f"**Total Value:** {total_value:.2f} <:cowoncy:1385212758919745608>\n"
                      f"**Total Invested:** {total_invested:.2f} <:cowoncy:1385212758919745608>\n"
                      f"**P&L:** {performance_emoji} {total_pl:+.2f} ({total_pl_percent:+.1f}%)\n"
                      f"**Positions:** {len([s for s in portfolio.values() if s > 0])} stocks",
                inline=False
            )
            
            await ctx.send(embed=embed)
            
        elif action == "leaderboard":
            # Top investors leaderboard
            all_traders = await self.get_all_traders()
            leaderboard = []
            
            for trader_id in all_traders:
                portfolio = await self.db.get_user_portfolio(trader_id)
                if portfolio:
                    total_value = 0
                    for stock_symbol, shares in portfolio.items():
                        if shares > 0:
                            current_price = await self.db.get_stock_price(stock_symbol)
                            total_value += shares * current_price
                    
                    if total_value > 0:
                        user = ctx.guild.get_member(trader_id)
                        if user:
                            leaderboard.append((user, total_value))
            
            leaderboard.sort(key=lambda x: x[1], reverse=True)
            
            embed = discord.Embed(
                title="🏆 Top Investors Leaderboard",
                description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
                color=0x000000
            )
            
            if leaderboard:
                rankings = []
                medals = ["🥇", "🥈", "🥉"]
                
                for i, (user, value) in enumerate(leaderboard[:10], 1):
                    medal = medals[i-1] if i <= 3 else f"`{i:02d}`"
                    highlight = "**← YOU**" if user.id == ctx.author.id else ""
                    rankings.append(f"{medal} **{user.display_name}** - {value:.2f} <:cowoncy:1385212758919745608> {highlight}")
                
                embed.add_field(
                    name="📊 Portfolio Rankings",
                    value="\n".join(rankings),
                    inline=False
                )
                
                # Show user's rank if not in top 10
                user_rank = None
                for i, (user, value) in enumerate(leaderboard, 1):
                    if user.id == ctx.author.id:
                        user_rank = i
                        break
                
                if user_rank and user_rank > 10:
                    user_value = next(value for user, value in leaderboard if user.id == ctx.author.id)
                    embed.add_field(
                        name="📍 Your Position",
                        value=f"**#{user_rank}** - {user_value:.2f} <:cowoncy:1385212758919745608>",
                        inline=False
                    )
            else:
                embed.add_field(
                    name="📊 No Investors Yet",
                    value="Be the first to start investing!",
                    inline=False
                )
            
            await ctx.send(embed=embed)
            
        elif action == "watchlist":
            # Stock watchlist feature
            user_watchlist = await self.db.get_user_watchlist(ctx.author.id)
            
            embed = discord.Embed(
                title=f"👁️ {ctx.author.display_name}'s Stock Watchlist",
                description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
                color=0x000000
            )
            
            if user_watchlist:
                watchlist_display = []
                for symbol in user_watchlist:
                    if symbol in STOCK_COMPANIES:
                        company = STOCK_COMPANIES[symbol]
                        current_price = await self.db.get_stock_price(symbol)
                        
                        # Get price change
                        yesterday_price = await self.db.get_stock_price_history(symbol, 1)
                        if yesterday_price:
                            change = current_price - yesterday_price[0]
                            change_percent = (change / yesterday_price[0]) * 100
                            trend = "📈" if change > 0 else "📉" if change < 0 else "➡️"
                            change_text = f"{trend} {change:+.2f} ({change_percent:+.1f}%)"
                        else:
                            change_text = "➡️ --"
                        
                        watchlist_display.append(
                            f"{company['emoji']} **{symbol}** - {current_price:.2f} <:cowoncy:1385212758919745608>\n"
                            f"   {company['name']} | {change_text}"
                        )
                
                embed.add_field(
                    name="📊 Watched Stocks",
                    value="\n\n".join(watchlist_display),
                    inline=False
                )
            else:
                embed.add_field(
                    name="📊 Empty Watchlist",
                    value="Add stocks to track with:\n"
                          f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} stocks watch <symbol>`",
                    inline=False
                )
            
            embed.add_field(
                name="💡 Watchlist Commands",
                value=f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} stocks watch <symbol>` - Add to watchlist\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} stocks unwatch <symbol>` - Remove from watchlist\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} stocks watchlist` - View watchlist",
                inline=False
            )
            
            await ctx.send(embed=embed)
            
        elif action == "watch":
            if symbol is None:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, specify a stock symbol to watch!")
            
            symbol = symbol.upper()
            if symbol not in STOCK_COMPANIES:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid stock symbol!")
            
            await self.db.add_to_watchlist(ctx.author.id, symbol)
            company = STOCK_COMPANIES[symbol]
            await ctx.send(f"👁️ **Added {company['emoji']} {symbol}** to your watchlist!")
            
        elif action == "unwatch":
            if symbol is None:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, specify a stock symbol to unwatch!")
            
            symbol = symbol.upper()
            await self.db.remove_from_watchlist(ctx.author.id, symbol)
            await ctx.send(f"👁️ **Removed {symbol}** from your watchlist!")

        elif action == "info":
            if symbol is None:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, specify a stock symbol!")
            
            symbol = symbol.upper()
            if symbol not in STOCK_COMPANIES:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid stock symbol!")
            
            company = STOCK_COMPANIES[symbol]
            current_price = await self.db.get_stock_price(symbol)
            
            # Calculate performance metrics
            week_prices = await self.db.get_stock_price_history(symbol, 7)
            month_prices = await self.db.get_stock_price_history(symbol, 30)
            
            if week_prices and len(week_prices) > 1:
                week_change = current_price - week_prices[-1]
                week_change_percent = (week_change / week_prices[-1]) * 100
                week_high = max(week_prices)
                week_low = min(week_prices)
            else:
                week_change = 0
                week_change_percent = 0
                week_high = current_price
                week_low = current_price
            
            if month_prices and len(month_prices) > 1:
                month_change = current_price - month_prices[-1]
                month_change_percent = (month_change / month_prices[-1]) * 100
            else:
                month_change = 0
                month_change_percent = 0
            
            embed = discord.Embed(
                title=f"{company['emoji']} {company['name']} ({symbol})",
                description=f"**Sector:** {company['sector']} | **Exchange:** Strelizia Stock Exchange",
                color=0x000000
            )
            
            embed.add_field(
                name="💰 Current Price",
                value=f"**{current_price:.2f}** <:cowoncy:1385212758919745608>",
                inline=True
            )
            
            embed.add_field(
                name="📈 Performance",
                value=f"**7D:** {week_change:+.2f} ({week_change_percent:+.1f}%)\n"
                      f"**30D:** {month_change:+.2f} ({month_change_percent:+.1f}%)",
                inline=True
            )
            
            embed.add_field(
                name="📊 Price Range (7D)",
                value=f"**High:** {week_high:.2f}\n**Low:** {week_low:.2f}",
                inline=True
            )
            
            embed.add_field(
                name="📉 Risk Profile",
                value=f"**Volatility:** {company['volatility']*100:.1f}%\n"
                      f"**Risk:** {'High' if company['volatility'] > 0.2 else 'Medium' if company['volatility'] > 0.15 else 'Low'}",
                inline=True
            )
            
            # Market metrics
            market_cap = current_price * random.randint(50000, 200000)
            volume = random.randint(5000, 100000)
            
            embed.add_field(
                name="🌍 Market Data",
                value=f"**Market Cap:** {market_cap:,.0f}\n**Volume (24h):** {volume:,}",
                inline=True
            )
            
            # Show user's holdings
            portfolio = await self.db.get_user_portfolio(ctx.author.id)
            user_shares = portfolio.get(symbol, 0)
            if user_shares > 0:
                holdings_value = user_shares * current_price
                embed.add_field(
                    name="💼 Your Position",
                    value=f"**Shares:** {user_shares}\n**Value:** {holdings_value:.2f} <:cowoncy:1385212758919745608>",
                    inline=True
                )
            
            # Company description based on sector
            descriptions = {
                'Technology': "Leading innovator in cutting-edge technology solutions and digital transformation.",
                'Food & Beverage': "Global food and beverage company serving millions of customers worldwide.",
                'Automotive': "Revolutionary automotive manufacturer focused on sustainable transportation.",
                'Financial': "Premier financial institution providing comprehensive banking and investment services.",
                'Healthcare': "Advanced healthcare provider delivering life-saving medical treatments and technologies.",
                'Gaming': "Entertainment powerhouse creating immersive gaming experiences for players globally."
            }
            
            embed.add_field(
                name="📋 Company Overview",
                value=descriptions.get(company['sector'], "Established company with strong market presence."),
                inline=False
            )
            
            await ctx.send(embed=embed)
        
        else:
            await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid action! Use `buy`, `sell`, `graph`, `info`, `portfolio`, `leaderboard`, `watchlist`, `watch`, or `unwatch`.")

    @sys.command(name='crypto', aliases=['cryptocurrency'])
    async def sys_crypto(self, ctx, action: str = None, symbol: str = None, amount: float = None):
        """Cryptocurrency trading system with real-time charts"""
        if action is None:
            # Show crypto market overview
            embed = discord.Embed(
                title="₿ Strelizia Crypto Exchange",
                description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nTrade cryptocurrencies with live market data!",
                color=0x000000
            )
            
            # Show current crypto prices
            crypto_prices = []
            total_market_cap = 0
            
            for symbol, crypto in CRYPTO_CURRENCIES.items():
                current_price = await self.db.get_crypto_price(symbol)
                if current_price is None:
                    current_price = crypto['base_price']
                    await self.db.set_crypto_price(symbol, current_price)
                
                market_cap = crypto['market_cap']
                total_market_cap += market_cap
                
                # Calculate 24h change (simulated)
                change_percent = random.uniform(-10, 10)
                change_indicator = "🚀" if change_percent > 5 else "📈" if change_percent > 0 else "📉" if change_percent < -5 else "💥"
                
                crypto_prices.append(
                    f"{crypto['emoji']} **{symbol}** - {current_price:,.2f} <:cowoncy:1385212758919745608>\n"
                    f"   {crypto['name']} | {change_indicator} {change_percent:+.2f}%\n"
                    f"   Market Cap: {market_cap:,.0f} <:cowoncy:1385212758919745608>"
                )
            
            embed.add_field(
                name="📊 Live Market Data",
                value="\n\n".join(crypto_prices),
                inline=False
            )
            
            # Show user's crypto portfolio
            portfolio = await self.db.get_user_crypto_portfolio(ctx.author.id)
            if portfolio:
                portfolio_value = 0
                portfolio_text = []
                
                for crypto_symbol, amount in portfolio.items():
                    if amount > 0:
                        current_price = await self.db.get_crypto_price(crypto_symbol)
                        crypto_value = amount * current_price
                        portfolio_value += crypto_value
                        
                        crypto_data = CRYPTO_CURRENCIES[crypto_symbol]
                        portfolio_text.append(
                            f"{crypto_data['emoji']} **{crypto_symbol}** x{amount:.6f}\n"
                            f"   Value: {crypto_value:.2f} <:cowoncy:1385212758919745608>"
                        )
                
                if portfolio_text:
                    embed.add_field(
                        name="💼 Your Crypto Portfolio",
                        value="\n\n".join(portfolio_text) + f"\n\n**Total Value:** {portfolio_value:.2f} <:cowoncy:1385212758919745608>",
                        inline=False
                    )
            else:
                embed.add_field(
                    name="💼 Your Crypto Portfolio",
                    value="No cryptocurrencies owned - Start trading today!",
                    inline=False
                )
            
            embed.add_field(
                name="💡 Trading Commands",
                value=f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} crypto buy <symbol> <amount>` - Buy crypto\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} crypto sell <symbol> <amount>` - Sell crypto\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} crypto chart <symbol>` - Price charts\n"
                      f"`{self.economy_prefixes.get(ctx.guild.id, 'sys')} crypto convert <from> <to> <amount>` - Convert crypto",
                inline=False
            )
            
            await ctx.send(embed=embed)
            return
        
        action = action.lower()
        
        if action == "buy":
            if symbol is None or amount is None:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, usage: `sys crypto buy <symbol> <amount>`")
            
            symbol = symbol.upper()
            if symbol not in CRYPTO_CURRENCIES:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid crypto symbol! Available: {', '.join(CRYPTO_CURRENCIES.keys())}")
            
            if amount <= 0:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, amount must be positive!")
            
            current_price = await self.db.get_crypto_price(symbol)
            total_cost = current_price * amount
            
            user_balance = await self.db.get_user_balance(ctx.author.id)
            if user_balance < total_cost:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you need {total_cost:,.2f} <:cowoncy:1385212758919745608> to buy {amount} {symbol}!")
            
            # Process purchase
            await self.db.update_user_balance(ctx.author.id, user_balance - int(total_cost))
            await self.db.update_user_crypto_portfolio(ctx.author.id, symbol, amount)
            
            crypto = CRYPTO_CURRENCIES[symbol]
            await ctx.send(
                f"₿ **{ctx.author.display_name}** bought **{amount:.6f} {symbol}** "
                f"for **{total_cost:,.2f}** <:cowoncy:1385212758919745608>!\n"
                f"Price per coin: **{current_price:,.2f}** <:cowoncy:1385212758919745608>"
            )
        
        elif action == "sell":
            if symbol is None or amount is None:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, usage: `sys crypto sell <symbol> <amount>`")
            
            symbol = symbol.upper()
            if symbol not in CRYPTO_CURRENCIES:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid crypto symbol!")
            
            if amount <= 0:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, amount must be positive!")
            
            portfolio = await self.db.get_user_crypto_portfolio(ctx.author.id)
            owned_amount = portfolio.get(symbol, 0)
            
            if owned_amount < amount:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you only own {owned_amount:.6f} {symbol}!")
            
            current_price = await self.db.get_crypto_price(symbol)
            total_value = current_price * amount
            
            # Process sale
            user_balance = await self.db.get_user_balance(ctx.author.id)
            await self.db.update_user_balance(ctx.author.id, user_balance + int(total_value))
            await self.db.update_user_crypto_portfolio(ctx.author.id, symbol, -amount)
            
            crypto = CRYPTO_CURRENCIES[symbol]
            await ctx.send(
                f"💰 **{ctx.author.display_name}** sold **{amount:.6f} {symbol}** "
                f"for **{total_value:,.2f}** <:cowoncy:1385212758919745608>!\n"
                f"Price per coin: **{current_price:,.2f}** <:cowoncy:1385212758919745608>"
            )
        
        elif action == "chart":
            if symbol is None:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, specify a crypto symbol!")
            
            symbol = symbol.upper()
            if symbol not in CRYPTO_CURRENCIES:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid crypto symbol!")
            
            # Generate crypto chart (similar to stock chart)
            await ctx.send("📊 Generating crypto chart...")
            
            try:
                chart_image = await self.generate_crypto_chart(symbol)
                if chart_image:
                    crypto = CRYPTO_CURRENCIES[symbol]
                    current_price = await self.db.get_crypto_price(symbol)
                    
                    embed = discord.Embed(
                        title=f"₿ {symbol} Price Chart",
                        description=f"{crypto['emoji']} **{crypto['name']}**\n"
                                  f"Current Price: **{current_price:,.2f}** <:cowoncy:1385212758919745608>\n"
                                  f"Market Cap: **{crypto['market_cap']:,.0f}** <:cowoncy:1385212758919745608>",
                        color=0x000000
                    )
                    
                    file = discord.File(chart_image, filename=f"{symbol}_chart.png")
                    embed.set_image(url=f"attachment://{symbol}_chart.png")
                    
                    await ctx.send(file=file, embed=embed)
                else:
                    await ctx.send("**<:icon_cross:1372375094336425986> | Error generating chart!**")
            except Exception as e:
                print(f"Crypto chart error: {e}")
                await ctx.send("**<:icon_cross:1372375094336425986> | Error generating chart!**")
        
        else:
            await ctx.send(f"**🚫 | {ctx.author.display_name}**, invalid action! Use `buy`, `sell`, or `chart`.")

    async def generate_crypto_chart(self, symbol):
        """Generate a cryptocurrency price chart similar to stock charts"""
        try:
            from PIL import Image, ImageDraw, ImageFont
            import io
            
            # Similar to stock chart generation but with crypto styling
            width, height = 1000, 500
            img = Image.new('RGB', (width, height), color='#0d1421')  # Dark crypto theme
            draw = ImageDraw.Draw(img)
            
            # Generate price history for chart
            crypto = CRYPTO_CURRENCIES[symbol]
            current_price = await self.db.get_crypto_price(symbol)
            
            if current_price is None:
                current_price = crypto['base_price']
                await self.db.set_crypto_price(symbol, current_price)
            
            # Generate 30 days of price data
            price_history = []
            base_price = crypto['base_price']
            
            for i in range(30):
                if i == 0:
                    price = base_price
                else:
                    volatility = crypto['volatility']
                    change = random.uniform(-volatility, volatility) * 0.1
                    price = price_history[i-1] * (1 + change)
                    # Keep within reasonable bounds
                    price = max(price, base_price * 0.5)
                    price = min(price, base_price * 2.0)
                
                price_history.append(price)
            
            # Update current price to last generated price
            current_price = price_history[-1]
            await self.db.set_crypto_price(symbol, current_price)
            
            # Draw chart with crypto styling (orange/gold theme)
            margin_left, margin_right = 100, 80
            margin_top, margin_bottom = 80, 100
            
            graph_width = width - margin_left - margin_right  
            graph_height = height - margin_top - margin_bottom
            
            # Calculate price range
            min_price = min(price_history)
            max_price = max(price_history)
            price_range = max_price - min_price
            
            if price_range == 0:
                price_range = max_price * 0.1
            
            padding = price_range * 0.05
            min_price -= padding
            max_price += padding
            price_range = max_price - min_price
            
            # Draw title
            try:
                title_font = ImageFont.truetype("utils/arial.ttf", 28)
                font = ImageFont.truetype("utils/arial.ttf", 14)
                label_font = ImageFont.truetype("utils/arial.ttf", 12)
            except:
                title_font = ImageFont.load_default()
                font = ImageFont.load_default()
                label_font = ImageFont.load_default()
            
            title = f"{crypto['emoji']} {symbol} - {crypto['name']}"
            title_bbox = draw.textbbox((0, 0), title, font=title_font)
            title_width = title_bbox[2] - title_bbox[0]
            draw.text(((width - title_width) // 2, 25), title, fill='#f7931a', font=title_font)  # Bitcoin orange
            
            # Current price subtitle
            price_text = f"Current Price: {current_price:,.2f} <:cowoncy:1385212758919745608>"
            price_bbox = draw.textbbox((0, 0), price_text, font=font)
            price_width = price_bbox[2] - price_bbox[0]
            draw.text(((width - price_width) // 2, 55), price_text, fill='#cccccc', font=font)
            
            # Draw graph background
            graph_x, graph_y = margin_left, margin_top
            draw.rectangle([graph_x, graph_y, graph_x + graph_width, graph_y + graph_height], 
                          outline='#333333', width=2)
            
            # Draw grid
            for i in range(9):
                y = graph_y + (i * graph_height // 8)
                draw.line([graph_x, y, graph_x + graph_width, y], fill='#1a1a2e', width=1)
                
                if i <= 8:
                    price_value = max_price - (i * price_range / 8)
                    price_text = f"${price_value:.2f}"
                    text_bbox = draw.textbbox((0, 0), price_text, font=label_font)
                    text_width = text_bbox[2] - text_bbox[0]
                    draw.text((graph_x - text_width - 10, y - 8), price_text, fill='#cccccc', font=label_font)
            
            # Draw vertical grid lines
            for i in range(7):
                x = graph_x + (i * graph_width // 6)
                draw.line([x, graph_y, x, graph_y + graph_height], fill='#1a1a2e', width=1)
            
            # Draw price line
            points = []
            for i, price in enumerate(price_history):
                x = graph_x + (i * graph_width // (len(price_history) - 1))
                y = graph_y + graph_height - ((price - min_price) / price_range * graph_height)
                points.append((x, y))
            
            # Determine trend color
            trend_color = '#00d4aa' if price_history[-1] >= price_history[0] else '#ff6b6b'
            
            # Draw filled area under the line
            if len(points) > 1:
                fill_points = points + [(points[-1][0], graph_y + graph_height), 
                                       (points[0][0], graph_y + graph_height)]
                
                # Create polygon points as integers
                fill_points_int = [(int(x), int(y)) for x, y in fill_points]
                
                # Create overlay for transparency effect
                overlay = Image.new('RGBA', (width, height), (0, 0, 0, 0))
                overlay_draw = ImageDraw.Draw(overlay)
                
                if trend_color == '#00d4aa':
                    overlay_draw.polygon(fill_points_int, fill=(0, 212, 170, 30))
                else:
                    overlay_draw.polygon(fill_points_int, fill=(255, 107, 107, 30))
                
                # Composite with main image
                img = Image.alpha_composite(img.convert('RGBA'), overlay).convert('RGB')
                draw = ImageDraw.Draw(img)
            
            # Draw trend line
            for i in range(len(points) - 1):
                draw.line([points[i], points[i + 1]], fill=trend_color, width=3)
            
            # Draw points for last week
            for point in points[-7:]:  # Last week highlighted
                draw.ellipse([point[0] - 3, point[1] - 3, point[0] + 3, point[1] + 3], 
                           fill=trend_color, outline='#ffffff', width=1)
            
            # Current price dashed line
            if current_price >= min_price and current_price <= max_price:
                current_y = graph_y + graph_height - ((current_price - min_price) / price_range * graph_height)
                for x in range(graph_x, graph_x + graph_width, 12):
                    draw.line([x, current_y, min(x + 6, graph_x + graph_width), current_y], 
                             fill='#f7931a', width=2)
                
                # Current price label
                current_label = f"{current_price:.2f} <:cowoncy:1385212758919745608>"
                label_bbox = draw.textbbox((0, 0), current_label, font=font)
                label_width = label_bbox[2] - label_bbox[0]
                label_height = label_bbox[3] - label_bbox[1]
                
                label_x = graph_x + graph_width - label_width - 10
                label_y = current_y - label_height // 2
                
                # Background for label
                draw.rectangle([label_x - 5, label_y - 2, label_x + label_width + 5, label_y + label_height + 2], 
                              fill='#000000', outline='#f7931a', width=1)
                draw.text((label_x, label_y), current_label, fill='#f7931a', font=font)
            
            # Add time labels
            time_labels = ['30D', '25D', '20D', '15D', '10D', '5D', 'Now']
            for i, label in enumerate(time_labels):
                x_pos = graph_x + (i * graph_width // (len(time_labels) - 1))
                text_bbox = draw.textbbox((0, 0), label, font=label_font)
                text_width = text_bbox[2] - text_bbox[0]
                draw.text((x_pos - text_width // 2, graph_y + graph_height + 15), 
                         label, fill='#cccccc', font=label_font)
            
            # Add market cap and volatility info
            market_cap_text = f"Market Cap: {crypto['market_cap']:,.0f} <:cowoncy:1385212758919745608>"
            volatility_text = f"Volatility: {crypto['volatility']*100:.1f}%"
            
            draw.text((margin_left, graph_y + graph_height + 45), market_cap_text, fill='#cccccc', font=label_font)
            draw.text((margin_left + 300, graph_y + graph_height + 45), volatility_text, fill='#cccccc', font=label_font)
            
            # Add watermark
            watermark = "Strelizia Crypto Exchange"
            watermark_bbox = draw.textbbox((0, 0), watermark, font=label_font)
            watermark_width = watermark_bbox[2] - watermark_bbox[0]
            draw.text((width - watermark_width - 10, height - 20), watermark, 
                     fill='#666666', font=label_font)
            
            # Save to bytes
            img_bytes = io.BytesIO()
            img.save(img_bytes, format='PNG', quality=95, optimize=True)
            img_bytes.seek(0)
            
            return img_bytes
            
        except Exception as e:
            print(f"Crypto chart generation error: {e}")
            import traceback
            traceback.print_exc()
            return None

    @sys.command(name='cookie')
    async def sys_cookie(self, ctx, user: discord.Member = None):
        """Give or check cookies"""
        if user is None:
            # Check own cookies
            user_cookies = await self.db.get_user_cookies(ctx.author.id)
            await ctx.send(f"**<a:cookieeat:1385507680331894845> | {ctx.author.display_name}**! You currently have **{user_cookies}** cookies! Yummy! c:<\n"
                          f"** |** You have one cookie to send!")
        else:
            if user == ctx.author:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you can't give a cookie to yourself!", delete_after=3)

            if user.bot:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you can't give a cookie to a bot!", delete_after=3)

            # Give cookie to user
            user_cookies = await self.db.get_user_cookies(user.id)
            new_cookies = user_cookies + 1
            await self.db.update_user_cookies(user.id, new_cookies)

            await ctx.send(f"**<a:cookieeat:1385507680331894845> | {user.mention}**! You got a cookie from **{ctx.author.mention}**! *nom nom nom c:<*")

    @sys.command(name='prefix')
    @commands.has_permissions(administrator=True)
    async def sys_prefix(self, ctx, prefix: str = None):
        """Set a custom prefix for economy commands"""
        if prefix is None:
            current_prefix = self.economy_prefixes.get(ctx.guild.id, "sys")
            return await ctx.send(f"**💰 | Current economy prefix:** `{current_prefix}`\n"
                                f"**Usage:** `sys prefix <new_prefix>`")

        if len(prefix) > 10:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, prefix cannot be longer than 10 characters!", delete_after=3)

        # Store the prefix for this guild
        await self.db.set_economy_prefix(ctx.guild.id, prefix)
        self.economy_prefixes[ctx.guild.id] = prefix

        await ctx.send(f"**⚙️ | {ctx.author.display_name}**, you successfully changed my server prefix to **`{prefix}`**! I love it <3")

    @commands.Cog.listener()
    async def on_message(self, message):
        """Listen for custom economy prefix commands"""
        if message.author.bot or not message.guild or not message.content:
            return

        guild_id = message.guild.id
        custom_prefix = self.economy_prefixes.get(guild_id)

        if not custom_prefix:
            return

        # Check if message starts with custom prefix
        if not message.content.startswith(custom_prefix):
            return

        # Handle prefix with or without space after it
        content_after_prefix = message.content[len(custom_prefix):]
        
        # If there's a space after prefix, strip it. If not, check if the next char is alphanumeric
        if content_after_prefix.startswith(' '):
            content = content_after_prefix[1:]  # Remove the space
        elif content_after_prefix and (content_after_prefix[0].isalnum() or content_after_prefix[0] in ['_', '-']):
            content = content_after_prefix  # No space but valid command
        else:
            return  # Invalid format

        if not content:
            # Show main help if just prefix is used
            ctx = await self.bot.get_context(message)
            await self._show_main_help(ctx)
            return

        parts = content.split()
        command_name = parts[0].lower()
        args = parts[1:] if len(parts) > 1 else []

        # Complete map of economy commands to their methods
        economy_commands = {
            # Main help command
            'help': ('sys_help', 'text'),
            
            # Currency commands
            'cash': ('sys_cash', 'user'),
            'cowoncy': ('sys_cash', 'user'),
            
            # Transaction commands
            'give': ('sys_give', 'amount_user'),
            
            # Earning commands
            'work': ('sys_work', 'none'),
            'beg': ('sys_beg', 'none'),
            'daily': ('sys_daily', 'none'),
            'trivia': ('sys_trivia', 'none'),
            'lottery': ('sys_lottery', 'none'),
            
            # Gambling commands
            'slots': ('sys_slots', 'amount'),
            's': ('sys_slots', 'amount'),
            'coinflip': ('sys_coinflip', 'amount_choice'),
            'cf': ('sys_coinflip', 'amount_choice'),
            'blackjack': ('sys_blackjack', 'amount'),
            'bj': ('sys_blackjack', 'amount'),
            
            # Shop commands
            'shop': ('sys_shop', 'none'),
            'buy': ('sys_buy', 'item_id'),
            'sell': ('sys_sell_unified', 'text'),
            
            # Inventory and marriage
            'inventory': ('sys_inventory', 'user'),
            'inv': ('sys_inventory', 'user'),
            'marry': ('sys_marry', 'user_ring_id'),
            
            # Leaderboard and bank
            'baltop': ('sys_baltop', 'none'),
            'leaderboard': ('sys_baltop', 'none'),
            'rich': ('sys_baltop', 'none'),
            'bank': ('sys_bank', 'bank_args'),
            
            # Social commands
            'pray': ('sys_pray', 'user'),
            'curse': ('sys_curse', 'user'),
            'cookie': ('sys_cookie', 'user'),
            
            # Job system
            'job': ('sys_job', 'job_args'),
            
            # Stock market
            'stocks': ('sys_stocks', 'stock_args'),
            'stock': ('sys_stocks', 'stock_args'),
            
            # Cryptocurrency
            'crypto': ('sys_crypto', 'stock_args'),
            'cryptocurrency': ('sys_crypto', 'stock_args'),
            
            # Money management
            'money': ('sys_money', 'money_args'),
            'finance': ('sys_finance', 'finance_args'),
            'wealth': ('sys_wealth', 'none'),
            
            # Utility commands
            'emoji': ('sys_emoji', 'emoji'),
            'sysify': ('sys_sysify', 'text'),
            'avatar': ('sys_avatar', 'user'),
            'av': ('sys_avatar', 'user'),
            
            # Zoo commands
            'zoo': ('sys_zoo', 'user'),
            'hunt': ('sys_hunt', 'none'),
            'h': ('sys_hunt', 'none'),
            
            
            
            # Roleplay commands
            'hug': ('sys_hug', 'user'),
            'kiss': ('sys_kiss', 'user'),
            'cuddle': ('sys_cuddle', 'user'),
            'pat': ('sys_pat', 'user'),
            'slap': ('sys_slap', 'user'),
            'tickle': ('sys_tickle', 'user'),
            'poke': ('sys_poke', 'user'),
            'wave': ('sys_wave', 'user'),
            'dance': ('sys_dance', 'none'),
            'cry': ('sys_cry', 'none'),
            'laugh': ('sys_laugh', 'none'),
            'smile': ('sys_smile', 'none'),
            'blush': ('sys_blush', 'none'),
            'wink': ('sys_wink', 'user'),
            'thumbsup': ('sys_thumbsup', 'none'),
            'clap': ('sys_clap', 'none'),
            'bow': ('sys_bow', 'user'),
            'salute': ('sys_salute', 'user'),
            'facepalm': ('sys_facepalm', 'none'),
            'shrug': ('sys_shrug', 'none'),
            'sleep': ('sys_sleep', 'none'),
            'eat': ('sys_eat', 'none'),
            'drink': ('sys_drink', 'none'),
            'run': ('sys_run', 'none'),
            'lewd': ('sys_lewd', 'user'),
            'pout': ('sys_pout', 'none'),
            'sleepy': ('sys_sleepy', 'none'),
            'smug': ('sys_smug', 'none'),
            'wag': ('sys_wag', 'none'),
            'thinking': ('sys_thinking', 'none'),
            'triggered': ('sys_triggered', 'none'),
            'teehee': ('sys_teehee', 'none'),
            'deredere': ('sys_deredere', 'none'),
            'thonking': ('sys_thonking', 'none'),
            'scoff': ('sys_scoff', 'none'),
            'happy': ('sys_happy', 'none'),
            'thumbs': ('sys_thumbs', 'none'),
            'grin': ('sys_grin', 'none'),
            'lick': ('sys_lick', 'user'),
            'nom': ('sys_nom', 'user'),
            'stare': ('sys_stare', 'user'),
            'highfive': ('sys_highfive', 'user'),
            'bite': ('sys_bite', 'user'),
            'greet': ('sys_greet', 'user'),
            'punch': ('sys_punch', 'user'),
            'handholding': ('sys_handholding', 'user'),
            'kill': ('sys_kill', 'user'),
            'hold': ('sys_hold', 'user'),
            'pats': ('sys_pats', 'user'),
            'boop': ('sys_boop', 'user'),
            'snuggle': ('sys_snuggle', 'user'),
            'bully': ('sys_bully', 'user'),
            
            # Admin commands
            'prefix': ('sys_prefix', 'text')
        }

        if command_name not in economy_commands:
            return

        method_name, arg_type = economy_commands[command_name]
        
        # Check if method exists
        if not hasattr(self, method_name):
            print(f"Method {method_name} not found for command {command_name}")
            return
            
        method = getattr(self, method_name)

        # Create a proper context from the message
        ctx = await self.bot.get_context(message)
        
        # Override the command to prevent conflicts with regular command processing
        ctx.command = None

        try:
            if arg_type == 'none':
                await method(ctx)
                
            elif arg_type == 'user':
                user = None
                if args:
                    try:
                        # Try different user mention formats
                        user_arg = args[0]
                        if user_arg.startswith('<@') and user_arg.endswith('>'):
                            # Handle mention format
                            user_id = int(user_arg.strip('<@!>'))
                            user = ctx.guild.get_member(user_id)
                        else:
                            # Try converter
                            user = await commands.MemberConverter().convert(ctx, user_arg)
                    except Exception as e:
                        print(f"User conversion error: {e}")
                        pass
                await method(ctx, user)
                
            elif arg_type == 'amount':
                amount = None
                if args:
                    try:
                        amount = int(args[0].replace(',', ''))  # Remove commas from numbers
                    except ValueError:
                        pass
                await method(ctx, amount)
                
            elif arg_type == 'amount_user':
                amount = None
                user = None
                if len(args) >= 1:
                    try:
                        amount = int(args[0].replace(',', ''))
                    except ValueError:
                        pass
                if len(args) >= 2:
                    try:
                        user_arg = args[1]
                        if user_arg.startswith('<@') and user_arg.endswith('>'):
                            user_id = int(user_arg.strip('<@!>'))
                            user = ctx.guild.get_member(user_id)
                        else:
                            user = await commands.MemberConverter().convert(ctx, user_arg)
                    except Exception as e:
                        print(f"User conversion error in amount_user: {e}")
                        pass
                await method(ctx, amount, user)
                
            elif arg_type == 'amount_choice':
                amount = None
                choice = "heads"
                if len(args) >= 1:
                    try:
                        amount = int(args[0].replace(',', ''))
                    except ValueError:
                        pass
                if len(args) >= 2:
                    choice = args[1]
                await method(ctx, amount, choice)
                
            elif arg_type == 'item_id':
                item_id = None
                if args:
                    try:
                        item_id = int(args[0])
                    except ValueError:
                        pass
                await method(ctx, item_id)
                
            elif arg_type == 'user_ring_id':
                user = None
                ring_id = None
                if len(args) >= 1:
                    try:
                        user_arg = args[0]
                        if user_arg.startswith('<@') and user_arg.endswith('>'):
                            user_id = int(user_arg.strip('<@!>'))
                            user = ctx.guild.get_member(user_id)
                        else:
                            user = await commands.MemberConverter().convert(ctx, user_arg)
                    except Exception as e:
                        print(f"User conversion error in user_ring_id: {e}")
                        pass
                if len(args) >= 2:
                    try:
                        ring_id = int(args[1])
                    except ValueError:
                        pass
                await method(ctx, user, ring_id)
                
            elif arg_type == 'emoji':
                emoji = None
                if args:
                    emoji_str = args[0]
                    try:
                        # Try custom emoji first
                        emoji = await commands.EmojiConverter().convert(ctx, emoji_str)
                    except:
                        try:
                            # Try partial emoji
                            emoji = await commands.PartialEmojiConverter().convert(ctx, emoji_str)
                        except:
                            # Use as unicode emoji string
                            emoji = emoji_str
                await method(ctx, emoji)
                
            elif arg_type == 'text':
                text = None
                if args:
                    text = ' '.join(args)
                elif command_name == 'help':
                    # For help command, if no args provided, show main help
                    text = None
                if command_name == 'prefix':
                    await method(ctx, text)
                elif command_name == 'sysify':
                    await method(ctx, text=text)
                elif command_name in ['teamadd', 'teamremove']:
                    await method(ctx, text)
                else:
                    await method(ctx, text)
                
            elif arg_type == 'team_args':
                await method(ctx, args)
            
            elif arg_type == 'bank_args':
                action = args[0] if len(args) > 0 else None
                amount = None
                if len(args) > 1:
                    try:
                        amount = int(args[1].replace(',', ''))
                    except ValueError:
                        pass
                await method(ctx, action, amount)
            
            elif arg_type == 'job_args':
                action = args[0] if len(args) > 0 else None
                job_type = ' '.join(args[1:]) if len(args) > 1 else None
                await method(ctx, action, job_type=job_type)
            
            elif arg_type == 'stock_args':
                action = args[0] if len(args) > 0 else None
                symbol = args[1] if len(args) > 1 else None
                amount = None
                if len(args) > 2:
                    try:
                        amount = int(args[2].replace(',', ''))
                    except ValueError:
                        pass
                await method(ctx, action, symbol, amount)
                
            elif arg_type == 'money_args':
                action = args[0] if len(args) > 0 else None
                amount = None
                user = None
                if len(args) > 1:
                    try:
                        amount = int(args[1].replace(',', ''))
                    except ValueError:
                        # If not a number, might be a user mention
                        try:
                            user_arg = args[1]
                            if user_arg.startswith('<@') and user_arg.endswith('>'):
                                user_id = int(user_arg.strip('<@!>'))
                                user = ctx.guild.get_member(user_id)
                            else:
                                user = await commands.MemberConverter().convert(ctx, user_arg)
                        except:
                            pass
                if len(args) > 2 and amount is not None:
                    try:
                        user_arg = args[2]
                        if user_arg.startswith('<@') and user_arg.endswith('>'):
                            user_id = int(user_arg.strip('<@!>'))
                            user = ctx.guild.get_member(user_id)
                        else:
                            user = await commands.MemberConverter().convert(ctx, user_arg)
                    except:
                        pass
                elif len(args) > 1 and amount is None and user is None:
                    # Check if args[1] is a user mention for stats/breakdown commands
                    try:
                        user_arg = args[1]
                        if user_arg.startswith('<@') and user_arg.endswith('>'):
                            user_id = int(user_arg.strip('<@!>'))
                            user = ctx.guild.get_member(user_id)
                        else:
                            user = await commands.MemberConverter().convert(ctx, user_arg)
                    except:
                        pass
                await method(ctx, action, amount, user)
                
            elif arg_type == 'finance_args':
                action = args[0] if len(args) > 0 else None
                await method(ctx, action)
                
            elif arg_type == 'team_args':
                await method(ctx, args)
                    
        except Exception as e:
            # Send raw error to channel for debugging
            error_msg = f"**🚫 DEBUG ERROR for `{command_name}`:**\n```python\n{type(e).__name__}: {str(e)}\n```"
            await ctx.send(error_msg)
            
            # Also print full traceback to console
            print(f"Economy prefix command error for {command_name}: {e}")
            import traceback
            traceback.print_exc()
    
    

    async def load_economy_prefixes(self):
        """Load economy prefixes from database on startup"""
        prefixes = await self.db.get_all_economy_prefixes()
        for guild_id, prefix in prefixes:
            self.economy_prefixes[guild_id] = prefix

    async def _show_main_help(self, ctx):
        """Show main economy help with interactive dropdown"""
        current_prefix = self.economy_prefixes.get(ctx.guild.id, "sys")
        
        embed = discord.Embed(
            title="<:cowoncy:1385212758919745608> Economy System Commands",
            description=f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nAll economy commands available in this server.",
            color=0x000000
        )
        
        # Currency Commands
        embed.add_field(
            name="<:icon_categories:1372375027340804176> **Currency Commands**",
            value=f"`{current_prefix} cash [user]` - Check cowoncy balance\n"
                  f"`{current_prefix} give <amount> <user>` - Give cowoncy to another user\n"
                  f"`{current_prefix} baltop` - View server wealth leaderboard\n"
                  f"`{current_prefix} cookie [user]` - Give or check cookies",
            inline=False
        )
        
        # Earning Commands
        embed.add_field(
            name="💼 **Earning Commands**",
            value=f"`{current_prefix} work` - Work jobs for cowoncy (1h cooldown)\n"
                  f"`{current_prefix} beg` - Beg for cowoncy (30min cooldown)\n"
                  f"`{current_prefix} daily` - Daily reward with streaks\n"
                  f"`{current_prefix} trivia` - Answer questions for rewards\n"
                  f"`{current_prefix} lottery` - Buy lottery tickets",
            inline=False
        )
        
        # Gambling Commands
        embed.add_field(
            name="🎰 **Gambling Commands**",
            value=f"`{current_prefix} slots <amount>` - Play slot machine\n"
                  f"`{current_prefix} coinflip <amount> [choice]` - Flip a coin\n"
                  f"`{current_prefix} blackjack <amount>` - Play blackjack",
            inline=False
        )
        
        embed.set_author(
            name=f"{ctx.author.display_name}'s Economy Help",
            icon_url=ctx.author.display_avatar.url
        )
        
        embed.set_footer(
            text=f"Current prefix: {current_prefix} | Use the dropdown below to explore categories",
            icon_url=ctx.bot.user.display_avatar.url
        )
        
        # Create and send the interactive view
        view = EconomyHelpView(ctx, current_prefix, embed)
        await ctx.send(embed=embed, view=view)

    async def sys_help(self, ctx, command_name: str = None):
        """Economy help command"""
        if command_name is None:
            await self._show_main_help(ctx)
        else:
            # Show specific command help
            await ctx.send(f"Help for specific command `{command_name}` is not implemented yet.")

    # Add missing roleplay commands
    async def sys_hug(self, ctx, user: discord.Member = None):
        """Hug someone"""
        await self.create_action_embed(ctx, "hug", user)

    async def sys_kiss(self, ctx, user: discord.Member = None):
        """Kiss someone"""
        await self.create_action_embed(ctx, "kiss", user)

    async def sys_cuddle(self, ctx, user: discord.Member = None):
        """Cuddle with someone"""
        await self.create_action_embed(ctx, "cuddle", user)

    async def sys_pat(self, ctx, user: discord.Member = None):
        """Pat someone"""
        await self.create_action_embed(ctx, "pat", user)

    async def sys_slap(self, ctx, user: discord.Member = None):
        """Slap someone playfully"""
        await self.create_action_embed(ctx, "slap", user)

    async def sys_dance(self, ctx):
        """Dance"""
        await self.create_action_embed(ctx, "dance")

    async def sys_cry(self, ctx):
        """Cry"""
        await self.create_action_embed(ctx, "cry")

    async def sys_smile(self, ctx):
        """Smile"""
        await self.create_action_embed(ctx, "smile")

    async def sys_blush(self, ctx):
        """Blush"""
        await self.create_action_embed(ctx, "blush")

    async def sys_emoji(self, ctx, emoji=None):
        """Show emoji info"""
        if emoji is None:
            return await ctx.send("Please provide an emoji!")
        
        embed = discord.Embed(title="Emoji Info", color=0x000000)
        
        if hasattr(emoji, 'url'):
            # Custom emoji
            embed.set_image(url=str(emoji.url))
            embed.add_field(name="Name", value=emoji.name, inline=True)
            embed.add_field(name="ID", value=emoji.id, inline=True)
            embed.add_field(name="Animated", value=emoji.animated, inline=True)
        else:
            # Unicode emoji
            embed.add_field(name="Emoji", value=str(emoji), inline=True)
        
        await ctx.send(embed=embed)

    async def sys_sysify(self, ctx, *, text: str = None):
        """Transform text into cute SyS style"""
        if text is None:
            return await ctx.send("Please provide text to sysify!")
        
        # Simple transformation - add cute elements
        sysified = text.replace("!", "! ✨").replace("?", "? 🤔").replace(".", ". uwu")
        await ctx.send(f"**Sysified:** {sysified} 💕")

    async def sys_avatar(self, ctx, user: discord.Member = None):
        """Show user's avatar"""
        target_user = user or ctx.author
        
        embed = discord.Embed(
            title=f"{target_user.display_name}'s Avatar",
            color=0x000000
        )
        embed.set_image(url=target_user.display_avatar.url)
        
        await ctx.send(embed=embed)

    async def sys_zoo(self, ctx, user: discord.Member = None):
        """View zoo collection"""
        target_user = user or ctx.author
        zoo_data = await self.db.get_user_zoo(target_user.id)
        
        embed = discord.Embed(
            title=f"{target_user.display_name}'s Zoo",
            color=0x000000
        )
        
        if zoo_data and any(any(animals.values()) for animals in zoo_data.values() if isinstance(animals, dict)):
            # Calculate stats
            points, rarity_counts = self.calculate_zoo_points(zoo_data)
            
            # Display animals by rarity
            zoo_display = []
            
            for rarity in ['mythic', 'epic', 'rare', 'uncommon', 'common']:
                if rarity in zoo_data and zoo_data[rarity]:
                    rarity_animals = []
                    for emoji, count in zoo_data[rarity].items():
                        if count > 0 and emoji in ZOO_ANIMALS[rarity]:
                            animal_name = ZOO_ANIMALS[rarity][emoji]['name']
                            rarity_animals.append(f"{emoji} **{animal_name}** `x{count}`")
                    
                    if rarity_animals:
                        zoo_display.append(f"\n{RARITY_COLORS[rarity]} **{rarity.title()}** ({len(rarity_animals)})")
                        zoo_display.extend(rarity_animals)
            
            if zoo_display:
                embed.description = "\n".join(zoo_display)
                embed.add_field(
                    name="📊 Zoo Stats",
                    value=f"**Total Animals:** {sum(rarity_counts.values())}\n**Zoo Points:** {points:,}",
                    inline=False
                )
            else:
                embed.description = "No animals found! Use `sys hunt` to start collecting."
        else:
            embed.description = "No animals found! Use `sys hunt` to start collecting."
        
        embed.set_author(
            name=f"{target_user.display_name}'s Zoo Collection",
            icon_url=target_user.display_avatar.url
        )
        
        embed.set_footer(
            text="Use 'sys hunt' to find more animals!",
            icon_url=ctx.bot.user.display_avatar.url
        )
        
        await ctx.send(embed=embed)

    async def sys_hunt(self, ctx):
        """Hunt for animals"""
        user_id = ctx.author.id
        current_time = datetime.now()
        
        # Check cooldown (15 minutes)
        last_hunt = await self.db.get_last_hunt_time(user_id)
        
        if last_hunt:
            last_hunt_dt = datetime.fromisoformat(last_hunt)
            time_diff = current_time - last_hunt_dt
            cooldown_minutes = 15
            
            if time_diff < timedelta(minutes=cooldown_minutes):
                remaining_time = timedelta(minutes=cooldown_minutes) - time_diff
                next_use_time = int((current_time + remaining_time).timestamp())
                
                cooldown_msg = f"**🦁 | {ctx.author.display_name}**, you're still searching! Try hunting again **<t:{next_use_time}:R>**"
                return await ctx.send(cooldown_msg, delete_after=int(remaining_time.total_seconds()))
        
        # Update hunt time
        await self.db.set_last_hunt_time(user_id, current_time.isoformat())
        
        # Get random animal with luck bonus
        user_luck = await self.db.get_user_luck(user_id)
        animal_emoji, rarity = self.get_random_animal(user_luck)
        
        # Get or create user's zoo
        zoo_data = await self.db.get_user_zoo(user_id)
        if not zoo_data:
            zoo_data = {
                'common': {},
                'uncommon': {},
                'rare': {},
                'epic': {},
                'mythic': {}
            }
        
        # Add animal to zoo
        if rarity not in zoo_data:
            zoo_data[rarity] = {}
        
        if animal_emoji not in zoo_data[rarity]:
            zoo_data[rarity][animal_emoji] = 0
        
        zoo_data[rarity][animal_emoji] += 1
        
        # Save updated zoo
        await self.db.update_user_zoo(user_id, zoo_data)
        
        # Create result embed
        animal_data = ZOO_ANIMALS[rarity][animal_emoji]
        rarity_color = {
            'common': 0x808080,
            'uncommon': 0x1f8b4c,
            'rare': 0x3498db,
            'epic': 0x9b59b6,
            'mythic': 0xe74c3c
        }
        
        embed = discord.Embed(
            title="🦁 Hunt Results",
            description=f"You found {animal_emoji} **{animal_data['name'].title()}**!\n"
                       f"**Rarity:** {RARITY_COLORS[rarity]} {rarity.title()}\n"
                       f"**HP:** {animal_data['hp']} | **Attack:** {animal_data['attack']}\n"
                       f"**You now have:** {zoo_data[rarity][animal_emoji]} {animal_emoji}",
            color=rarity_color[rarity]
        )
        
        embed.set_author(
            name=f"{ctx.author.display_name}'s Hunt",
            icon_url=ctx.author.display_avatar.url
        )
        
        await ctx.send(embed=embed)

    # Add other missing roleplay commands with basic implementations
    async def sys_wink(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "wink", user)

    async def sys_thumbsup(self, ctx):
        await self.create_action_embed(ctx, "thumbsup")

    async def sys_bow(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "bow", user)

    async def sys_salute(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "salute", user)

    async def sys_facepalm(self, ctx):
        await self.create_action_embed(ctx, "facepalm")

    async def sys_shrug(self, ctx):
        await self.create_action_embed(ctx, "shrug")

    async def sys_sleep(self, ctx):
        await self.create_action_embed(ctx, "sleep")

    async def sys_eat(self, ctx):
        await self.create_action_embed(ctx, "eat")

    async def sys_drink(self, ctx):
        await self.create_action_embed(ctx, "drink")

    async def sys_run(self, ctx):
        await self.create_action_embed(ctx, "run")

    async def sys_lewd(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "lewd", user)

    async def sys_pout(self, ctx):
        await self.create_action_embed(ctx, "pout")

    async def sys_sleepy(self, ctx):
        await self.create_action_embed(ctx, "sleepy")

    async def sys_smug(self, ctx):
        await self.create_action_embed(ctx, "smug")

    async def sys_wag(self, ctx):
        await self.create_action_embed(ctx, "wag")

    async def sys_thinking(self, ctx):
        await self.create_action_embed(ctx, "thinking")

    async def sys_triggered(self, ctx):
        await self.create_action_embed(ctx, "triggered")

    async def sys_teehee(self, ctx):
        await self.create_action_embed(ctx, "teehee")

    async def sys_deredere(self, ctx):
        await self.create_action_embed(ctx, "deredere")

    async def sys_thonking(self, ctx):
        await self.create_action_embed(ctx, "thonking")

    async def sys_scoff(self, ctx):
        await self.create_action_embed(ctx, "scoff")

    async def sys_happy(self, ctx):
        await self.create_action_embed(ctx, "happy")

    async def sys_thumbs(self, ctx):
        await self.create_action_embed(ctx, "thumbs")

    async def sys_grin(self, ctx):
        await self.create_action_embed(ctx, "grin")

    async def sys_tickle(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "tickle", user)

    async def sys_poke(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "poke", user)

    async def sys_wave(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "wave", user)

    async def sys_lick(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "lick", user)

    async def sys_nom(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "nom", user)

    async def sys_stare(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "stare", user)

    async def sys_highfive(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "highfive", user)

    async def sys_bite(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "bite", user)

    async def sys_greet(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "greet", user)

    async def sys_punch(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "punch", user)

    async def sys_handholding(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "handholding", user)

    async def sys_kill(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "kill", user)

    async def sys_hold(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "hold", user)

    async def sys_pats(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "pats", user)

    async def sys_boop(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "boop", user)

    async def sys_snuggle(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "snuggle", user)

    async def sys_bully(self, ctx, user: discord.Member = None):
        await self.create_action_embed(ctx, "bully", user)

    async def sys_laugh(self, ctx):
        await self.create_action_embed(ctx, "laugh")

    async def sys_clap(self, ctx):
        await self.create_action_embed(ctx, "clap")

    async def create_action_embed(self, ctx, action, target=None):
        """Create and send an action embed with GIF"""
        if target and target.id == ctx.author.id:
            embed = discord.Embed(
                description="You can't perform this action on yourself! Try targeting someone else.",
                color=0x000000
            )
            embed.set_footer(text="Choose a different target")
            return await ctx.send(embed=embed)

        # Get the best GIF for this action
        gif_url = await self.get_tenor_gif(action)

        # Simple action messages
        if target:
            message = f"**{ctx.author.display_name}** {action}s **{target.display_name}**!"
        else:
            message = f"**{ctx.author.display_name}** {action}s!"

        embed = discord.Embed(
            description=message,
            color=0x000000
        )
        
        if gif_url:
            embed.set_image(url=gif_url)
        
        embed.set_author(
            name=f"{ctx.author.display_name}'s {action.title()}",
            icon_url=ctx.author.display_avatar.url
        )
        
        await ctx.send(embed=embed)

    

    def get_random_animal(self, luck_bonus=0):
        """Get a random animal based on rarity rates + luck"""
        total_rate = sum(HUNT_RATES.values()) + luck_bonus
        rand = random.randint(1, total_rate)
        
        cumulative = 0
        for rarity, rate in HUNT_RATES.items():
            cumulative += rate
            if rand <= cumulative:
                animals = list(ZOO_ANIMALS[rarity].keys())
                return random.choice(animals), rarity
        
        # Fallback to common
        animals = list(ZOO_ANIMALS['common'].keys())
        return random.choice(animals), 'common'

    def calculate_zoo_points(self, zoo_data):
        """Calculate total zoo points from animals"""
        points = 0
        rarity_counts = {'mythic': 0, 'epic': 0, 'rare': 0, 'uncommon': 0, 'common': 0}
        
        for rarity, animals in zoo_data.items():
            if rarity not in ['common', 'uncommon', 'rare', 'epic', 'mythic']:
                continue
            multiplier = {'common': 1, 'uncommon': 2, 'rare': 5, 'epic': 15, 'mythic': 50}[rarity]
            
            if isinstance(animals, dict):
                for emoji, count in animals.items():
                    if count > 0:
                        points += count * multiplier
                        rarity_counts[rarity] += count
        
        return points, rarity_counts

    async def generate_stock_graph(self, symbol):
        """Generate an enhanced stock price graph using Pillow"""
        try:
            # Get historical data (last 30 days)
            price_history = await self.db.get_stock_price_history(symbol, 30)
            current_price = await self.db.get_stock_price(symbol)
            
            if not price_history or len(price_history) < 2:
                # Generate realistic sample data if no history exists
                price_history = []
                company = STOCK_COMPANIES[symbol]
                base_price = company['base_price']
                
                for i in range(30):
                    # More realistic price movement simulation
                    if i == 0:
                        price = base_price
                    else:
                        # Add market trend and random walk
                        trend = random.uniform(-0.002, 0.003)  # Slight upward bias
                        volatility_factor = company['volatility']
                        random_change = random.uniform(-volatility_factor, volatility_factor) * 0.1
                        
                        price = price_history[i-1] * (1 + trend + random_change)
                        # Keep price within reasonable bounds
                        price = max(price, base_price * 0.7)
                        price = min(price, base_price * 1.5)
                    
                    price_history.append(price)
                
                # Update current price to last in history
                await self.db.set_stock_price(symbol, price_history[-1])
                current_price = price_history[-1]
            
            # Create larger, higher quality image
            width, height = 1000, 500
            img = Image.new('RGB', (width, height), color='#1a1a1a')
            draw = ImageDraw.Draw(img)
            
            # Try to load better fonts
            try:
                font = ImageFont.truetype("utils/arial.ttf", 14)
                title_font = ImageFont.truetype("utils/arial.ttf", 28)
                label_font = ImageFont.truetype("utils/arial.ttf", 12)
            except:
                font = ImageFont.load_default()
                title_font = ImageFont.load_default()
                label_font = ImageFont.load_default()
            
            # Enhanced margins and layout
            margin_left = 100
            margin_right = 80
            margin_top = 80
            margin_bottom = 100
            
            graph_width = width - margin_left - margin_right
            graph_height = height - margin_top - margin_bottom
            
            # Calculate price range with padding
            min_price = min(price_history)
            max_price = max(price_history)
            price_range = max_price - min_price
            
            if price_range == 0:
                price_range = max_price * 0.1  # 10% range if flat
            
            # Add 5% padding to top and bottom
            padding = price_range * 0.05
            min_price -= padding
            max_price += padding
            price_range = max_price - min_price
            
            # Draw enhanced title with company info
            company = STOCK_COMPANIES[symbol]
            title = f"{company['emoji']} {symbol} - {company['name']}"
            title_bbox = draw.textbbox((0, 0), title, font=title_font)
            title_width = title_bbox[2] - title_bbox[0]
            draw.text(((width - title_width) // 2, 25), title, fill='#ffffff', font=title_font)
            
            # Draw sector and current price info
            sector_text = f"Sector: {company['sector']} | Current: {current_price:,.2f} <:cowoncy:1385212758919745608>"
            sector_bbox = draw.textbbox((0, 0), sector_text, font=font)
            sector_width = sector_bbox[2] - sector_bbox[0]
            draw.text(((width - sector_width) // 2, 55), sector_text, fill='#cccccc', font=font)
            
            # Draw graph background with gradient effect
            graph_x = margin_left
            graph_y = margin_top
            
            # Create gradient background
            for i in range(graph_height):
                alpha = int(20 + (i / graph_height) * 15)
                color = f"#{alpha:02x}{alpha:02x}{alpha+5:02x}"
                draw.line([(graph_x, graph_y + i), (graph_x + graph_width, graph_y + i)], 
                         fill=color, width=1)
            
            # Draw border
            draw.rectangle([graph_x, graph_y, graph_x + graph_width, graph_y + graph_height], 
                          outline='#444444', width=2)
            
            # Draw enhanced grid lines
            grid_lines = 8
            for i in range(grid_lines + 1):
                y = graph_y + (i * graph_height // grid_lines)
                # Alternate grid line styles
                if i % 2 == 0:
                    draw.line([graph_x, y, graph_x + graph_width, y], fill='#333333', width=1)
                else:
                    # Dashed line effect
                    for x in range(graph_x, graph_x + graph_width, 10):
                        draw.line([x, y, min(x + 5, graph_x + graph_width), y], fill='#2a2a2a', width=1)
                
                # Enhanced price labels
                if i <= grid_lines:
                    price_value = max_price - (i * price_range / grid_lines)
                    price_text = f"{price_value:,.0f}"
                    text_bbox = draw.textbbox((0, 0), price_text, font=label_font)
                    text_width = text_bbox[2] - text_bbox[0]
                    draw.text((graph_x - text_width - 10, y - 8), price_text, fill='#cccccc', font=label_font)
            
            # Draw vertical grid lines
            v_grid_lines = 6
            for i in range(v_grid_lines + 1):
                x = graph_x + (i * graph_width // v_grid_lines)
                if i % 2 == 0:
                    draw.line([x, graph_y, x, graph_y + graph_height], fill='#333333', width=1)
                else:
                    # Dashed vertical lines
                    for y in range(graph_y, graph_y + graph_height, 10):
                        draw.line([x, y, x, min(y + 5, graph_y + graph_height)], fill='#2a2a2a', width=1)
            
            # Calculate points for the price line
            points = []
            for i, price in enumerate(price_history):
                x = graph_x + (i * graph_width // (len(price_history) - 1))
                y = graph_y + graph_height - ((price - min_price) / price_range * graph_height)
                points.append((x, y))
            
            # Draw area fill under the line
            if len(points) > 1:
                # Create polygon for fill area
                fill_points = points + [(points[-1][0], graph_y + graph_height), 
                                       (points[0][0], graph_y + graph_height)]
                
                # Determine line color based on trend
                trend_color = '#00ff88' if price_history[-1] >= price_history[0] else '#ff4444'
                fill_color = trend_color + '20'  # Add transparency
                
                # Draw filled area (simulate transparency with darker version)
                fill_points_int = [(int(x), int(y)) for x, y in fill_points]
                try:
                    # Create a separate image for transparency effect
                    overlay = Image.new('RGBA', (width, height), (0, 0, 0, 0))
                    overlay_draw = ImageDraw.Draw(overlay)
                    
                    if trend_color == '#00ff88':
                        overlay_draw.polygon(fill_points_int, fill=(0, 255, 136, 50))
                    else:
                        overlay_draw.polygon(fill_points_int, fill=(255, 68, 68, 50))
                    
                    # Composite with main image
                    img = Image.alpha_composite(img.convert('RGBA'), overlay).convert('RGB')
                    draw = ImageDraw.Draw(img)
                except:
                    # Fallback if transparency doesn't work
                    pass
                
                # Draw main price line with varying thickness
                for i in range(len(points) - 1):
                    # Make line thicker in recent days
                    thickness = 2 + int((i / len(points)) * 2)
                    draw.line([points[i], points[i + 1]], fill=trend_color, width=thickness)
                
                # Draw enhanced data points
                for i, point in enumerate(points):
                    # Larger points for recent data
                    if i >= len(points) - 7:  # Last week
                        radius = 4
                        draw.ellipse([point[0] - radius, point[1] - radius, 
                                    point[0] + radius, point[1] + radius], 
                                   fill=trend_color, outline='#ffffff', width=1)
                    elif i % 3 == 0:  # Every third point for older data
                        radius = 2
                        draw.ellipse([point[0] - radius, point[1] - radius, 
                                    point[0] + radius, point[1] + radius], 
                                   fill=trend_color)
            
            # Draw current price indicator line
            if current_price >= min_price and current_price <= max_price:
                current_y = graph_y + graph_height - ((current_price - min_price) / price_range * graph_height)
                
                # Animated-style current price line
                dash_length = 8
                for x in range(graph_x, graph_x + graph_width, dash_length * 2):
                    draw.line([x, current_y, min(x + dash_length, graph_x + graph_width), current_y], 
                             fill='#ffff00', width=2)
                
                # Current price label with background
                price_text = f"Current: {current_price:,.0f}"
                text_bbox = draw.textbbox((0, 0), price_text, font=font)
                text_width = text_bbox[2] - text_bbox[0]
                text_height = text_bbox[3] - text_bbox[1]
                
                label_x = graph_x + graph_width - text_width - 10
                label_y = current_y - text_height // 2
                
                # Background for label
                draw.rectangle([label_x - 5, label_y - 2, label_x + text_width + 5, label_y + text_height + 2], 
                              fill='#000000', outline='#ffff00', width=1)
                draw.text((label_x, label_y), price_text, fill='#ffff00', font=font)
            
            # Enhanced x-axis labels (time periods)
            time_labels = ['1M ago', '3W ago', '2W ago', '1W ago', 'Yesterday', 'Today']
            for i, label in enumerate(time_labels):
                if i < len(time_labels):
                    x_pos = graph_x + (i * graph_width // (len(time_labels) - 1))
                    text_bbox = draw.textbbox((0, 0), label, font=label_font)
                    text_width = text_bbox[2] - text_bbox[0]
                    draw.text((x_pos - text_width // 2, graph_y + graph_height + 15), 
                             label, fill='#cccccc', font=label_font)
            
            # Add comprehensive statistics panel
            if len(price_history) > 1:
                stats_y = graph_y + graph_height + 45
                
                # Calculate statistics
                price_change = current_price - price_history[0]
                change_percent = (price_change / price_history[0]) * 100
                volatility_index = (max(price_history) - min(price_history)) / min(price_history) * 100
                
                # Recent trend (last 7 days)
                recent_trend = "Bullish 📈" if price_history[-1] > price_history[-7] else "Bearish 📉"
                
                stats_text = [
                    f"30D Change: {price_change:+,.0f} ({change_percent:+.1f}%)",
                    f"High: {max(price_history):,.0f} | Low: {min(price_history):,.0f}",
                    f"Volatility: {volatility_index:.1f}% | Trend: {recent_trend}",
                    f"Volume: {random.randint(10000, 100000):,} | Market Cap: {current_price * random.randint(1000, 10000):,.0f}"
                ]
                
                for i, text in enumerate(stats_text):
                    color = '#00ff88' if change_percent >= 0 else '#ff4444'
                    if i > 0:
                        color = '#cccccc'
                    
                    draw.text((margin_left + (i % 2) * 400, stats_y + (i // 2) * 20), 
                             text, fill=color, font=label_font)
            
            # Add watermark
            watermark = "Strelizia Stock Exchange"
            watermark_bbox = draw.textbbox((0, 0), watermark, font=label_font)
            watermark_width = watermark_bbox[2] - watermark_bbox[0]
            draw.text((width - watermark_width - 10, height - 20), watermark, 
                     fill='#666666', font=label_font)
            
            # Save to bytes
            img_bytes = io.BytesIO()
            img.save(img_bytes, format='PNG', quality=95, optimize=True)
            img_bytes.seek(0)
            
            return img_bytes
            
        except Exception as e:
            print(f"Enhanced stock graph generation error: {e}")
            import traceback
            traceback.print_exc()
            return None

    async def update_stock_prices(self):
        """Update all stock prices (call this periodically)"""
        try:
            for symbol, company in STOCK_COMPANIES.items():
                current_price = await self.db.get_stock_price(symbol)
                if current_price is None:
                    current_price = company['base_price']
                
                # Generate price movement
                volatility = company['volatility']
                change_percent = random.uniform(-volatility, volatility)
                new_price = current_price * (1 + change_percent)
                
                # Don't let price go too low
                min_price = company['base_price'] * 0.3
                new_price = max(new_price, min_price)
                
                await self.db.set_stock_price(symbol, new_price)
                await self.db.add_stock_price_history(symbol, new_price)
        except Exception as e:
            print(f"Stock price update error: {e}")

    async def get_all_traders(self):
        """Get all users who have invested in stocks"""
        try:
            cursor = await self.db.db.execute('SELECT user_id FROM users WHERE portfolio IS NOT NULL AND portfolio != "{}"')
            rows = await cursor.fetchall()
            return [row[0] for row in rows]
        except Exception as e:
            print(f"Error getting all traders: {e}")
            return []

    async def stock_price_updater(self):
        """Background task to update stock and crypto prices every hour"""
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            try:
                await asyncio.sleep(1800)  # Wait 30 minutes for crypto (more volatile)
                await self.update_stock_prices()
                await self.update_crypto_prices()
                print("Stock and crypto prices updated")
            except Exception as e:
                print(f"Price updater error: {e}")
                await asyncio.sleep(300)  # Wait 5 minutes on error

    async def update_crypto_prices(self):
        """Update all cryptocurrency prices"""
        try:
            for symbol, crypto in CRYPTO_CURRENCIES.items():
                current_price = await self.db.get_crypto_price(symbol)
                if current_price is None:
                    current_price = crypto['base_price']
                
                # Generate more volatile price movement for crypto
                volatility = crypto['volatility']
                change_percent = random.uniform(-volatility, volatility) * 0.5
                new_price = current_price * (1 + change_percent)
                
                # Keep within reasonable bounds
                min_price = crypto['base_price'] * 0.2
                max_price = crypto['base_price'] * 3.0
                new_price = max(min_price, min(new_price, max_price))
                
                await self.db.set_crypto_price(symbol, new_price)
        except Exception as e:
            print(f"Crypto price update error: {e}")

    async def generate_battle_image(self, user1, user2, avatar1_url, avatar2_url, result_data):
        """Generate an epic battle image"""
        try:
            width, height = 900, 400
            
            # Create gradient background
            canvas = Image.new('RGB', (width, height), (20, 20, 30))
            draw = ImageDraw.Draw(canvas)
            
            # Create battle arena gradient
            for y in range(height):
                r = int(20 + (y / height) * 40)
                g = int(20 + (y / height) * 30) 
                b = int(30 + (y / height) * 50)
                draw.line([(0, y), (width, y)], fill=(r, g, b))
            
            # Load font
            try:
                title_font = ImageFont.truetype("utils/arial.ttf", 36)
                name_font = ImageFont.truetype("utils/arial.ttf", 28)
                stat_font = ImageFont.truetype("utils/arial.ttf", 20)
            except:
                title_font = ImageFont.load_default()
                name_font = ImageFont.load_default()
                stat_font = ImageFont.load_default()
            
            # Download and process avatars
            async with aiohttp.ClientSession() as session:
                async with session.get(avatar1_url) as resp:
                    avatar1_data = await resp.read()
                async with session.get(avatar2_url) as resp:
                    avatar2_data = await resp.read()
            
            avatar1 = Image.open(io.BytesIO(avatar1_data)).resize((120, 120)).convert("RGBA")
            avatar2 = Image.open(io.BytesIO(avatar2_data)).resize((120, 120)).convert("RGBA")
            
            # Create circular masks for avatars
            mask = Image.new('L', (120, 120), 0)
            mask_draw = ImageDraw.Draw(mask)
            mask_draw.ellipse((0, 0, 120, 120), fill=255)
            
            # Apply masks
            avatar1.putalpha(mask)
            avatar2.putalpha(mask)
            
            # Add glowing border to avatars
            for i in range(5):
                glow_size = 120 + i * 4
                glow_pos1 = (80 - i * 2, 50 - i * 2)
                glow_pos2 = (width - 200 - i * 2, 50 - i * 2)
                
                draw.ellipse((glow_pos1[0], glow_pos1[1], glow_pos1[0] + glow_size, glow_pos1[1] + glow_size), 
                           outline=(255, 215, 0, 100 - i * 20), width=2)
                draw.ellipse((glow_pos2[0], glow_pos2[1], glow_pos2[0] + glow_size, glow_pos2[1] + glow_size), 
                           outline=(255, 215, 0, 100 - i * 20), width=2)
            
            # Paste avatars
            canvas.paste(avatar1, (80, 50), avatar1)
            canvas.paste(avatar2, (width - 200, 50), avatar2)
            
            # Battle title
            title_text = "⚔️ EPIC ZOO BATTLE ⚔️"
            title_bbox = draw.textbbox((0, 0), title_text, font=title_font)
            title_width = title_bbox[2] - title_bbox[0]
            draw.text(((width - title_width) // 2, 10), title_text, font=title_font, fill=(255, 215, 0))
            
            # Player names
            draw.text((90, 180), user1.display_name[:15], font=name_font, fill=(255, 255, 255))
            draw.text((width - 190, 180), user2.display_name[:15], font=name_font, fill=(255, 255, 255))
            
            # HP bars
            hp1_percent = result_data.get('hp1_percent', 100)
            hp2_percent = result_data.get('hp2_percent', 100)
            
            # HP bar backgrounds
            draw.rectangle((80, 210, 280, 235), fill=(100, 0, 0))
            draw.rectangle((width - 280, 210, width - 80, 235), fill=(100, 0, 0))
            
            # HP bar fills
            hp1_width = int(200 * hp1_percent / 100)
            hp2_width = int(200 * hp2_percent / 100)
            
            hp1_color = (0, 255, 0) if hp1_percent > 50 else (255, 255, 0) if hp1_percent > 25 else (255, 0, 0)
            hp2_color = (0, 255, 0) if hp2_percent > 50 else (255, 255, 0) if hp2_percent > 25 else (255, 0, 0)
            
            draw.rectangle((80, 210, 80 + hp1_width, 235), fill=hp1_color)
            draw.rectangle((width - 280, 210, width - 280 + hp2_width, 235), fill=hp2_color)
            
            # HP text
            draw.text((85, 213), f"HP: {hp1_percent}%", font=stat_font, fill=(255, 255, 255))
            draw.text((width - 275, 213), f"HP: {hp2_percent}%", font=stat_font, fill=(255, 255, 255))
            
            # Battle actions
            action_y = 250
            if 'actions' in result_data:
                for i, action in enumerate(result_data['actions'][:3]):
                    draw.text((width // 2 - 200, action_y + i * 25), action, font=stat_font, fill=(255, 255, 0))
            
            # Winner declaration
            winner_text = f"🏆 WINNER: {result_data.get('winner', 'Draw')} 🏆"
            winner_bbox = draw.textbbox((0, 0), winner_text, font=name_font)
            winner_width = winner_bbox[2] - winner_bbox[0]
            draw.text(((width - winner_width) // 2, height - 50), winner_text, font=name_font, fill=(255, 215, 0))
            
            # Lightning effects
            for _ in range(10):
                x = random.randint(0, width)
                y = random.randint(0, height)
                draw.line([(x, y), (x + random.randint(-20, 20), y + random.randint(-20, 20))], 
                         fill=(255, 255, 255, 150), width=2)
            
            # Save to bytes
            img_bytes = io.BytesIO()
            canvas.save(img_bytes, format='PNG')
            img_bytes.seek(0)
            
            return img_bytes
            
        except Exception as e:
            print(f"Battle image generation error: {e}")
            return None

    async def get_tenor_gif(self, action):
        """Fetch the best animated GIF from Tenor API"""
        try:
            async with aiohttp.ClientSession() as session:
                url = f"https://tenor.googleapis.com/v2/search"
                params = {
                    "q": f"anime {action}",
                    "key": "AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ",
                    "limit": 25,
                    "contentfilter": "medium",
                    "media_filter": "gif"
                }

                async with session.get(url, params=params) as response:
                    if response.status == 200:
                        data = await response.json()
                        if data.get("results"):
                            # Get any available GIF
                            all_gifs = [result.get("media_formats", {}).get("gif", {}).get("url") 
                                      for result in data["results"] 
                                      if result.get("media_formats", {}).get("gif", {}).get("url")]

                            if all_gifs:
                                return random.choice(all_gifs)

        except Exception as e:
            print(f"Tenor API error: {e}")

        # Enhanced fallback GIFs with multiple options per action
        action_fallbacks = {
            "hug": [
                "https://media.tenor.com/VBXfHaXXK8UAAAAC/anime-hug.gif",
                "https://media.tenor.com/KAplWFVgZcMAAAAC/anime-hug-cute.gif",
                "https://media.tenor.com/x6xj9CyH_TYAAAAC/wholesome-hug.gif"
            ],
            "kiss": [
                "https://media.tenor.com/X2n2sz4wNYMAAAAC/anime-kiss.gif",
                "https://media.tenor.com/pK3lBkhH4EIAAAAC/anime-kiss-cute.gif"
            ],
            "cuddle": [
                "https://media.tenor.com/7vy_3CQrN8IAAAAC/anime-cuddle.gif",
                "https://media.tenor.com/YCEuJQT6_qsAAAAC/cuddle-anime.gif"
            ],
            "pat": [
                "https://media.tenor.com/efzrKPH-xeYAAAAC/anime-pat.gif",
                "https://media.tenor.com/d2bhHySVT9QAAAAC/anime-pat-head.gif"
            ],
            "slap": [
                "https://media.tenor.com/R_rjwlEH7zMAAAAC/anime-slap.gif",
                "https://media.tenor.com/HJZp5MrYHmMAAAAC/anime-slap-funny.gif"
            ],
            "tickle": [
                "https://media.tenor.com/rggT2ROoFpYAAAAC/anime-tickle.gif"
            ],
            "poke": [
                "https://media.tenor.com/1MoLS3INZuEAAAAC/anime-poke.gif"
            ],
            "wave": [
                "https://media.tenor.com/E3b2EAFV_pIAAAAC/anime-wave.gif"
            ],
            "dance": [
                "https://media.tenor.com/EAK-sPw8aRMAAAAC/anime-dance.gif"
            ],
            "cry": [
                "https://media.tenor.com/WZ8P6_LQQ2AAAAAC/anime-cry.gif"
            ],
            "laugh": [
                "https://media.tenor.com/84fgtyXgqTUAAAAC/anime-laugh.gif"
            ],
            "smile": [
                "https://media.tenor.com/Wn9X2FKr3PEAAAAC/anime-smile.gif"
            ],
            "blush": [
                "https://media.tenor.com/Mc8KFXbSJXUAAAAC/anime-blush.gif"
            ],
            "wink": [
                "https://media.tenor.com/YzWbgGF2sIEAAAAC/anime-wink.gif"
            ],
            "thumbsup": [
                "https://media.tenor.com/7hKJhE2gzGEAAAAC/anime-thumbs-up.gif"
            ],
            "clap": [
                "https://media.tenor.com/cxeBKKIqz8oAAAAC/anime-clap.gif"
            ],
            "bow": [
                "https://media.tenor.com/8KYAj3b2JO4AAAAC/anime-bow.gif"
            ],
            "salute": [
                "https://media.tenor.com/7w8WaOVY5T8AAAAC/anime-salute.gif"
            ],
            "facepalm": [
                "https://media.tenor.com/wQ0jLkfWgDYAAAAC/anime-facepalm.gif"
            ],
            "shrug": [
                "https://media.tenor.com/QIFq7g4r79EAAAAC/anime-shrug.gif"
            ],
            "sleep": [
                "https://media.tenor.com/W45_Xl9-enoAAAAC/anime-sleep.gif"
            ],
            "eat": [
                "https://media.tenor.com/qA7wC6Z3oAQAAAAC/anime-eating.gif"
            ],
            "drink": [
                "https://media.tenor.com/BHJqPnXiZdEAAAAC/anime-drink.gif"
            ],
            "run": [
                "https://media.tenor.com/Vq8MbpQlhWEAAAAC/anime-running.gif"
            ]
        }

        fallback_gifs = action_fallbacks.get(action, action_fallbacks["hug"])
        return random.choice(fallback_gifs)

    async def create_action_embed(self, ctx, action, target=None):
        if target and target.id == ctx.author.id:
            embed = discord.Embed(
                description="You can't perform this action on yourself! Try targeting someone else.",
                color=0x000000
            )
            embed.set_footer(text="Choose a different target")
            return await ctx.send(embed=embed)

        # Get the best GIF for this action
        gif_url = await self.get_tenor_gif(action)

        # Different message variations for each action
        action_messages = {
            "hug": {
                "with_target": [
                    "{author} hugs {target} tightly! 🤗",
                    "{author} gives {target} a warm hug~",
                    "{author} embraces {target} sweetly!",
                    "{author} wraps {target} in a cozy hug!",
                    "{author} hugs {target}! So wholesome!"
                ],
                "without_target": [
                    "{author} needs a hug! Someone hug them!",
                    "{author} is looking for hugs~",
                    "{author} wants to spread hugs around!"
                ]
            },
            "kiss": {
                "with_target": [
                    "{author} kisses {target}'s lips~",
                    "{author} kissed {target}! Cute!",
                    "{author} gives {target} a sweet kiss 💋",
                    "{author} pecks {target} on the cheek~",
                    "{author} kisses {target} lovingly!"
                ],
                "without_target": [
                    "{author} blows kisses to everyone!",
                    "{author} is feeling romantic~",
                    "{author} sends virtual kisses!"
                ]
            },
            "cuddle": {
                "with_target": [
                    "{author} cuddles with {target} warmly~",
                    "{author} snuggles up to {target}!",
                    "{author} cuddles {target} softly 🫂",
                    "{author} wraps {target} in a cozy cuddle!",
                    "{author} and {target} are cuddling!"
                ],
                "without_target": [
                    "{author} wants cuddles!",
                    "{author} is in cuddle mode~",
                    "{author} needs someone to cuddle with!"
                ]
            },
            "pat": {
                "with_target": [
                    "{author} pats {target}'s head gently~",
                    "{author} gives {target} comforting pats!",
                    "{author} pats {target} softly 👋",
                    "{author} pat pat pats {target}!",
                    "{author} gently pats {target}!"
                ],
                "without_target": [
                    "{author} is patting the air!",
                    "{author} wants to pat someone~",
                    "{author} gives themselves a pat!"
                ]
            },
            "slap": {
                "with_target": [
                    "{author} playfully slaps {target}!",
                    "{author} gives {target} a gentle slap~",
                    "{author} *slap* {target}! That's what you get!",
                    "{author} boops {target} with a slap!",
                    "{author} slaps {target} teasingly!"
                ],
                "without_target": [
                    "{author} slaps the air dramatically!",
                    "{author} is ready to slap someone!",
                    "{author} practices their slapping technique!"
                ]
            },
            "tickle": {
                "with_target": [
                    "{author} tickles {target} playfully!",
                    "{author} starts a tickle fight with {target}!",
                    "{author} tickles {target}! Hehe~",
                    "{author} pokes and tickles {target}!",
                    "{author} tickles {target} until they laugh!"
                ],
                "without_target": [
                    "{author} tickles themselves!",
                    "{author} is feeling ticklish~",
                    "{author} wants to tickle someone!"
                ]
            },
            "poke": {
                "with_target": [
                    "{author} pokes {target} gently~",
                    "{author} *poke poke* {target}!",
                    "{author} gives {target} a little poke!",
                    "{author} pokes {target} to get attention!",
                    "{author} boops {target} with a poke!"
                ],
                "without_target": [
                    "{author} pokes the air!",
                    "{author} is poking around~",
                    "{author} wants to poke someone!"
                ]
            },
            "wave": {
                "with_target": [
                    "{author} waves at {target} happily!",
                    "{author} gives {target} a friendly wave~",
                    "{author} *waves* Hello {target}!",
                    "{author} waves enthusiastically at {target}!",
                    "{author} greets {target} with a wave!"
                ],
                "without_target": [
                    "{author} waves to everyone!",
                    "{author} is waving around~",
                    "{author} gives a big wave!"
                ]
            },
            "dance": {
                "without_target": [
                    "{author} dances with pure joy!",
                    "{author} is dancing like nobody's watching!",
                    "{author} breaks into dance moves!",
                    "{author} dances happily~",
                    "{author} shows off their dance moves!"
                ]
            },
            "cry": {
                "without_target": [
                    "{author} is crying... someone comfort them!",
                    "{author} sheds tears sadly~",
                    "{author} cries softly...",
                    "{author} is having an emotional moment!",
                    "{author} needs tissues and hugs!"
                ]
            },
            "laugh": {
                "without_target": [
                    "{author} laughs heartily!",
                    "{author} is laughing so hard!",
                    "{author} bursts into laughter~",
                    "{author} can't stop laughing!",
                    "{author} laughs joyfully!"
                ]
            },
            "smile": {
                "without_target": [
                    "{author} smiles brightly!",
                    "{author} has the cutest smile~",
                    "{author} beams with happiness!",
                    "{author} flashes a warm smile!",
                    "{author} smiles radiantly!"
                ]
            },
            "blush": {
                "without_target": [
                    "{author} blushes adorably~",
                    "{author} is blushing so cutely!",
                    "{author} turns red with embarrassment!",
                    "{author} blushes shyly...",
                    "{author} has rosy cheeks!"
                ]
            },
            "wink": {
                "with_target": [
                    "{author} winks at {target} playfully~",
                    "{author} gives {target} a cheeky wink!",
                    "{author} *wink wink* {target}!",
                    "{author} winks flirtatiously at {target}!",
                    "{author} sends {target} a sly wink!"
                ],
                "without_target": [
                    "{author} winks at everyone!",
                    "{author} is feeling flirty~",
                    "{author} gives a charming wink!"
                ]
            },
            "thumbsup": {
                "without_target": [
                    "{author} gives a thumbs up!",
                    "{author} approves with a thumbs up!",
                    "{author} shows their approval!",
                    "{author} *thumbs up* Good job!",
                    "{author} is feeling positive!"
                ]
            },
            "clap": {
                "without_target": [
                    "{author} claps enthusiastically!",
                    "{author} gives a round of applause!",
                    "{author} claps their hands together!",
                    "{author} applauds loudly!",
                    "{author} is clapping with joy!"
                ]
            },
            "bow": {
                "with_target": [
                    "{author} bows respectfully to {target}!",
                    "{author} gives {target} a formal bow~",
                    "{author} bows gracefully before {target}!",
                    "{author} shows respect with a bow to {target}!",
                    "{author} bows politely to {target}!"
                ],
                "without_target": [
                    "{author} takes a bow!",
                    "{author} bows gracefully~",
                    "{author} gives a respectful bow!"
                ]
            },
            "salute": {
                "with_target": [
                    "{author} salutes {target} formally!",
                    "{author} gives {target} a military salute!",
                    "{author} salutes {target} with respect!",
                    "{author} *salutes* {target}!",
                    "{author} shows military respect to {target}!"
                ],
                "without_target": [
                    "{author} gives a formal salute!",
                    "{author} salutes with honor!",
                    "{author} stands at attention and salutes!"
                ]
            },
            "facepalm": {
                "without_target": [
                    "{author} facepalms in frustration!",
                    "{author} *facepalm* Oh no...",
                    "{author} covers their face with their palm!",
                    "{author} is having a facepalm moment!",
                    "{author} can't believe what just happened!"
                ]
            },
            "shrug": {
                "without_target": [
                    "{author} shrugs casually~",
                    "{author} *shrug* I don't know!",
                    "{author} gives a nonchalant shrug!",
                    "{author} shrugs their shoulders!",
                    "{author} doesn't know what to say!"
                ]
            },
            "sleep": {
                "without_target": [
                    "{author} is sleeping peacefully~",
                    "{author} takes a nap! Zzz...",
                    "{author} is dreaming sweetly!",
                    "{author} sleeps like a baby!",
                    "{author} is snoozing away!"
                ]
            },
            "eat": {
                "without_target": [
                    "{author} is enjoying a delicious meal!",
                    "{author} *nom nom nom*",
                    "{author} eats something tasty~",
                    "{author} is having a feast!",
                    "{author} satisfies their hunger!"
                ]
            },
            "drink": {
                "without_target": [
                    "{author} drinks something refreshing!",
                    "{author} quenches their thirst~",
                    "{author} sips their favorite drink!",
                    "{author} enjoys a cool beverage!",
                    "{author} takes a refreshing drink!"
                ]
            },
            "run": {
                "without_target": [
                    "{author} runs as fast as they can!",
                    "{author} is sprinting away!",
                    "{author} runs with determination!",
                    "{author} dashes off quickly!",
                    "{author} is running like the wind!"
                ]
            },
            "lewd": {
                "with_target": [
                    "{author} acts lewd towards {target}~",
                    "{author} gives {target} a lewd look!",
                    "{author} is being lewd with {target}~",
                    "{author} whispers something lewd to {target}!",
                    "{author} makes {target} blush with lewd actions!"
                ],
                "without_target": [
                    "{author} is being lewd~",
                    "{author} has lewd thoughts!",
                    "{author} acts lewdly!"
                ]
            },
            "pout": {
                "without_target": [
                    "{author} pouts cutely!",
                    "{author} is pouting adorably~",
                    "{author} makes a pouty face!",
                    "{author} pouts like a child!",
                    "{author} sulks with a pout!"
                ]
            },
            "sleepy": {
                "without_target": [
                    "{author} is feeling sleepy... *yawn*",
                    "{author} rubs their sleepy eyes~",
                    "{author} looks drowsy!",
                    "{author} is getting sleepy!",
                    "{author} yawns adorably!"
                ]
            },
            "smug": {
                "without_target": [
                    "{author} has a smug expression!",
                    "{author} grins smugly~",
                    "{author} looks very pleased with themselves!",
                    "{author} smirks smugly!",
                    "{author} radiates smugness!"
                ]
            },
            "wag": {
                "without_target": [
                    "{author} wags their tail happily!",
                    "{author}'s tail is wagging excitedly!",
                    "{author} wags like a happy puppy!",
                    "{author} can't stop wagging!",
                    "{author} wags their tail in joy!"
                ]
            },
            "thinking": {
                "without_target": [
                    "{author} is thinking deeply...",
                    "{author} ponders thoughtfully!",
                    "{author} is lost in thought~",
                    "{author} thinks hard about something!",
                    "{author} contemplates life!"
                ]
            },
            "triggered": {
                "without_target": [
                    "{author} is TRIGGERED!",
                    "{author} feels triggered by something!",
                    "{author} is absolutely triggered!",
                    "{author} can't handle this anymore!",
                    "{author} is having a triggered moment!"
                ]
            },
            "teehee": {
                "without_target": [
                    "{author} giggles cutely~ Teehee!",
                    "{author} lets out a cute teehee!",
                    "{author} covers their mouth and giggles!",
                    "{author} teehees adorably!",
                    "{author} can't help but teehee!"
                ]
            },
            "deredere": {
                "without_target": [
                    "{author} is being super lovey-dovey!",
                    "{author} acts all deredere~",
                    "{author} is in full deredere mode!",
                    "{author} sparkles with deredere energy!",
                    "{author} radiates pure deredere vibes!"
                ]
            },
            "thonking": {
                "without_target": [
                    "{author} is thonking really hard...",
                    "{author} puts on their thonking cap!",
                    "{author} enters maximum thonk mode!",
                    "{author} thonks intensely!",
                    "{author} is having big thonks!"
                ]
            },
            "scoff": {
                "without_target": [
                    "{author} scoffs dismissively!",
                    "{author} lets out a disdainful scoff!",
                    "{author} scoffs at the situation!",
                    "{author} can't help but scoff!",
                    "{author} scoffs in disbelief!"
                ]
            },
            "happy": {
                "without_target": [
                    "{author} is radiating happiness!",
                    "{author} feels incredibly happy!",
                    "{author} can't contain their joy!",
                    "{author} is beaming with happiness!",
                    "{author} spreads happy vibes!"
                ]
            },
            "thumbs": {
                "without_target": [
                    "{author} gives two thumbs up!",
                    "{author} shows their approval!",
                    "{author} flashes a thumbs up!",
                    "{author} gives the thumbs up sign!",
                    "{author} approves with thumbs!"
                ]
            },
            "grin": {
                "without_target": [
                    "{author} grins from ear to ear!",
                    "{author} has a big grin on their face!",
                    "{author} grins mischievously!",
                    "{author} can't stop grinning!",
                    "{author} flashes a wide grin!"
                ]
            },
            "lick": {
                "with_target": [
                    "{author} licks {target} playfully!",
                    "{author} gives {target} a cute lick!",
                    "{author} licks {target}'s cheek~",
                    "{author} playfully licks {target}!",
                    "{author} can't resist licking {target}!"
                ],
                "without_target": [
                    "{author} licks the air!",
                    "{author} sticks their tongue out!",
                    "{author} licks their lips!"
                ]
            },
            "nom": {
                "with_target": [
                    "{author} noms on {target} gently!",
                    "{author} gives {target} little noms!",
                    "{author} playfully noms {target}!",
                    "{author} can't resist nomming {target}!",
                    "{author} noms {target}'s hand cutely!"
                ],
                "without_target": [
                    "{author} noms on something tasty!",
                    "{author} noms happily!",
                    "{author} is nomming away!"
                ]
            },
            "stare": {
                "with_target": [
                    "{author} stares intensely at {target}!",
                    "{author} gives {target} a long stare!",
                    "{author} can't stop staring at {target}!",
                    "{author} stares at {target} curiously!",
                    "{author} fixes their gaze on {target}!"
                ],
                "without_target": [
                    "{author} stares into the void!",
                    "{author} has a blank stare!",
                    "{author} stares off into space!"
                ]
            },
            "highfive": {
                "with_target": [
                    "{author} high-fives {target} enthusiastically!",
                    "{author} gives {target} an epic high-five!",
                    "{author} and {target} share a high-five!",
                    "{author} slaps {target}'s hand in a high-five!",
                    "{author} celebrates with {target} with a high-five!"
                ],
                "without_target": [
                    "{author} holds up their hand for a high-five!",
                    "{author} wants a high-five!",
                    "{author} high-fives the air!"
                ]
            },
            "bite": {
                "with_target": [
                    "{author} playfully bites {target}!",
                    "{author} gives {target} a gentle bite!",
                    "{author} nips at {target} cutely!",
                    "{author} bites {target}'s arm playfully!",
                    "{author} can't resist biting {target}!"
                ],
                "without_target": [
                    "{author} bites the air!",
                    "{author} shows their teeth!",
                    "{author} is in a biting mood!"
                ]
            },
            "greet": {
                "with_target": [
                    "{author} greets {target} warmly!",
                    "{author} gives {target} a friendly greeting!",
                    "{author} welcomes {target} with open arms!",
                    "{author} says hello to {target}!",
                    "{author} greets {target} enthusiastically!"
                ],
                "without_target": [
                    "{author} greets everyone!",
                    "{author} gives a friendly greeting!",
                    "{author} says hello to the world!"
                ]
            },
            "punch": {
                "with_target": [
                    "{author} playfully punches {target}!",
                    "{author} gives {target} a light punch!",
                    "{author} punches {target} on the shoulder!",
                    "{author} delivers a friendly punch to {target}!",
                    "{author} can't help but punch {target} playfully!"
                ],
                "without_target": [
                    "{author} punches the air!",
                    "{author} throws a punch at nothing!",
                    "{author} practices their punching!"
                ]
            },
            "handholding": {
                "with_target": [
                    "{author} holds {target}'s hand sweetly!",
                    "{author} intertwines fingers with {target}!",
                    "{author} and {target} hold hands lovingly!",
                    "{author} grasps {target}'s hand gently!",
                    "{author} never wants to let go of {target}'s hand!"
                ],
                "without_target": [
                    "{author} holds their own hands!",
                    "{author} wishes for someone to hold hands with!",
                    "{author} extends their hand for holding!"
                ]
            },
            "kill": {
                "with_target": [
                    "{author} playfully 'kills' {target}!",
                    "{author} dramatically defeats {target}!",
                    "{author} gives {target} the final blow!",
                    "{author} ends {target} with style!",
                    "{author} finishes {target} off dramatically!"
                ],
                "without_target": [
                    "{author} kills dramatically!",
                    "{author} strikes a killing pose!",
                    "{author} goes on a killing spree!"
                ]
            },
            "hold": {
                "with_target": [
                    "{author} holds {target} closely!",
                    "{author} embraces {target} tightly!",
                    "{author} wraps their arms around {target}!",
                    "{author} holds {target} protectively!",
                    "{author} never wants to let {target} go!"
                ],
                "without_target": [
                    "{author} holds themselves!",
                    "{author} wants someone to hold!",
                    "{author} extends their arms for holding!"
                ]
            },
            "pats": {
                "with_target": [
                    "{author} gives {target} gentle pats!",
                    "{author} pats {target} lovingly!",
                    "{author} showers {target} with pats!",
                    "{author} can't stop patting {target}!",
                    "{author} gives {target} the best pats!"
                ],
                "without_target": [
                    "{author} pats the air!",
                    "{author} wants to give pats!",
                    "{author} practices their patting technique!"
                ]
            },
            "boop": {
                "with_target": [
                    "{author} boops {target}'s nose!",
                    "{author} gives {target} a cute boop!",
                    "{author} can't resist booping {target}!",
                    "{author} playfully boops {target}!",
                    "{author} delivers the perfect boop to {target}!"
                ],
                "without_target": [
                    "{author} boops the air!",
                    "{author} wants to boop someone!",
                    "{author} practices their booping!"
                ]
            },
            "snuggle": {
                "with_target": [
                    "{author} snuggles with {target} warmly!",
                    "{author} pulls {target} into a snuggle!",
                    "{author} and {target} snuggle together!",
                    "{author} snuggles up to {target} cozily!",
                    "{author} wraps {target} in a warm snuggle!"
                ],
                "without_target": [
                    "{author} snuggles with a pillow!",
                    "{author} wants snuggles!",
                    "{author} snuggles alone!"
                ]
            },
            "bully": {
                "with_target": [
                    "{author} playfully bullies {target}!",
                    "{author} teases {target} like a bully!",
                    "{author} gives {target} the bully treatment!",
                    "{author} can't help but bully {target}!",
                    "{author} bullies {target} with love!"
                ],
                "without_target": [
                    "{author} acts like a bully!",
                    "{author} is in bullying mode!",
                    "{author} practices their bullying!"
                ]
            }
        }

        # Get random message for the action
        messages = action_messages.get(action, {})
        if target and "with_target" in messages:
            description = random.choice(messages["with_target"]).format(
                author=ctx.author.display_name,
                target=target.display_name
            )
        elif "without_target" in messages:
            description = random.choice(messages["without_target"]).format(
                author=ctx.author.display_name
            )
        else:
            # Fallback
            if target:
                description = f"**{ctx.author.display_name}** {action}s **{target.display_name}**!"
            else:
                description = f"**{ctx.author.display_name}** {action}s!"

        embed = discord.Embed(
            color=0x000000,
            timestamp=discord.utils.utcnow()
        )

        embed.set_image(url=gif_url)
        embed.set_author(
            name=description,
            icon_url=ctx.author.display_avatar.url
        )

        await ctx.send(embed=embed)

    @sys.command(name='hug')
    async def sys_hug(self, ctx, target: discord.Member = None):
        """Hug someone sweetly"""
        await self.create_action_embed(ctx, "hug", target)

    @sys.command(name='kiss')
    async def sys_kiss(self, ctx, target: discord.Member = None):
        """Kiss someone lovingly"""
        await self.create_action_embed(ctx, "kiss", target)

    @sys.command(name='cuddle')
    async def sys_cuddle(self, ctx, target: discord.Member = None):
        """Cuddle someone warmly"""
        await self.create_action_embed(ctx, "cuddle", target)

    @sys.command(name='pat')
    async def sys_pat(self, ctx, target: discord.Member = None):
        """Pat someone gently"""
        await self.create_action_embed(ctx, "pat", target)

    @sys.command(name='slap')
    async def sys_slap(self, ctx, target: discord.Member = None):
        """Slap someone playfully"""
        await self.create_action_embed(ctx, "slap", target)

    @sys.command(name='tickle')
    async def sys_tickle(self, ctx, target: discord.Member = None):
        """Tickle someone playfully"""
        await self.create_action_embed(ctx, "tickle", target)

    @sys.command(name='poke')
    async def sys_poke(self, ctx, target: discord.Member = None):
        """Poke someone gently"""
        await self.create_action_embed(ctx, "poke", target)

    @sys.command(name='wave')
    async def sys_wave(self, ctx, target: discord.Member = None):
        """Wave at someone"""
        await self.create_action_embed(ctx, "wave", target)

    @sys.command(name='dance')
    async def sys_dance(self, ctx):
        """Dance with joy"""
        await self.create_action_embed(ctx, "dance")

    @sys.command(name='cry')
    async def sys_cry(self, ctx):
        """Cry sadly"""
        await self.create_action_embed(ctx, "cry")

    @sys.command(name='laugh')
    async def sys_laugh(self, ctx):
        """Laugh heartily"""
        await self.create_action_embed(ctx, "laugh")

    @sys.command(name='smile')
    async def sys_smile(self, ctx):
        """Smile happily"""
        await self.create_action_embed(ctx, "smile")

    @sys.command(name='blush')
    async def sys_blush(self, ctx):
        """Blush shyly"""
        await self.create_action_embed(ctx, "blush")

    @sys.command(name='wink')
    async def sys_wink(self, ctx, target: discord.Member = None):
        """Wink at someone"""
        await self.create_action_embed(ctx, "wink", target)

    @sys.command(name='thumbsup')
    async def sys_thumbsup(self, ctx):
        """Give thumbs up"""
        await self.create_action_embed(ctx, "thumbsup")

    @sys.command(name='clap')
    async def sys_clap(self, ctx):
        """Clap enthusiastically"""
        await self.create_action_embed(ctx, "clap")

    @sys.command(name='bow')
    async def sys_bow(self, ctx, target: discord.Member = None):
        """Bow respectfully"""
        await self.create_action_embed(ctx, "bow", target)

    @sys.command(name='salute')
    async def sys_salute(self, ctx, target: discord.Member = None):
        """Salute formally"""
        await self.create_action_embed(ctx, "salute", target)

    @sys.command(name='facepalm')
    async def sys_facepalm(self, ctx):
        """Facepalm in frustration"""
        await self.create_action_embed(ctx, "facepalm")

    @sys.command(name='shrug')
    async def sys_shrug(self, ctx):
        """Shrug casually"""
        await self.create_action_embed(ctx, "shrug")

    @sys.command(name='sleep')
    async def sys_sleep(self, ctx):
        """Sleep peacefully"""
        await self.create_action_embed(ctx, "sleep")

    @sys.command(name='eat')
    async def sys_eat(self, ctx):
        """Eat something delicious"""
        await self.create_action_embed(ctx, "eat")

    @sys.command(name='drink')
    async def sys_drink(self, ctx):
        """Drink something refreshing"""
        await self.create_action_embed(ctx, "drink")

    @sys.command(name='run')
    async def sys_run(self, ctx):
        """Run quickly"""
        await self.create_action_embed(ctx, "run")

    @sys.command(name='lewd')
    async def sys_lewd(self, ctx, target: discord.Member = None):
        """Act lewd"""
        await self.create_action_embed(ctx, "lewd", target)

    @sys.command(name='pout')
    async def sys_pout(self, ctx):
        """Pout cutely"""
        await self.create_action_embed(ctx, "pout")

    @sys.command(name='sleepy')
    async def sys_sleepy(self, ctx):
        """Feel sleepy"""
        await self.create_action_embed(ctx, "sleepy")

    @sys.command(name='smug')
    async def sys_smug(self, ctx):
        """Act smug"""
        await self.create_action_embed(ctx, "smug")

    @sys.command(name='wag')
    async def sys_wag(self, ctx):
        """Wag tail happily"""
        await self.create_action_embed(ctx, "wag")

    @sys.command(name='thinking')
    async def sys_thinking(self, ctx):
        """Think deeply"""
        await self.create_action_embed(ctx, "thinking")

    @sys.command(name='triggered')
    async def sys_triggered(self, ctx):
        """Feel triggered"""
        await self.create_action_embed(ctx, "triggered")

    @sys.command(name='teehee')
    async def sys_teehee(self, ctx):
        """Giggle cutely"""
        await self.create_action_embed(ctx, "teehee")

    @sys.command(name='deredere')
    async def sys_deredere(self, ctx):
        """Act deredere"""
        await self.create_action_embed(ctx, "deredere")

    @sys.command(name='thonking')
    async def sys_thonking(self, ctx):
        """Think really hard"""
        await self.create_action_embed(ctx, "thonking")

    @sys.command(name='scoff')
    async def sys_scoff(self, ctx):
        """Scoff dismissively"""
        await self.create_action_embed(ctx, "scoff")

    @sys.command(name='happy')
    async def sys_happy(self, ctx):
        """Feel happy"""
        await self.create_action_embed(ctx, "happy")

    @sys.command(name='thumbs')
    async def sys_thumbs(self, ctx):
        """Give thumbs up"""
        await self.create_action_embed(ctx, "thumbs")

    @sys.command(name='grin')
    async def sys_grin(self, ctx):
        """Grin widely"""
        await self.create_action_embed(ctx, "grin")

    @sys.command(name='lick')
    async def sys_lick(self, ctx, target: discord.Member = None):
        """Lick someone"""
        await self.create_action_embed(ctx, "lick", target)

    @sys.command(name='nom')
    async def sys_nom(self, ctx, target: discord.Member = None):
        """Nom on something"""
        await self.create_action_embed(ctx, "nom", target)

    @sys.command(name='stare')
    async def sys_stare(self, ctx, target: discord.Member = None):
        """Stare at someone"""
        await self.create_action_embed(ctx, "stare", target)

    @sys.command(name='highfive')
    async def sys_highfive(self, ctx, target: discord.Member = None):
        """Give a high five"""
        await self.create_action_embed(ctx, "highfive", target)

    @sys.command(name='bite')
    async def sys_bite(self, ctx, target: discord.Member = None):
        """Bite someone playfully"""
        await self.create_action_embed(ctx, "bite", target)

    @sys.command(name='greet')
    async def sys_greet(self, ctx, target: discord.Member = None):
        """Greet someone"""
        await self.create_action_embed(ctx, "greet", target)

    @sys.command(name='punch')
    async def sys_punch(self, ctx, target: discord.Member = None):
        """Punch someone playfully"""
        await self.create_action_embed(ctx, "punch", target)

    @sys.command(name='handholding')
    async def sys_handholding(self, ctx, target: discord.Member = None):
        """Hold hands with someone"""
        await self.create_action_embed(ctx, "handholding", target)

    @sys.command(name='kill')
    async def sys_kill(self, ctx, target: discord.Member = None):
        """Playfully kill someone"""
        await self.create_action_embed(ctx, "kill", target)

    @sys.command(name='hold')
    async def sys_hold(self, ctx, target: discord.Member = None):
        """Hold someone"""
        await self.create_action_embed(ctx, "hold", target)

    @sys.command(name='pats')
    async def sys_pats(self, ctx, target: discord.Member = None):
        """Give gentle pats"""
        await self.create_action_embed(ctx, "pats", target)

    @sys.command(name='boop')
    async def sys_boop(self, ctx, target: discord.Member = None):
        """Boop someone's nose"""
        await self.create_action_embed(ctx, "boop", target)

    @sys.command(name='snuggle')
    async def sys_snuggle(self, ctx, target: discord.Member = None):
        """Snuggle with someone"""
        await self.create_action_embed(ctx, "snuggle", target)

    @sys.command(name='bully')
    async def sys_bully(self, ctx, target: discord.Member = None):
        """Playfully bully someone"""
        await self.create_action_embed(ctx, "bully", target)

    async def cog_unload(self):
        await self.db.close()

    def help_custom(self):
        emoji = '<:cowoncy:1385212758919745608>'
        label = 'Economy'
        description = 'Complete economy system with cowoncy, gambling, zoo, and more!'
        return emoji, label, description

    @sys.command(name='emoji')
    async def sys_emoji(self, ctx, emoji: Union[discord.Emoji, discord.PartialEmoji, str] = None):
        """Display an enlarged emoji with file information"""
        if emoji is None:
            return await ctx.send("**🚫 | Please specify an emoji!**", delete_after=3)

        try:
            if isinstance(emoji, (discord.Emoji, discord.PartialEmoji)):
                # Handle custom emojis
                emoji_url = emoji.url
                emoji_id = emoji.id
                emoji_name = emoji.name
                
                # Get file size by making a HEAD request
                import aiohttp
                file_size = "Unknown"
                try:
                    async with aiohttp.ClientSession() as session:
                        async with session.head(emoji_url) as response:
                            if 'content-length' in response.headers:
                                size_bytes = int(response.headers['content-length'])
                                if size_bytes < 1024:
                                    file_size = f"{size_bytes} bytes"
                                elif size_bytes < 1024 * 1024:
                                    file_size = f"{size_bytes / 1024:.1f} KB"
                                else:
                                    file_size = f"{size_bytes / (1024 * 1024):.1f} MB"
                except:
                    file_size = "Unknown"
                
                embed = discord.Embed(
                    color=0x000000
                )
                embed.add_field(
                    name="**EMOJI**:",
                    value=f"`{emoji_name}` `{emoji_id}`\n**Size:** {file_size}",
                    inline=False
                )
                embed.set_image(url=emoji_url)
                embed.set_author(
                    name=f"{ctx.author.display_name} Enlarged Emoji!",
                    icon_url=ctx.author.display_avatar.url
                )
                
                await ctx.send(embed=embed)
                
            elif isinstance(emoji, str):
                # Handle default Unicode emojis with enlarged display
                # Make the emoji much larger by repeating it and using formatting
                enlarged_emoji = emoji * 5  # Repeat the emoji 5 times for larger appearance
                
                embed = discord.Embed(
                    title=enlarged_emoji,
                    description=f"**Type:** Unicode Emoji\n**Original:** {emoji}",
                    color=0x000000
                )
                embed.set_author(
                    name=f"{ctx.author.display_name} Enlarged Emoji!",
                    icon_url=ctx.author.display_avatar.url
                )
                await ctx.send(embed=embed)
            else:
                await ctx.send("**🚫 | Invalid emoji format!**", delete_after=3)
                
        except Exception as e:
            await ctx.send("**🚫 | Could not display the emoji!**", delete_after=3)

    async def _get_ai_sysify_response(self, text: str) -> str:
        """Use AI to generate sysified text"""
        try:
            # Import groq client
            from utils.ai_utils import groq_client
            
            prompt = f"""Transform the following text into a "SyS" style format. Here are examples of the transformation pattern:

Examples:
- "meow" becomes "SyS meow (๑•́ ₃ •̀๑)"
- "useless shit" becomes "SyS usewess shit >_<"
- "hell" becomes "SyS heww (◠‿◠✿)"
- "dumdum" becomes "SyS dumdum (⁎˃ᆺ˂)"

Rules:
1. Always start with "SyS"
2. Replace some 'l' with 'w' (like "hell" -> "heww", "useless" -> "usewess")
3. Add cute emoticons at the end like: (๑•́ ₃ •̀๑), >_<, (◠‿◠✿), (⁎˃ᆺ˂), (´∀｀), (＾◡＾), (´･ω･`), etc.
4. Keep the general meaning but make it cute/kawaii
5. Be creative with letter substitutions and emoticons

Transform this text: "{text}"

Only respond with the transformed text, nothing else."""

            response = await groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=100,
                temperature=0.8
            )
            
            return response.choices[0].message.content.strip()
        except:
            # Fallback transformation if AI fails
            return self._fallback_sysify(text)

    def _fallback_sysify(self, text: str) -> str:
        """Fallback sysify transformation"""
        # Simple transformations
        transformed = text.lower()
        transformed = transformed.replace('l', 'w')
        transformed = transformed.replace('r', 'w')
        
        # Random cute emoticons
        emoticons = ["(๑•́ ₃ •̀๑)", ">_<", "(◠‿◠✿)", "(⁎˃ᆺ˂)", "(´∀｀)", "(＾◡＾)", "(´･ω･`)", "( ˘ ³˘)♥", "(✿◠‿◠)", "ヽ(´▽`)/"]
        emoticon = random.choice(emoticons)
        
        return f"SyS {transformed} {emoticon}"

    @sys.command(name='sysify')
    async def sys_sysify(self, ctx, *, text: str = None):
        """Transform text into cute SyS style"""
        if text is None:
            return await ctx.send("**🚫 | Please provide text to sysify!**", delete_after=3)

        if len(text) > 200:
            return await ctx.send("**🚫 | Text is too long! Maximum 200 characters.**", delete_after=3)

        try:
            # Use AI to generate sysified text
            sysified_text = await self._get_ai_sysify_response(text)
            await ctx.send(sysified_text)
        except Exception as e:
            # Use fallback if AI fails
            sysified_text = self._fallback_sysify(text)
            await ctx.send(sysified_text)

    @sys.command(name='help')
    async def sys_help(self, ctx, command: str = None):
        """Get detailed help for economy commands"""
        if command is None:
            # Show main help with interaction menu
            await self._show_main_help(ctx)
            return
            
        # Get the current economy prefix for this guild
        current_prefix = self.economy_prefixes.get(ctx.guild.id, "sys")
        
        # Command help data
        command_help = {
            'cash': {
                'description': 'Check cowoncy balance for yourself or another user',
                'usage': f'{current_prefix} cash [user]',
                'aliases': 'cowoncy',
                'examples': [f'{current_prefix} cash', f'{current_prefix} cash @user']
            },
            'give': {
                'description': 'Give cowoncy to another user with confirmation',
                'usage': f'{current_prefix} give <amount> <user>',
                'aliases': 'None',
                'examples': [f'{current_prefix} give 1000 @user']
            },
            'slots': {
                'description': 'Play slot machine with different jackpot multipliers',
                'usage': f'{current_prefix} slots <amount>',
                'aliases': 's',
                'examples': [f'{current_prefix} slots 100', f'{current_prefix} s 500']
            },
            'coinflip': {
                'description': 'Flip a coin and bet on heads or tails',
                'usage': f'{current_prefix} coinflip <amount> [choice]',
                'aliases': 'cf',
                'examples': [f'{current_prefix} coinflip 100', f'{current_prefix} cf 200 heads']
            },
            'blackjack': {
                'description': 'Play blackjack against the dealer',
                'usage': f'{current_prefix} blackjack <amount>',
                'aliases': 'bj',
                'examples': [f'{current_prefix} blackjack 150', f'{current_prefix} bj 300']
            },
            'shop': {
                'description': 'View the ring shop with different tiers',
                'usage': f'{current_prefix} shop',
                'aliases': 'None',
                'examples': [f'{current_prefix} shop']
            },
            'buy': {
                'description': 'Buy a ring from the shop using its ID',
                'usage': f'{current_prefix} buy <id>',
                'aliases': 'None',
                'examples': [f'{current_prefix} buy 1', f'{current_prefix} buy 7']
            },
            'sell': {
                'description': 'Sell rings by ID or zoo animals by name/emoji',
                'usage': f'{current_prefix} sell <ring_id|animal_name|all>',
                'aliases': 'None',
                'examples': [f'{current_prefix} sell 3', f'{current_prefix} sell dog', f'{current_prefix} sell all']
            },
            'marry': {
                'description': 'Use a ring to propose to another user',
                'usage': f'{current_prefix} marry <user> <ring_id>',
                'aliases': 'None',
                'examples': [f'{current_prefix} marry @user 5']
            },
            'inventory': {
                'description': 'Check your or someone else\'s inventory',
                'usage': f'{current_prefix} inventory [user]',
                'aliases': 'inv',
                'examples': [f'{current_prefix} inventory', f'{current_prefix} inv @user']
            },
            'pray': {
                'description': 'Pray for luck points to increase gambling chances (5min cooldown)',
                'usage': f'{current_prefix} pray [user]',
                'aliases': 'None',
                'examples': [f'{current_prefix} pray', f'{current_prefix} pray @user']
            },
            'curse': {
                'description': 'Curse another user to steal their luck (5min cooldown)',
                'usage': f'{current_prefix} curse <user>',
                'aliases': 'None',
                'examples': [f'{current_prefix} curse @user']
            },
            'cookie': {
                'description': 'Give or check cookies',
                'usage': f'{current_prefix} cookie [user]',
                'aliases': 'None',
                'examples': [f'{current_prefix} cookie', f'{current_prefix} cookie @user']
            },
            'emoji': {
                'description': 'Enlarge and show emoji information',
                'usage': f'{current_prefix} emoji <emoji>',
                'aliases': 'None',
                'examples': [f'{current_prefix} emoji 😀', f'{current_prefix} emoji :custom_emoji:']
            },
            'sysify': {
                'description': 'Transform text into cute SyS style using AI',
                'usage': f'{current_prefix} sysify <text>',
                'aliases': 'None',
                'examples': [f'{current_prefix} sysify hello world']
            },
            'avatar': {
                'description': 'Display user\'s avatar in high quality with download links',
                'usage': f'{current_prefix} avatar [user]',
                'aliases': 'av',
                'examples': [f'{current_prefix} avatar', f'{current_prefix} av @user']
            },
            'prefix': {
                'description': 'Change economy prefix (Admin only)',
                'usage': f'{current_prefix} prefix <new_prefix>',
                'aliases': 'None',
                'examples': [f'{current_prefix} prefix eco', f'{current_prefix} prefix $']
            },
            'hug': {
                'description': 'Hug someone sweetly with an anime GIF',
                'usage': f'{current_prefix} hug [user]',
                'aliases': 'None',
                'examples': [f'{current_prefix} hug', f'{current_prefix} hug @user']
            },
            'kiss': {
                'description': 'Kiss someone lovingly with an anime GIF',
                'usage': f'{current_prefix} kiss [user]',
                'aliases': 'None',
                'examples': [f'{current_prefix} kiss @user']
            },
            'pat': {
                'description': 'Pat someone gently with an anime GIF',
                'usage': f'{current_prefix} pat [user]',
                'aliases': 'None',
                'examples': [f'{current_prefix} pat @user']
            },
            'dance': {
                'description': 'Dance with joy',
                'usage': f'{current_prefix} dance',
                'aliases': 'None',
                'examples': [f'{current_prefix} dance']
            }
        }
        
        command = command.lower()
        
        # Check for aliases
        if command in ['cowoncy']:
            command = 'cash'
        elif command in ['s']:
            command = 'slots'
        elif command in ['cf']:
            command = 'coinflip'
        elif command in ['bj']:
            command = 'blackjack'
        elif command in ['inv']:
            command = 'inventory'
        elif command in ['av']:
            command = 'avatar'
            
        if command not in command_help:
            embed = discord.Embed(
                title="<:icon_cross:1372375094336425986> Command Not Found",
                description=f"No help found for command `{command}`.\nUse `{current_prefix} help` to see all available commands.",
                color=0xFF0000
            )
            await ctx.send(embed=embed)
            return
            
        cmd_info = command_help[command]
        
        embed = discord.Embed(
            title=f"📚 Help: {command.title()}",
            description=cmd_info['description'],
            color=0x000000
        )
        
        embed.add_field(
            name="📝 Usage",
            value=f"`{cmd_info['usage']}`",
            inline=False
        )
        
        embed.add_field(
            name="🔗 Aliases", 
            value=cmd_info['aliases'],
            inline=True
        )
        
        embed.add_field(
            name="💡 Examples",
            value='\n'.join([f"`{ex}`" for ex in cmd_info['examples']]),
            inline=False
        )
        
        embed.set_author(
            name=f"Economy Help - {command.title()}",
            icon_url=ctx.author.display_avatar.url
        )
        
        embed.set_footer(
            text=f"Current prefix: {current_prefix}",
            icon_url=ctx.bot.user.display_avatar.url
        )
        
        await ctx.send(embed=embed)

    async def _show_main_help(self, ctx):
        """Show the main help page with interactive menu"""
        current_prefix = self.economy_prefixes.get(ctx.guild.id, "sys")
        
        # Create main help embed
        embed = discord.Embed(
            title="<:cowoncy:1385212758919745608> Economy System",
            description=f"Welcome to Strelizia's economy! Earn cowoncy, collect animals, and have fun with friends! ✨",
            color=0x000000
        )

        embed.add_field(
            name="🚀 **Getting Started**",
            value=f"`{current_prefix} cash` - Check your balance\n"
                  f"`{current_prefix} hunt` - Find cool animals\n"
                  f"`{current_prefix} slots 100` - Try your luck!",
            inline=False
        )
        
        embed.add_field(
            name="📚 **Need Help?**",
            value="Use the dropdown menu below to explore all features!\n"
                  f"Or try `{current_prefix} help <command>` for specific commands.",
            inline=False
        )

        embed.set_author(
            name=f"Hey {ctx.author.display_name}! 👋",
            icon_url=ctx.author.display_avatar.url
        )
        
        embed.set_footer(
            text=f"Your prefix: {current_prefix} • Have fun exploring! 🎉",
            icon_url=ctx.bot.user.display_avatar.url
        )
        
        embed.set_thumbnail(url=ctx.bot.user.display_avatar.url)
        
        # Create the view with dropdown
        view = EconomyHelpView(ctx, current_prefix, embed)
        await ctx.send(embed=embed, view=view)

    @sys.command(name='avatar', aliases=['av'])
    async def sys_avatar(self, ctx, user: discord.Member = None):
        """Display user's avatar in high quality"""
        target_user = user or ctx.author
        
        # Get different avatar formats
        avatar_url = target_user.display_avatar.url
        avatar_webp = target_user.display_avatar.replace(format='webp', size=1024).url
        avatar_png = target_user.display_avatar.replace(format='png', size=1024).url
        avatar_jpg = target_user.display_avatar.replace(format='jpg', size=1024).url
        
        # Create embed
        embed = discord.Embed(
            title=f"{target_user.display_name}'s Avatar",
            color=0x000000
        )
        
        embed.set_image(url=avatar_url)
        
        # Add avatar links
        embed.add_field(
            name="📸 Download Links",
            value=f"[PNG]({avatar_png}) • [JPG]({avatar_jpg}) • [WEBP]({avatar_webp})",
            inline=False
        )
        
        # Add user info
        embed.add_field(
            name="👤 User Info",
            value=f"**ID:** {target_user.id}\n**Created:** <t:{int(target_user.created_at.timestamp())}:R>",
            inline=True
        )
        
        if target_user.joined_at:
            embed.add_field(
                name="📅 Joined Server",
                value=f"<t:{int(target_user.joined_at.timestamp())}:R>",
                inline=True
            )
        
        # Add status info if available
        if hasattr(target_user, 'status') and target_user.status:
            status_emoji = {
                discord.Status.online: "🟢",
                discord.Status.idle: "🟡", 
                discord.Status.dnd: "🔴",
                discord.Status.offline: "⚫"
            }
            embed.add_field(
                name="📱 Status",
                value=f"{status_emoji.get(target_user.status, '❓')} {target_user.status.name.title()}",
                inline=True
            )
        
        embed.set_footer(
            text=f"Requested by {ctx.author.display_name}",
            icon_url=ctx.author.display_avatar.url
        )
        
        embed.timestamp = discord.utils.utcnow()
        
        await ctx.send(embed=embed)

    # Money Management Commands
    @sys.command(name='money')
    async def sys_money(self, ctx, action: str = None, amount: int = None, user: discord.Member = None):
        """Advanced money management system"""
        if action is None:
            # Show money dashboard
            user_balance = await self.db.get_user_balance(ctx.author.id)
            bank_balance = await self.db.get_bank_balance(ctx.author.id)
            total_wealth = user_balance + bank_balance
            
            # Get user's financial stats
            user_luck = await self.db.get_user_luck(ctx.author.id)
            daily_streak = await self.db.get_daily_streak(ctx.author.id)
            
            # Calculate portfolio value
            portfolio = await self.db.get_user_portfolio(ctx.author.id)
            portfolio_value = 0
            if portfolio:
                for symbol, shares in portfolio.items():
                    if shares > 0:
                        stock_price = await self.db.get_stock_price(symbol)
                        if stock_price:
                            portfolio_value += shares * stock_price
            
            embed = discord.Embed(
                title="💰 Financial Dashboard",
                description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nComplete overview of your financial status",
                color=0x000000
            )
            
            embed.add_field(
                name="💳 Liquid Assets",
                value=f"**Wallet:** {user_balance:,} <:cowoncy:1385212758919745608>\n"
                      f"**Bank:** {bank_balance:,} <:cowoncy:1385212758919745608>\n"
                      f"**Total Cash:** {user_balance + bank_balance:,} <:cowoncy:1385212758919745608>",
                inline=True
            )
            
            embed.add_field(
                name="📈 Investments",
                value=f"**Portfolio Value:** {portfolio_value:,.0f} <:cowoncy:1385212758919745608>\n"
                      f"**Total Wealth:** {total_wealth + portfolio_value:,.0f} <:cowoncy:1385212758919745608>\n"
                      f"**Investment %:** {(portfolio_value / (total_wealth + portfolio_value) * 100) if total_wealth + portfolio_value > 0 else 0:.1f}%",
                inline=True
            )
            
            embed.add_field(
                name="📊 Financial Stats",
                value=f"**Luck Points:** {user_luck}\n"
                      f"**Daily Streak:** {daily_streak} days\n"
                      f"**Risk Profile:** {'Conservative' if portfolio_value < total_wealth else 'Aggressive' if portfolio_value > total_wealth * 2 else 'Balanced'}",
                inline=True
            )
            
            # Financial tips based on user's status
            if total_wealth < 1000:
                tip = "💡 **Tip:** Start with `sys work` and `sys daily` to build your initial wealth!"
            elif bank_balance < user_balance:
                tip = "💡 **Tip:** Consider using `sys bank deposit` to earn 2% daily interest!"
            elif portfolio_value == 0:
                tip = "💡 **Tip:** Try investing with `sys stocks buy` to grow your wealth!"
            else:
                tip = "💡 **Tip:** You're doing great! Keep diversifying your portfolio!"
            
            embed.add_field(
                name="💡 Financial Advice",
                value=tip,
                inline=False
            )
            
            embed.set_author(
                name=f"{ctx.author.display_name}'s Financial Portfolio",
                icon_url=ctx.author.display_avatar.url
            )
            
            embed.set_footer(
                text="Use 'sys money help' for money management commands",
                icon_url=ctx.bot.user.display_avatar.url
            )
            
            await ctx.send(embed=embed)
            return
        
        action = action.lower()
        
        if action == "help":
            embed = discord.Embed(
                title="💰 Money Management Commands",
                description="Advanced financial tools and analytics",
                color=0x000000
            )
            
            current_prefix = self.economy_prefixes.get(ctx.guild.id, "sys")
            
            embed.add_field(
                name="📊 Analysis Commands",
                value=f"`{current_prefix} money stats [user]` - Detailed financial analysis\n"
                      f"`{current_prefix} money breakdown [user]` - Income/expense breakdown\n"
                      f"`{current_prefix} money history` - Transaction history\n"
                      f"`{current_prefix} money goals` - Set and track financial goals",
                inline=False
            )
            
            embed.add_field(
                name="💸 Transaction Commands",
                value=f"`{current_prefix} money send <amount> <user>` - Send money instantly\n"
                      f"`{current_prefix} money request <amount> <user>` - Request money\n"
                      f"`{current_prefix} money split <amount> <users...>` - Split bills\n"
                      f"`{current_prefix} money tax` - View and pay taxes",
                inline=False
            )
            
            embed.add_field(
                name="🏦 Advanced Banking",
                value=f"`{current_prefix} money loan <amount>` - Apply for loans\n"
                      f"`{current_prefix} money invest <amount>` - Quick invest\n"
                      f"`{current_prefix} money budget` - Set spending budgets\n"
                      f"`{current_prefix} money autopay` - Set up automatic payments",
                inline=False
            )
            
            await ctx.send(embed=embed)
            
        elif action == "stats":
            target_user = user or ctx.author
            
            # Get comprehensive financial data
            user_balance = await self.db.get_user_balance(target_user.id)
            bank_balance = await self.db.get_bank_balance(target_user.id)
            portfolio = await self.db.get_user_portfolio(target_user.id)
            user_luck = await self.db.get_user_luck(target_user.id)
            daily_streak = await self.db.get_daily_streak(target_user.id)
            job_stats = await self.db.get_user_job_stats(target_user.id)
            
            # Calculate portfolio metrics
            portfolio_value = 0
            portfolio_diversity = 0
            if portfolio:
                portfolio_diversity = len([s for s in portfolio.values() if s > 0])
                for symbol, shares in portfolio.items():
                    if shares > 0:
                        stock_price = await self.db.get_stock_price(symbol)
                        if stock_price:
                            portfolio_value += shares * stock_price
            
            total_wealth = user_balance + bank_balance + portfolio_value
            
            embed = discord.Embed(
                title=f"📊 {target_user.display_name}'s Financial Analysis",
                description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
                color=0x000000
            )
            
            embed.add_field(
                name="💰 Wealth Distribution",
                value=f"**Cash:** {user_balance + bank_balance:,} ({((user_balance + bank_balance) / total_wealth * 100) if total_wealth > 0 else 0:.1f}%)\n"
                      f"**Investments:** {portfolio_value:,.0f} ({(portfolio_value / total_wealth * 100) if total_wealth > 0 else 0:.1f}%)\n"
                      f"**Total Net Worth:** {total_wealth:,.0f} <:cowoncy:1385212758919745608>",
                inline=True
            )
            
            embed.add_field(
                name="📈 Investment Profile",
                value=f"**Portfolio Value:** {portfolio_value:,.0f}\n"
                      f"**Diversification:** {portfolio_diversity} stocks\n"
                      f"**Risk Level:** {'Low' if portfolio_value < total_wealth * 0.3 else 'High' if portfolio_value > total_wealth * 0.7 else 'Medium'}",
                inline=True
            )
            
            embed.add_field(
                name="🎯 Performance Metrics",
                value=f"**Luck Factor:** {user_luck} points\n"
                      f"**Consistency:** {daily_streak} day streak\n"
                      f"**Experience:** {job_stats.get('experience', 0)} XP\n"
                      f"**Education:** {job_stats.get('education', 0)} level",
                inline=True
            )
            
            # Financial health score
            health_score = min(100, (
                (daily_streak * 2) +
                (user_luck * 3) +
                (portfolio_diversity * 5) +
                (job_stats.get('experience', 0) // 2) +
                (30 if bank_balance > user_balance else 0)
            ))
            
            health_emoji = "🟢" if health_score >= 70 else "🟡" if health_score >= 40 else "🔴"
            
            embed.add_field(
                name="💚 Financial Health Score",
                value=f"{health_emoji} **{health_score}/100**\n"
                      f"{'Excellent' if health_score >= 80 else 'Good' if health_score >= 60 else 'Fair' if health_score >= 40 else 'Poor'} financial health",
                inline=False
            )
            
            await ctx.send(embed=embed)
            
        elif action == "send":
            if amount is None or user is None:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, usage: `sys money send <amount> <user>`")
                
            if user == ctx.author:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you can't send money to yourself!")
                
            if amount <= 0:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, amount must be positive!")
                
            sender_balance = await self.db.get_user_balance(ctx.author.id)
            if sender_balance < amount:
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, insufficient funds! You have {sender_balance:,} cowoncy.")
                
            # Process instant transfer
            receiver_balance = await self.db.get_user_balance(user.id)
            await self.db.update_user_balance(ctx.author.id, sender_balance - amount)
            await self.db.update_user_balance(user.id, receiver_balance + amount)
            
            embed = discord.Embed(
                title="💸 Money Transfer Complete",
                description=f"**{ctx.author.mention}** sent **{amount:,}** <:cowoncy:1385212758919745608> to **{user.mention}**",
                color=0x000000
            )
            
            embed.add_field(
                name="Transaction Details",
                value=f"**Amount:** {amount:,} <:cowoncy:1385212758919745608>\n"
                      f"**Sender Balance:** {sender_balance - amount:,}\n"
                      f"**Receiver Balance:** {receiver_balance + amount:,}",
                inline=False
            )
            
            await ctx.send(embed=embed)
            
        elif action == "breakdown":
            target_user = user or ctx.author
            
            embed = discord.Embed(
                title=f"📊 {target_user.display_name}'s Financial Breakdown",
                description="Income and expense analysis",
                color=0x000000
            )
            
            # Simulated data based on user's activity
            job_stats = await self.db.get_user_job_stats(target_user.id)
            times_worked = job_stats.get('times_worked', 0)
            
            # Estimate income sources
            estimated_job_income = times_worked * 500  # Average job income
            estimated_gambling = random.randint(100, 2000)  # Gambling activity
            estimated_daily = await self.db.get_daily_streak(target_user.id) * 1000  # Daily rewards
            
            total_estimated_income = estimated_job_income + estimated_gambling + estimated_daily
            
            embed.add_field(
                name="💰 Income Sources",
                value=f"**Job Earnings:** {estimated_job_income:,} ({(estimated_job_income/total_estimated_income*100) if total_estimated_income > 0 else 0:.1f}%)\n"
                      f"**Gambling Wins:** {estimated_gambling:,} ({(estimated_gambling/total_estimated_income*100) if total_estimated_income > 0 else 0:.1f}%)\n"
                      f"**Daily Rewards:** {estimated_daily:,} ({(estimated_daily/total_estimated_income*100) if total_estimated_income > 0 else 0:.1f}%)\n"
                      f"**Total Income:** {total_estimated_income:,} <:cowoncy:1385212758919745608>",
                inline=False
            )
            
            # Estimate expenses
            estimated_shopping = random.randint(50, 500)
            estimated_gambling_loss = random.randint(100, 1000)
            estimated_investments = random.randint(200, 1500)
            
            total_estimated_expenses = estimated_shopping + estimated_gambling_loss + estimated_investments
            
            embed.add_field(
                name="💸 Expense Categories",
                value=f"**Shopping:** {estimated_shopping:,} ({(estimated_shopping/total_estimated_expenses*100) if total_estimated_expenses > 0 else 0:.1f}%)\n"
                      f"**Gambling Losses:** {estimated_gambling_loss:,} ({(estimated_gambling_loss/total_estimated_expenses*100) if total_estimated_expenses > 0 else 0:.1f}%)\n"
                      f"**Investments:** {estimated_investments:,} ({(estimated_investments/total_estimated_expenses*100) if total_estimated_expenses > 0 else 0:.1f}%)\n"
                      f"**Total Expenses:** {total_estimated_expenses:,} <:cowoncy:1385212758919745608>",
                inline=False
            )
            
            net_worth = total_estimated_income - total_estimated_expenses
            embed.add_field(
                name="📈 Net Worth Change",
                value=f"**{'📈 Profit' if net_worth > 0 else '📉 Loss'}:** {abs(net_worth):,} <:cowoncy:1385212758919745608>\n"
                      f"**Savings Rate:** {(net_worth/total_estimated_income*100) if total_estimated_income > 0 else 0:.1f}%",
                inline=False
            )
            
            await ctx.send(embed=embed)

    @sys.command(name='finance')
    async def sys_finance(self, ctx, action: str = None):
        """Advanced financial planning tools"""
        if action is None:
            embed = discord.Embed(
                title="🏦 Financial Planning Center",
                description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nAdvanced tools for financial success",
                color=0x000000
            )
            
            current_prefix = self.economy_prefixes.get(ctx.guild.id, "sys")
            
            embed.add_field(
                name="📊 Planning Tools",
                value=f"`{current_prefix} finance budget` - Create spending budgets\n"
                      f"`{current_prefix} finance goals` - Set financial goals\n"
                      f"`{current_prefix} finance advisor` - Get AI financial advice\n"
                      f"`{current_prefix} finance calculator` - Financial calculators",
                inline=False
            )
            
            embed.add_field(
                name="📈 Investment Tools",
                value=f"`{current_prefix} finance diversify` - Portfolio diversification tips\n"
                      f"`{current_prefix} finance risk` - Risk assessment\n"
                      f"`{current_prefix} finance compound` - Compound interest calculator\n"
                      f"`{current_prefix} finance rebalance` - Portfolio rebalancing",
                inline=False
            )
            
            embed.add_field(
                name="💡 Financial Education",
                value=f"`{current_prefix} finance learn` - Financial literacy courses\n"
                      f"`{current_prefix} finance terms` - Financial glossary\n"
                      f"`{current_prefix} finance news` - Market news and updates\n"
                      f"`{current_prefix} finance tips` - Daily financial tips",
                inline=False
            )
            
            await ctx.send(embed=embed)
            
        elif action == "budget":
            user_balance = await self.db.get_user_balance(ctx.author.id)
            
            embed = discord.Embed(
                title="💳 Budget Planner",
                description=f"Smart budgeting for {user_balance:,} <:cowoncy:1385212758919745608>",
                color=0x000000
            )
            
            # Suggest budget allocation
            emergency_fund = int(user_balance * 0.2)
            investments = int(user_balance * 0.3)
            gambling_budget = int(user_balance * 0.1)
            spending_money = user_balance - emergency_fund - investments - gambling_budget
            
            embed.add_field(
                name="📊 Recommended Allocation",
                value=f"**Emergency Fund (20%):** {emergency_fund:,} <:cowoncy:1385212758919745608>\n"
                      f"**Investments (30%):** {investments:,} <:cowoncy:1385212758919745608>\n"
                      f"**Entertainment/Gambling (10%):** {gambling_budget:,} <:cowoncy:1385212758919745608>\n"
                      f"**Spending Money (40%):** {spending_money:,} <:cowoncy:1385212758919745608>",
                inline=False
            )
            
            embed.add_field(
                name="💡 Budget Tips",
                value="• Keep emergency funds in bank for 2% daily interest\n"
                      "• Diversify investments across different stocks\n"
                      "• Set strict gambling limits to avoid losses\n"
                      "• Track your spending with `sys money breakdown`",
                inline=False
            )
            
            await ctx.send(embed=embed)
            
        elif action == "goals":
            embed = discord.Embed(
                title="🎯 Financial Goals Tracker",
                description="Set and achieve your financial milestones",
                color=0x000000
            )
            
            user_balance = await self.db.get_user_balance(ctx.author.id)
            bank_balance = await self.db.get_bank_balance(ctx.author.id)
            total_wealth = user_balance + bank_balance
            
            # Common financial goals
            goals = [
                {"name": "Emergency Fund", "target": 10000, "current": bank_balance},
                {"name": "First Million", "target": 1000000, "current": total_wealth},
                {"name": "Investment Portfolio", "target": 50000, "current": 0},  # Would calculate from portfolio
                {"name": "Retirement Fund", "target": 5000000, "current": total_wealth}
            ]
            
            for goal in goals:
                progress = min(100, (goal["current"] / goal["target"]) * 100)
                progress_bar = "█" * int(progress // 10) + "░" * (10 - int(progress // 10))
                
                embed.add_field(
                    name=f"🎯 {goal['name']}",
                    value=f"`{progress_bar}` {progress:.1f}%\n"
                          f"**Progress:** {goal['current']:,} / {goal['target']:,} <:cowoncy:1385212758919745608>",
                    inline=True
                )
            
            await ctx.send(embed=embed)

    @sys.command(name='wealth')
    async def sys_wealth(self, ctx):
        """Display comprehensive wealth statistics"""
        user_balance = await self.db.get_user_balance(ctx.author.id)
        bank_balance = await self.db.get_bank_balance(ctx.author.id)
        portfolio = await self.db.get_user_portfolio(ctx.author.id)
        
        # Calculate portfolio value
        portfolio_value = 0
        if portfolio:
            for symbol, shares in portfolio.items():
                if shares > 0:
                    stock_price = await self.db.get_stock_price(symbol)
                    if stock_price:
                        portfolio_value += shares * stock_price
        
        total_wealth = user_balance + bank_balance + portfolio_value
        
        embed = discord.Embed(
            title="💎 Wealth Overview",
            description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nComplete wealth analysis and breakdown",
            color=0x000000
        )
        
        # Wealth breakdown
        cash_percentage = ((user_balance + bank_balance) / total_wealth * 100) if total_wealth > 0 else 0
        investment_percentage = (portfolio_value / total_wealth * 100) if total_wealth > 0 else 0
        
        embed.add_field(
            name="💰 Asset Allocation",
            value=f"**Total Net Worth:** {total_wealth:,.0f} <:cowoncy:1385212758919745608>\n\n"
                  f"**Cash Assets:** {user_balance + bank_balance:,} ({cash_percentage:.1f}%)\n"
                  f"└ Wallet: {user_balance:,}\n"
                  f"└ Bank: {bank_balance:,}\n\n"
                  f"**Investments:** {portfolio_value:,.0f} ({investment_percentage:.1f}%)\n"
                  f"└ Stock Portfolio: {portfolio_value:,.0f}",
            inline=False
        )
        
        # Wealth ranking
        wealth_rank = "💎 Ultra High" if total_wealth >= 10000000 else \
                      "🏆 Very High" if total_wealth >= 5000000 else \
                      "🥇 High" if total_wealth >= 1000000 else \
                      "🥈 Upper Middle" if total_wealth >= 500000 else \
                      "🥉 Middle" if total_wealth >= 100000 else \
                      "📈 Building" if total_wealth >= 10000 else \
                      "🌱 Starting"
        
        embed.add_field(
            name="📊 Wealth Classification",
            value=f"**Class:** {wealth_rank}\n"
                  f"**Liquidity Ratio:** {((user_balance) / total_wealth * 100) if total_wealth > 0 else 0:.1f}%\n"
                  f"**Investment Ratio:** {investment_percentage:.1f}%",
            inline=True
        )
        
        # Growth metrics
        daily_streak = await self.db.get_daily_streak(ctx.author.id)
        luck_points = await self.db.get_user_luck(ctx.author.id)
        
        embed.add_field(
            name="📈 Growth Metrics",
            value=f"**Daily Streak:** {daily_streak} days\n"
                  f"**Luck Factor:** {luck_points} points\n"
                  f"**Risk Profile:** {'Conservative' if investment_percentage < 30 else 'Aggressive' if investment_percentage > 70 else 'Balanced'}",
            inline=True
        )
        
        embed.set_author(
            name=f"{ctx.author.display_name}'s Wealth Portfolio",
            icon_url=ctx.author.display_avatar.url
        )
        
        embed.set_footer(
            text="💡 Tip: Diversify your portfolio for optimal growth",
            icon_url=ctx.bot.user.display_avatar.url
        )
        
        await ctx.send(embed=embed)

    @sys.command(name='teamadd')
    async def sys_team_add(self, ctx, animal: str = None):
        """Add an animal to your battle team"""
        if animal is None:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must specify an animal to add to your team!", delete_after=3)
        
        # Get user's zoo and team
        zoo_data = await self.db.get_user_zoo(ctx.author.id)
        if not zoo_data:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have any animals in your zoo! Use `sys hunt` first.", delete_after=3)
        
        team_data = await self.db.get_user_team(ctx.author.id)
        if not team_data:
            team_data = []
        
        # Check if team is full (max 3 animals)
        if len(team_data) >= 3:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, your team is full! Remove an animal first.", delete_after=3)
        
        # Find the animal in zoo
        found_animal = None
        found_rarity = None
        animal_lower = animal.lower()
        
        for rarity, animals in zoo_data.items():
            for emoji, count in animals.items():
                if emoji in ZOO_ANIMALS[rarity]:
                    animal_name = ZOO_ANIMALS[rarity][emoji]['name']
                    if animal_name == animal_lower or emoji == animal:
                        if count > 0:
                            found_animal = emoji
                            found_rarity = rarity
                            break
            if found_animal:
                break
        
        if not found_animal:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have that animal in your zoo!", delete_after=3)
        
        # Check if animal is already in team
        if found_animal in team_data:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, {found_animal} is already in your team!", delete_after=3)
        
        # Add to team
        team_data.append(found_animal)
        await self.db.update_user_team(ctx.author.id, team_data)
        
        animal_info = ZOO_ANIMALS[found_rarity][found_animal]
        await ctx.send(f"<:icon_tick:1372375089668161597> **{found_animal} {animal_info['name']}** added to your battle team!")

    @sys.command(name='teamremove')
    async def sys_team_remove(self, ctx, animal: str = None):
        """Remove an animal from your battle team"""
        if animal is None:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must specify an animal to remove!", delete_after=3)
        
        team_data = await self.db.get_user_team(ctx.author.id)
        if not team_data:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, your team is empty!", delete_after=3)
        
        # Find animal in team
        animal_lower = animal.lower()
        found_animal = None
        
        for emoji in team_data:
            for rarity, animals in ZOO_ANIMALS.items():
                if emoji in animals:
                    animal_name = animals[emoji]['name']
                    if animal_name == animal_lower or emoji == animal:
                        found_animal = emoji
                        break
            if found_animal:
                break
        
        if not found_animal:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, that animal is not in your team!", delete_after=3)
        
        # Remove from team
        team_data.remove(found_animal)
        await self.db.update_user_team(ctx.author.id, team_data)
        
        await ctx.send(f"<:icon_tick:1372375089668161597> **{found_animal}** removed from your battle team!")

    @sys.command(name='teamview')
    async def sys_team_view(self, ctx):
        """View your current battle team"""
        team_data = await self.db.get_user_team(ctx.author.id)
        if not team_data:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, your team is empty! Use `sys team add <animal>` to add animals.", delete_after=3)
        
        embed = discord.Embed(
            title=f"⚔️ {ctx.author.display_name}'s Battle Team",
            color=0x000000
        )
        
        team_display = ""
        total_hp = 0
        total_attack = 0
        
        for i, emoji in enumerate(team_data, 1):
            for rarity, animals in ZOO_ANIMALS.items():
                if emoji in animals:
                    animal_info = animals[emoji]
                    color = RARITY_COLORS[rarity]
                    team_display += f"`{i}.` {color} {emoji} **{animal_info['name'].title()}** - HP: {animal_info['hp']} | ATK: {animal_info['attack']}\n"
                    total_hp += animal_info['hp']
                    total_attack += animal_info['attack']
                    break
        
        embed.description = team_display
        embed.add_field(
            name="📊 Team Stats",
            value=f"**Total HP:** {total_hp}\n**Total Attack:** {total_attack}",
            inline=False
        )
        
        await ctx.send(embed=embed)

    @sys.command(name='teamclear')
    async def sys_team_clear(self, ctx):
        """Clear your battle team"""
        await self.db.update_user_team(ctx.author.id, [])
        await ctx.send(f"<:icon_tick:1372375089668161597> **{ctx.author.display_name}**, your battle team has been cleared!")

    # Individual team command methods for custom prefix support
    async def sys_team_add(self, ctx, animal: str = None):
        """Add an animal to your battle team"""
        if animal is None:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must specify an animal to add to your team!", delete_after=3)
        
        # Get user's zoo and team
        zoo_data = await self.db.get_user_zoo(ctx.author.id)
        if not zoo_data:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have any animals in your zoo! Use `sys hunt` first.", delete_after=3)
        
        team_data = await self.db.get_user_team(ctx.author.id)
        if not team_data:
            team_data = []
        
        # Check if team is full (max 3 animals)
        if len(team_data) >= 3:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, your team is full! Remove an animal first.", delete_after=3)
        
        # Find the animal in zoo
        found_animal = None
        found_rarity = None
        animal_lower = animal.lower()
        
        for rarity, animals in zoo_data.items():
            for emoji, count in animals.items():
                if emoji in ZOO_ANIMALS[rarity]:
                    animal_name = ZOO_ANIMALS[rarity][emoji]['name']
                    if animal_name == animal_lower or emoji == animal:
                        if count > 0:
                            found_animal = emoji
                            found_rarity = rarity
                            break
            if found_animal:
                break
        
        if not found_animal:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you don't have that animal in your zoo!", delete_after=3)
        
        # Check if animal is already in team
        if found_animal in team_data:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, {found_animal} is already in your team!", delete_after=3)
        
        # Add to team
        team_data.append(found_animal)
        await self.db.update_user_team(ctx.author.id, team_data)
        
        animal_info = ZOO_ANIMALS[found_rarity][found_animal]
        await ctx.send(f"<:icon_tick:1372375089668161597> **{found_animal} {animal_info['name']}** added to your battle team!")

    async def sys_team_remove(self, ctx, animal: str = None):
        """Remove an animal from your battle team"""
        if animal is None:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must specify an animal to remove!", delete_after=3)
        
        team_data = await self.db.get_user_team(ctx.author.id)
        if not team_data:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, your team is empty!", delete_after=3)
        
        # Find animal in team
        animal_lower = animal.lower()
        found_animal = None
        
        for emoji in team_data:
            for rarity, animals in ZOO_ANIMALS.items():
                if emoji in animals:
                    animal_name = animals[emoji]['name']
                    if animal_name == animal_lower or emoji == animal:
                        found_animal = emoji
                        break
            if found_animal:
                break
        
        if not found_animal:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, that animal is not in your team!", delete_after=3)
        
        # Remove from team
        team_data.remove(found_animal)
        await self.db.update_user_team(ctx.author.id, team_data)
        
        await ctx.send(f"<:icon_tick:1372375089668161597> **{found_animal}** removed from your battle team!")

    async def sys_team_view(self, ctx):
        """View your current battle team"""
        team_data = await self.db.get_user_team(ctx.author.id)
        if not team_data:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, your team is empty! Use `sys team add <animal>` to add animals.", delete_after=3)
        
        embed = discord.Embed(
            title=f"⚔️ {ctx.author.display_name}'s Battle Team",
            color=0x000000
        )
        
        team_display = ""
        total_hp = 0
        total_attack = 0
        
        for i, emoji in enumerate(team_data, 1):
            for rarity, animals in ZOO_ANIMALS.items():
                if emoji in animals:
                    animal_info = animals[emoji]
                    color = RARITY_COLORS[rarity]
                    team_display += f"`{i}.` {color} {emoji} **{animal_info['name'].title()}** - HP: {animal_info['hp']} | ATK: {animal_info['attack']}\n"
                    total_hp += animal_info['hp']
                    total_attack += animal_info['attack']
                    break
        
        embed.description = team_display
        embed.add_field(
            name="📊 Team Stats",
            value=f"**Total HP:** {total_hp}\n**Total Attack:** {total_attack}",
            inline=False
        )
        
        await ctx.send(embed=embed)

    

    @sys.command(name='zoo')
    async def sys_zoo(self, ctx, user: discord.Member = None):
        """View your or someone's zoo collection"""
        target_user = user or ctx.author
        zoo_data = await self.db.get_user_zoo(target_user.id)
        
        if not zoo_data:
            # Initialize empty zoo
            zoo_data = {rarity: {} for rarity in ZOO_ANIMALS.keys()}
            await self.db.update_user_zoo(target_user.id, zoo_data)
        
        points, rarity_counts = self.calculate_zoo_points(zoo_data)
        
        embed = discord.Embed(
            title=f"🌿 🌱 🌳 **{target_user.display_name}'s zoo!** 🌳 🌱 🌿",
            color=0x000000
        )
        
        zoo_display = ""
        for rarity in ['common', 'uncommon', 'rare', 'epic', 'mythic']:
            color = RARITY_COLORS[rarity]
            animals_line = f"{color} "
            
            rarity_animals = zoo_data.get(rarity, {})
            if not rarity_animals:
                animals_line += "❓⁰⁰ " * 5
            else:
                count = 0
                for emoji in ZOO_ANIMALS[rarity]:
                    animal_count = rarity_animals.get(emoji, 0)
                    animals_line += f"{emoji}{animal_count:02d} "
                    count += 1
                    if count >= 5:
                        break
                
                # Fill remaining slots with unknown
                while count < 5:
                    animals_line += "❓⁰⁰ "
                    count += 1
            
            zoo_display += animals_line.strip() + "\n"
        
        embed.description = zoo_display
        
        # Zoo points breakdown
        embed.add_field(
            name="📊 Zoo Stats",
            value=f"**Zoo Points: __{points:,}__**\n"
                  f"**M-{rarity_counts['mythic']}, E-{rarity_counts['epic']}, R-{rarity_counts['rare']}, U-{rarity_counts['uncommon']}, C-{rarity_counts['common']}**",
            inline=False
        )
        
        embed.set_author(
            name=f"{target_user.display_name}'s Zoo Collection",
            icon_url=target_user.display_avatar.url
        )
        
        embed.set_footer(
            text=f"Use sys hunt to find more animals!",
            icon_url=ctx.bot.user.display_avatar.url
        )
        
        await ctx.send(embed=embed)

    @sys.command(name='hunt', aliases=['h'])
    async def sys_hunt(self, ctx):
        """Hunt for animals to add to your zoo"""
        # Check cooldown
        user_id = ctx.author.id
        current_time = datetime.now()
        last_hunt = await self.db.get_last_hunt_time(user_id)
        
        if last_hunt:
            last_hunt_dt = datetime.fromisoformat(last_hunt)
            time_diff = current_time - last_hunt_dt
            cooldown_seconds = 12  # 12 second cooldown
            
            if time_diff < timedelta(seconds=cooldown_seconds):
                remaining_time = timedelta(seconds=cooldown_seconds) - time_diff
                remaining_seconds = int(remaining_time.total_seconds())
                
                cooldown_msg = f"**⏱ | {ctx.author.display_name}**! You're tired from hunting. Try again in **{remaining_seconds}** seconds."
                return await ctx.send(cooldown_msg, delete_after=remaining_seconds)
        
        # Update hunt time
        await self.db.set_last_hunt_time(user_id, current_time.isoformat())
        
        # Get user luck for hunting bonus
        user_luck = await self.db.get_user_luck(user_id)
        luck_bonus = min(user_luck * 2, 20)  # Max 20% bonus
        
        # Hunt for 1-6 animals (more animals like OwO)
        num_animals = random.choices([1, 2, 3, 4, 5, 6], weights=[20, 25, 20, 15, 15, 5])[0]
        found_animals = []
        
        for _ in range(num_animals):
            animal, rarity = self.get_random_animal(luck_bonus)
            found_animals.append((animal, rarity))
        
        # Add to zoo
        zoo_data = await self.db.get_user_zoo(user_id)
        if not zoo_data:
            zoo_data = {rarity: {} for rarity in ZOO_ANIMALS.keys()}
        
        for animal, rarity in found_animals:
            if rarity not in zoo_data:
                zoo_data[rarity] = {}
            zoo_data[rarity][animal] = zoo_data[rarity].get(animal, 0) + 1
        
        await self.db.update_user_zoo(user_id, zoo_data)
        
        # Get user's actual gems or create defaults
        user_gems = await self.db.get_user_gems(user_id)
        if not user_gems:
            user_gems = {
                'power': random.randint(40, 75),
                'fire': random.randint(700, 1000), 
                'magic': random.randint(250, 525)
            }
            await self.db.update_user_gems(user_id, user_gems)
        
        power_gem = user_gems.get('power', random.randint(40, 75))
        fire_gem = user_gems.get('fire', random.randint(700, 1000))
        magic_gem = user_gems.get('magic', random.randint(250, 525))
        
        # Create response message with better formatting
        animal_str = " ".join([animal for animal, _ in found_animals])
        
        hunt_msg = (
            f"**🌱 | {ctx.author.display_name}**, hunt is empowered by "
            f"💎`[{power_gem}/75]` "
            f"🔥`[{fire_gem}/1000]` "
            f"✨`[{magic_gem}/525]` !\n"
            f"**|** You found: {animal_str}"
        )
        
        await ctx.send(hunt_msg, delete_after=12)

    

    

    @sys.command(name='battle', aliases=['b'])
    async def sys_battle(self, ctx, user: discord.Member = None):
        """Battle another user's zoo"""
        if user is None:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you must specify a user to battle!", delete_after=3)
        
        if user == ctx.author:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you can't battle yourself!", delete_after=3)
        
        if user.bot:
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you can't battle a bot!", delete_after=3)
        
        # Check if user has a team
        user_team = await self.db.get_user_team(ctx.author.id)
        if not user_team:
            current_prefix = self.economy_prefixes.get(ctx.guild.id, "sys")
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, Create a team with the command `{current_prefix} team add {{animal}}`", delete_after=3)
        
        # Check if opponent has animals
        opponent_team = await self.db.get_user_team(user.id)
        if not opponent_team:
            # Auto-generate team for opponent if they don't have one
            zoo2 = await self.db.get_user_zoo(user.id)
            if not zoo2 or not any(zoo2.values()):
                return await ctx.send(f"**🚫 | {ctx.author.display_name}**, {user.display_name} doesn't have any animals to battle!", delete_after=3)
            
            # Auto-create team from strongest animals
            auto_team = []
            for rarity in ['mythic', 'epic', 'rare', 'uncommon', 'common']:
                if len(auto_team) >= 3:
                    break
                animals = zoo2.get(rarity, {})
                for emoji, count in animals.items():
                    if count > 0 and len(auto_team) < 3:
                        auto_team.append(emoji)
            opponent_team = auto_team
        
        # Get both users' zoos
        zoo1 = await self.db.get_user_zoo(ctx.author.id)
        zoo2 = await self.db.get_user_zoo(user.id)
        
        if not zoo1 or not any(zoo1.values()):
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, you need animals in your zoo to battle! Use `sys hunt` first.", delete_after=3)
        
        if not zoo2 or not any(zoo2.values()):
            return await ctx.send(f"**🚫 | {ctx.author.display_name}**, {user.display_name} doesn't have any animals to battle!", delete_after=3)
        
        # Select fighting animals (strongest from each zoo)
        def get_strongest_animal(zoo_data):
            strongest = None
            max_power = 0
            
            for rarity, animals in zoo_data.items():
                for animal, count in animals.items():
                    if count > 0 and animal in ZOO_ANIMALS[rarity]:
                        stats = ZOO_ANIMALS[rarity][animal]
                        power = stats['hp'] + stats['attack']
                        if power > max_power:
                            max_power = power
                            strongest = (animal, rarity, stats)
            
            return strongest
        
        animal1 = get_strongest_animal(zoo1)
        animal2 = get_strongest_animal(zoo2)
        
        if not animal1 or not animal2:
            return await ctx.send("**🚫 | Battle failed - could not find valid animals to fight!**", delete_after=3)
        
        # Battle simulation
        emoji1, rarity1, stats1 = animal1
        emoji2, rarity2, stats2 = animal2
        
        hp1 = stats1['hp']
        hp2 = stats2['hp']
        max_hp1, max_hp2 = hp1, hp2
        
        battle_actions = []
        turn = 0
        
        while hp1 > 0 and hp2 > 0 and turn < 10:  # Max 10 turns
            # Player 1 attacks
            damage1 = random.randint(stats1['attack'] - 10, stats1['attack'] + 10)
            hp2 -= damage1
            battle_actions.append(f"{emoji1} dealt {damage1} damage!")
            
            if hp2 <= 0:
                break
            
            # Player 2 attacks
            damage2 = random.randint(stats2['attack'] - 10, stats2['attack'] + 10)
            hp1 -= damage2
            battle_actions.append(f"{emoji2} retaliated for {damage2} damage!")
            
            turn += 1
        
        # Determine winner
        if hp1 > hp2:
            winner = ctx.author
            reward = random.randint(200, 800)
        elif hp2 > hp1:
            winner = user
            reward = random.randint(200, 800)
        else:
            winner = None
            reward = 100
        
        # Award cowoncy to winner
        if winner:
            winner_balance = await self.db.get_user_balance(winner.id)
            await self.db.update_user_balance(winner.id, winner_balance + reward)
        
        # Generate battle image
        battle_data = {
            'hp1_percent': max(0, int(hp1 * 100 / max_hp1)),
            'hp2_percent': max(0, int(hp2 * 100 / max_hp2)),
            'actions': battle_actions,
            'winner': winner.display_name if winner else 'Draw'
        }
        
        battle_image = await self.generate_battle_image(
            ctx.author, user,
            ctx.author.display_avatar.url,
            user.display_avatar.url,
            battle_data
        )
        
        # Create result embed
        embed = discord.Embed(
            title=f"⚔️ **{ctx.author.display_name} vs {user.display_name}**",
            color=0xFF6B00
        )
        
        battle_text = f"{emoji1} **{stats1['name'].title()}** vs {emoji2} **{stats2['name'].title()}**\n\n"
        for action in battle_actions[:4]:  # Show first 4 actions
            battle_text += f"{action}\n"
        
        if winner:
            battle_text += f"\n🏆 **Winner: {winner.display_name}**\n💰 +{reward:,} <:cowoncy:1385212758919745608>"
        else:
            battle_text += f"\n🤝 **Draw!** Both fighters are exhausted."
        
        embed.description = battle_text
        
        if battle_image:
            file = discord.File(battle_image, filename="battle.png")
            embed.set_image(url="attachment://battle.png")
            await ctx.send(embed=embed, file=file)
        else:
            await ctx.send(embed=embed)

    

class EconomyHelpDropdown(discord.ui.Select):
    def __init__(self, ctx, current_prefix, home_embed):
        self.ctx = ctx
        self.current_prefix = current_prefix
        self.home_embed = home_embed
        
        options = [
            discord.SelectOption(
                label="🏠 Home",
                description="Return to main help page",
                emoji="🏠",
                value="home"
            ),
            discord.SelectOption(
                label="💰 Currency",
                description="Money management & balance commands",
                emoji="💰",
                value="currency"
            ),
            discord.SelectOption(
                label="🎰 Gambling",
                description="Casino games & betting commands",
                emoji="🎰",
                value="gambling"
            ),
            discord.SelectOption(
                label="🛒 Shop & Items",
                description="Shopping, inventory & marriage system",
                emoji="🛒",
                value="shop"
            ),
            discord.SelectOption(
                label="🦁 Zoo System",
                description="Animal hunting, battles & teams",
                emoji="🦁",
                value="zoo"
            ),
            discord.SelectOption(
                label="🤝 Actions",
                description="Interactive roleplay commands with users",
                emoji="🤝",
                value="actions"
            ),
            discord.SelectOption(
                label="😊 Emotes",
                description="Express emotions & feelings",
                emoji="😊",
                value="emotes"
            ),
            discord.SelectOption(
                label="🔧 Utility",
                description="Helpful tools & customization",
                emoji="🔧",
                value="utility"
            )
        ]
        
        super().__init__(
            placeholder="🔍 Choose a category to explore...",
            min_values=1,
            max_values=1,
            options=options
        )

    async def callback(self, interaction: discord.Interaction):
        if interaction.user != self.ctx.author:
            return await interaction.response.send_message(
                "<:icon_cross:1372375094336425986> Only the command user can interact with this menu!", 
                ephemeral=True
            )

        category = self.values[0]
        
        if category == "home":
            embed = self.home_embed
        elif category == "currency":
            embed = self._create_currency_embed()
        elif category == "gambling":
            embed = self._create_gambling_embed()
        elif category == "shop":
            embed = self._create_shop_embed()
        elif category == "zoo":
            embed = self._create_zoo_embed()
        elif category == "actions":
            embed = self._create_actions_embed()
        elif category == "emotes":
            embed = self._create_emotes_embed()
        elif category == "utility":
            embed = self._create_utility_embed()
        else:
            embed = self.home_embed

        await interaction.response.edit_message(embed=embed, view=self.view)

    def _create_currency_embed(self):
        embed = discord.Embed(
            title="💰 Currency Commands",
            description=f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nManage your cowoncy and transactions",
            color=0x000000
        )
        
        embed.add_field(
            name="💳 **Balance & Transactions**",
            value=f"`{self.current_prefix} cash [user]` - Check cowoncy balance\n"
                  f"`{self.current_prefix} give <amount> <user>` - Transfer cowoncy safely\n"
                  f"`{self.current_prefix} cookie [user]` - Give or check cookies",
            inline=False
        )
        
        embed.add_field(
            name="🍀 **Luck System**",
            value=f"`{self.current_prefix} pray [user]` - Gain luck points (5min cooldown)\n"
                  f"`{self.current_prefix} curse <user>` - Steal luck from others (5min cooldown)",
            inline=False
        )
        
        embed.add_field(
            name="ℹ️ **Tips**",
            value="• Luck points improve gambling win rates\n• Cookie giving builds community karma\n• Transfers require confirmation for safety",
            inline=False
        )
        
        embed.set_author(
            name=f"{self.ctx.author.display_name}'s Currency Help",
            icon_url=self.ctx.author.display_avatar.url
        )
        
        embed.set_footer(
            text=f"Use {self.current_prefix} help <command> for detailed info",
            icon_url=self.ctx.bot.user.display_avatar.url
        )
        
        return embed

    def _create_gambling_embed(self):
        embed = discord.Embed(
            title="🎰 Gambling Commands",
            description=f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nTry your luck with casino games!",
            color=0x000000
        )
        
        embed.add_field(
            name="🎲 **Casino Games**",
            value=f"`{self.current_prefix} slots <amount>` - Spin the slot machine\n"
                  f"`{self.current_prefix} coinflip <amount> [choice]` - Heads or tails betting\n"
                  f"`{self.current_prefix} blackjack <amount>` - Play 21 against the dealer",
            inline=False
        )
        
        embed.add_field(
            name="💎 **Payout Information**",
            value="**Slots:** Cherry x10, Grape x8, Apple x7, Lemon x6, Orange x5, Kiwi x4\n"
                  "**Coinflip:** 2x payout on correct guess\n"
                  "**Blackjack:** 1.5x for natural 21, 1x for regular wins",
            inline=False
        )
        
        embed.add_field(
            name="🍀 **Luck Bonuses**",
            value="• Higher luck = better win chances\n• Use `pray` to build luck points\n• Maximum bet: 250,000 cowoncy",
            inline=False
        )
        
        embed.set_author(
            name=f"{self.ctx.author.display_name}'s Gambling Help",
            icon_url=self.ctx.author.display_avatar.url
        )
        
        embed.set_footer(
            text=f"Aliases: s=slots, cf=coinflip, bj=blackjack",
            icon_url=self.ctx.bot.user.display_avatar.url
        )
        
        return embed

    def _create_shop_embed(self):
        embed = discord.Embed(
            title="🛒 Shop & Items",
            description=f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nShopping, inventory and relationships",
            color=0x000000
        )
        
        embed.add_field(
            name="💍 **Ring Shop**",
            value=f"`{self.current_prefix} shop` - View available rings\n"
                  f"`{self.current_prefix} buy <id>` - Purchase a ring\n"
                  f"`{self.current_prefix} sell <id>` - Sell ring for 75% price",
            inline=False
        )
        
        embed.add_field(
            name="💖 **Marriage System**",
            value=f"`{self.current_prefix} marry <user> <ring_id>` - Propose with a ring\n"
                  f"`{self.current_prefix} inventory [user]` - View items & collection",
            inline=False
        )
        
        embed.add_field(
            name="💎 **Ring Tiers**",
            value="1️⃣ Common (10) • 2️⃣ Uncommon (100) • 3️⃣ Rare (1K)\n4️⃣ Epic (10K) • 5️⃣ Mythical (100K) • 6️⃣ Legendary (1M) • 7️⃣ Fabled (10M)",
            inline=False
        )
        
        embed.set_author(
            name=f"{self.ctx.author.display_name}'s Shop Help",
            icon_url=self.ctx.author.display_avatar.url
        )
        
        embed.set_footer(
            text=f"Higher tier rings show greater commitment!",
            icon_url=self.ctx.bot.user.display_avatar.url
        )
        
        return embed

    def _create_zoo_embed(self):
        embed = discord.Embed(
            title="🦁 Zoo System",
            description=f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nCollect animals and battle other zoos!",
            color=0x000000
        )
        
        embed.add_field(
            name="🌿 **Animal Collection**",
            value=f"`{self.current_prefix} hunt` - Hunt for animals (12s cooldown)\n"
                  f"`{self.current_prefix} zoo [user]` - View zoo collection\n"
                  f"`{self.current_prefix} sell <animal|all>` - Sell animals for cowoncy",
            inline=False
        )
        
        embed.add_field(
            name="⚔️ **Battle System**",
            value=f"`{self.current_prefix} team add <animal>` - Add animal to battle team\n"
                  f"`{self.current_prefix} team view` - View your current team\n"
                  f"`{self.current_prefix} battle <user>` - Challenge another zoo",
            inline=False
        )
        
        embed.add_field(
            name="🏆 **Rarity System**",
            value="🟢 Common (60%) • 🔵 Uncommon (25%) • 🟣 Rare (10%)\n🟠 Epic (4%) • 🔴 Mythic (1%)",
            inline=False
        )
        
        embed.set_author(
            name=f"{self.ctx.author.display_name}'s Zoo Help",
            icon_url=self.ctx.author.display_avatar.url
        )
        
        embed.set_footer(
            text=f"Aliases: h=hunt, b=battle | Max team size: 3 animals",
            icon_url=self.ctx.bot.user.display_avatar.url
        )
        
        return embed

    def _create_actions_embed(self):
        embed = discord.Embed(
            title="🤝 Actions",
            description=f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nInteractive roleplay commands with other users",
            color=0x000000
        )
        
        embed.add_field(
            name="💕 **Affectionate Actions**",
            value=f"`{self.current_prefix} hug [user]` - Give warm hugs\n"
                  f"`{self.current_prefix} kiss [user]` - Sweet kisses\n"
                  f"`{self.current_prefix} cuddle [user]` - Cozy cuddles\n"
                  f"`{self.current_prefix} snuggle [user]` - Warm snuggles\n"
                  f"`{self.current_prefix} hold [user]` - Hold someone close",
            inline=False
        )
        
        embed.add_field(
            name="🎯 **Playful Actions**",
            value=f"`{self.current_prefix} pat [user]` - Gentle head pats\n"
                  f"`{self.current_prefix} poke [user]` - Playful pokes\n"
                  f"`{self.current_prefix} tickle [user]` - Tickle fights\n"
                  f"`{self.current_prefix} boop [user]` - Nose boops\n"
                  f"`{self.current_prefix} highfive [user]` - Celebrate together",
            inline=False
        )
        
        embed.add_field(
            name="⚡ **Dynamic Actions**",
            value=f"`{self.current_prefix} slap [user]` - Playful slaps\n"
                  f"`{self.current_prefix} punch [user]` - Friendly punches\n"
                  f"`{self.current_prefix} bite [user]` - Playful bites\n"
                  f"`{self.current_prefix} stare [user]` - Intense staring\n"
                  f"`{self.current_prefix} wave [user]` - Friendly waves",
            inline=False
        )
        
        embed.set_author(
            name=f"{self.ctx.author.display_name}'s Actions Help",
            icon_url=self.ctx.author.display_avatar.url
        )
        
        embed.set_footer(
            text=f"All actions include animated GIFs! Use without @user for solo actions.",
            icon_url=self.ctx.bot.user.display_avatar.url
        )
        
        return embed

    def _create_emotes_embed(self):
        embed = discord.Embed(
            title="😊 Emotes",
            description=f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nExpress your emotions and feelings",
            color=0x000000
        )
        
        embed.add_field(
            name="😄 **Happy Emotions**",
            value=f"`{self.current_prefix} smile` - Bright smiles\n"
                  f"`{self.current_prefix} grin` - Wide grins\n"
                  f"`{self.current_prefix} happy` - Pure happiness\n"
                  f"`{self.current_prefix} dance` - Joyful dancing\n"
                  f"`{self.current_prefix} thumbsup` - Show approval",
            inline=False
        )
        
        embed.add_field(
            name="😳 **Shy Emotions**",
            value=f"`{self.current_prefix} blush` - Adorable blushing\n"
                  f"`{self.current_prefix} pout` - Cute pouting\n"
                  f"`{self.current_prefix} teehee` - Cute giggles\n"
                  f"`{self.current_prefix} deredere` - Lovey-dovey mood\n"
                  f"`{self.current_prefix} sleepy` - Feeling drowsy",
            inline=False
        )
        
        embed.add_field(
            name="🤔 **Thinking Emotions**",
            value=f"`{self.current_prefix} thinking` - Deep thoughts\n"
                  f"`{self.current_prefix} thonking` - Really hard thinking\n"
                  f"`{self.current_prefix} shrug` - Casual shrugging\n"
                  f"`{self.current_prefix} smug` - Smug expressions\n"
                  f"`{self.current_prefix} triggered` - Feeling triggered",
            inline=False
        )
        
        embed.set_author(
            name=f"{self.ctx.author.display_name}'s Emotes Help",
            icon_url=self.ctx.author.display_avatar.url
        )
        
        embed.set_footer(
            text=f"Express yourself with animated reactions!",
            icon_url=self.ctx.bot.user.display_avatar.url
        )
        
        return embed

    def _create_utility_embed(self):
        embed = discord.Embed(
            title="🔧 Utility",
            description=f"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\nHelpful tools and customization options",
            color=0x000000
        )
        
        embed.add_field(
            name="🖼️ **Visual Tools**",
            value=f"`{self.current_prefix} avatar [user]` - High-quality avatar display\n"
                  f"`{self.current_prefix} emoji <emoji>` - Enlarge emojis with info",
            inline=False
        )
        
        embed.add_field(
            name="✨ **Text Tools**",
            value=f"`{self.current_prefix} sysify <text>` - Transform text to cute SyS style",
            inline=False
        )
        
        embed.add_field(
            name="⚙️ **Configuration**",
            value=f"`{self.current_prefix} prefix <new_prefix>` - Change economy prefix (Admin only)",
            inline=False
        )
        
        embed.add_field(
            name="💡 **Features**",
            value="• Avatar tools support PNG, JPG, WEBP formats\n• Emoji tool works with custom and Unicode emojis\n• SyS style uses AI for cute transformations\n• Prefix changes apply server-wide",
            inline=False
        )
        
        embed.set_author(
            name=f"{self.ctx.author.display_name}'s Utility Help",
            icon_url=self.ctx.author.display_avatar.url
        )
        
        embed.set_footer(
            text=f"Aliases: av=avatar | All tools include download links where applicable",
            icon_url=self.ctx.bot.user.display_avatar.url
        )
        
        return embed





async def setup(bot):
    await bot.add_cog(Economy(bot))
"""
@Author: ! Aegis !
    + Discord: Aegis
    + Community: https://discord.gg/35FqchfVZG (Strelix Studios™)
    + for any queries reach out Community or DM me.
"""
