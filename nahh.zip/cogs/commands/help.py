# START OF FILE
import discord
from discord.ext import commands
from discord import app_commands
from core.Strelizia import Strelizia
from core.Cog import Cog
from utils.Tools import getConfig
from utils import help as vhelp
from utils import Paginator, FieldPagePaginator
import asyncio

# Placeholder decorators — replace with your real logic
def ignore_check():
    class Dummy:
        async def predicate(self, ctx): return True
    return Dummy()

def blacklist_check():
    class Dummy:
        async def predicate(self, ctx): return True
    return Dummy()

color = 0x000000

class HelpCommand(commands.HelpCommand):

    async def send_ignore_message(self, ctx, ignore_type: str):
        messages = {
            "channel": "This channel is ignored.",
            "command": f"{ctx.author.mention} This Command, Channel, or You have been ignored here.",
            "user": "You are ignored."
        }
        await ctx.reply(messages.get(ignore_type, "Ignored."), mention_author=False)

    async def on_help_command_error(self, ctx, error):
        if isinstance(error, commands.CommandNotFound):
            embed = discord.Embed(
                color=color,
                description=f"No command or category named `{ctx.invoked_with}` found."
            )
            embed.set_author(name="Command Not Found", icon_url=ctx.bot.user.avatar.url)
            embed.set_footer(text=f"Use {ctx.prefix}help to see all commands")
            await ctx.reply(embed=embed, delete_after=10)
        else:
            await ctx.reply("An error occurred while processing the help command.", delete_after=10)

    async def command_not_found(self, string: str) -> str:
        return f"No command called `{string}` found."

    async def send_bot_help(self, mapping):
        ctx = self.context
        if not await blacklist_check().predicate(ctx): return
        if not await ignore_check().predicate(ctx):
            await self.send_ignore_message(ctx, "command")
            return

        embed = discord.Embed(description="⌛ **Loading Help menu...**", color=color)
        ok = await ctx.reply(embed=embed)
        data = await getConfig(ctx.guild.id)
        prefix = data["prefix"]

        embed = discord.Embed(
            title="📁 Zyron-bot Command Suite",
            description="━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━",
            color=color
        )
        embed.add_field(name="⚙️ System Info", value=f"⚫ Commands: ``157``\nModules: ``104``\nPrefix: ``{prefix}``")
        embed.add_field(name="❔ How To Use", value=f"```Use {prefix}help <category> or {prefix}help <command>\nExample: {prefix}help automod```")
        embed.add_field(name="🌐 Website", value="[Zyron web](https://zyron.dpdns.org)")
        embed.add_field(name="🏠 __**General Features**__", value=">>> 🔉 Voice\n🎮 Games\n🚀 Welcomer\n🎫 Ticketing\n✏️ Auto Setup\n🗨️ Autorole\n🧩 Fun\n❌ Ignore Channels\n📔 Logging\n⏲️ Counting\n⏫ Leveling\n🖲️ Tracking\n📺 Roleplay\n👨 Staff Application")
        embed.add_field(name="🪐 __**Bot Features**__", value=">>> 🔐 Security\n🤖 Automod\n🔧 Utility\n🎧 Music\n🛠️ Moderation\n📁 General\n🎉 Giveaway\n👾 AI\n🗄️ Backup")
        embed.add_field(name="🔗 Useful Links", value="[Support Server](https://discord.gg/2Q9FqYubSf)\n[Add Me](https://discord.com/oauth2/authorize?client_id=1387495824195321938)")
        embed.set_footer(text=f"Requested By {ctx.author}")
        embed.set_thumbnail(url=ctx.author.avatar.url)

        view = vhelp.View(mapping=mapping, ctx=ctx, homeembed=embed, ui=2)
        await asyncio.sleep(0.1)
        await ok.edit(embed=embed, view=view)

    async def send_command_help(self, command):
        ctx = self.context
        if not await blacklist_check().predicate(ctx): return
        if not await ignore_check().predicate(ctx):
            await self.send_ignore_message(ctx, "command")
            return

        description = command.description or command.help or 'No Help Provided...'
        embed = discord.Embed(
            description=f"""```xml
<[] = optional | ‹› = required
Don't type these while using Commands>```\n>>> {description}""",
            color=color
        )
        alias = ' | '.join(command.aliases) if command.aliases else "No Aliases"
        embed.add_field(name="**Aliases**", value=alias, inline=False)
        embed.add_field(name="**Usage**", value=f"`{ctx.prefix}{command.signature}`")
        embed.set_author(name=f"{command.qualified_name.title()} Command", icon_url=ctx.bot.user.display_avatar.url)
        await ctx.reply(embed=embed, mention_author=False)

    def get_command_signature(self, command: commands.Command) -> str:
        alias = f"[{command.name} | {' | '.join(command.aliases)}]" if command.aliases else command.name
        return f"{alias} {command.signature}"

    async def send_group_help(self, group):
        ctx = self.context
        if not await blacklist_check().predicate(ctx): return
        if not await ignore_check().predicate(ctx):
            await self.send_ignore_message(ctx, "command")
            return

        entries = [(f"➜ `{ctx.prefix}{cmd.qualified_name}`", f"{cmd.description or cmd.short_doc or 'No description provided...'}\n\u200b") for cmd in group.commands]
        paginator = Paginator(
            source=FieldPagePaginator(
                entries=entries,
                title=f"{group.qualified_name.title()} [{len(group.commands)}]",
                description="< > Duty | [ ] Optional\n",
                color=color,
                per_page=4
            ),
            ctx=ctx
        )
        await paginator.paginate()

    async def send_cog_help(self, cog):
        ctx = self.context
        if not await blacklist_check().predicate(ctx): return
        if not await ignore_check().predicate(ctx):
            await self.send_ignore_message(ctx, "command")
            return

        entries = [(f"➜ `{ctx.prefix}{cmd.qualified_name}`", f"{cmd.description or cmd.short_doc or 'No description provided...'}\n\u200b") for cmd in cog.get_commands()]
        paginator = Paginator(
            source=FieldPagePaginator(
                entries=entries,
                title=f"{cog.qualified_name.title()} ({len(cog.get_commands())})",
                description="< > Duty | [ ] Optional\n\n",
                color=color,
                per_page=4
            ),
            ctx=ctx
        )
        await paginator.paginate()


class Help(Cog, name="help"):

    def __init__(self, client: Strelizia):
        self.bot = client
        self._original_help_command = client.help_command
        attributes = {
            'name': "help",
            'aliases': ['h'],
            'cooldown': commands.CooldownMapping.from_cooldown(1, 5, commands.BucketType.user),
            'help': 'Shows help about bot, a command or a category'
        }
        client.help_command = HelpCommand(command_attrs=attributes)
        client.help_command.cog = self

    async def cog_unload(self):
        self.help_command = self._original_help_command
# END OF FILE
