

import discord
from discord.ext import commands

class eco(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    """"""
  
    def help_custom(self):
        emoji = '<:economy:1387479173890572323>'
        label = "Economy Commands (sys)"
        description = ""
        return emoji, label, description

    @commands.group()
    async def __Economy__(self, ctx: commands.Context):
        """`sys` , `sys help` , `sys cash` , `sys cowoncy` , `sys give` , `sys work` , `sys beg` , `sys daily` , `sys trivia` , `sys lottery` , `sys slots` , `sys s` , `sys coinflip` , `sys cf` , `sys blackjack` , `sys bj` , `sys shop` , `sys buy` , `sys sell` , `sys marry` , `sys inventory` , `sys inv` , `sys baltop` , `sys leaderboard` , `sys rich` , `sys bank` , `sys pray` , `sys curse` , `sys cookie` , `sys job` , `sys stocks` , `sys stock` , `sys crypto` , `sys cryptocurrency` , `sys emoji` , `sys sysify` , `sys avatar` , `sys av` , `sys zoo` , `sys hunt` , `sys prefix` , `sys taxstats`"""

async def setup(client):
    await client.add_cog(eco(client))

"""
@Author: ! Aegis !
    + Discord: Aegis
    + Community: https://discord.gg/35FqchfVZG (Strelix Studios™)
    + for any queries reach out Community or DM me.
"""
