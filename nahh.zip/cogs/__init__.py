from __future__ import annotations
from core import Strelizia
from colorama import Fore, Style, init
import asyncio
import traceback

# Initialize colorama
init(autoreset=True)

#----------Commands---------#
from .commands.help import Help
from .commands.helpslash import HelpSlash
from .commands.general import General
from .commands.tracking import TrackingCog
from .commands.unblacklist import Unblacklist
from .commands.counting import Counting
from .commands.music import Music
from .commands.automod import Automod
from .commands.welcome import Welcomer
from .commands.leveling import Leveling
from .commands.fun import Fun
from .commands.economy import Economy
from .commands.Games import Games
from .commands.extra import Extra
from .commands.owner import Owner
from .commands.voice import Voice
from .commands.afk import afk
from .commands.ignore import Ignore
from .commands.discordlogging import Logging
from .commands.Media import Media
from .commands.Invc import Invcrole
from .commands.giveaway import Giveaway
from .commands.Embed import Embed
from .commands.steal import Steal
from .commands.ticket import AdvancedTicketSystem
from .commands.timer import Timer
from .commands.staff import Staff
from .commands.verification import Verification  # Re-added - needed for cog loading
from .commands.roleplay import Roleplay
from .commands.blacklist import Blacklist
from .commands.block import Block
from .commands.nightmode import Nightmode
from .commands.ai import AI  # Updated import: chatbot to ai, Chatbot to AI
from .commands.owner import Badges
from .commands.autoresponder import AutoResponder
from .commands.customrole import Customrole
from .commands.autorole import AutoRole
from .commands.antinuke import Antinuke
from .commands.extraown import Extraowner
from .commands.anti_wl import Whitelist
from .commands.anti_unwl import Unwhitelist
from .commands.slots import Slots
from .commands.blackjack import Blackjack
from .commands.autoreact import AutoReaction
from .commands.stats import Stats
from .commands.emergency import Emergency
from .commands.notify import NotifCommands
from .commands.status import Status
from .commands.np import NoPrefix
from .commands.filters import FilterCog
from .commands.owner2 import Global
from .commands.backup_final import Backup
# Add this to your command imports
# from .commands.activity import Activity

#____________ Events _____________
from .events.autoblacklist import AutoBlacklist
from .events.Errors import Errors
from .events.on_guild import Guild
from .events.autorole import Autorole2
from .events.auto import Autorole
from .events.greet2 import greet
from .events.mention import Mention
from .events.ai import AIResponses
from .events.react import React
from .events.autoreact import AutoReactListener
# from .events.topgg import TopGG

########-------HELP-------########
from .strelizia.antinuke import _antinuke
from .strelizia.counting import _counting
from .strelizia.logging import _logging
from .strelizia.extra import _extra
from .strelizia.general import _general
from .strelizia.automod import _automod 
from .strelizia.moderation import _moderation
from .strelizia.music import _music
from .strelizia.fun import _fun
from .strelizia.games import _games
from .strelizia.ignore import _ignore
from .strelizia.tracking import _tracking
from .strelizia.leveling import _leveling
from .strelizia.server import _server
from .strelizia.voice import _voice 
from .strelizia.crew import _crew
from .strelizia.welcome import _welcome 
from .strelizia.giveaway import _giveaway
from .strelizia.ai import _ai  # Already correctly set for AI cog
from .strelizia.backup import _Backup
from .strelizia.verification import VerificationHelp
from .strelizia.roleplay import RoleplayHelp
from .strelizia.ticket import ticket
from .commands.staff import Staff as staff
from .strelizia.eco import eco
#########ANTINUKE#########
from .antinuke.anti_member_update import AntiMemberUpdate
from .antinuke.antiban import AntiBan
from .antinuke.antibotadd import AntiBotAdd
from .antinuke.antichcr import AntiChannelCreate
from .antinuke.antichdl import AntiChannelDelete
from .antinuke.antichup import AntiChannelUpdate
from .antinuke.antieveryone import AntiEveryone
from .antinuke.antiguild import AntiGuildUpdate
from .antinuke.antiIntegration import AntiIntegration
from .antinuke.antikick import AntiKick
from .antinuke.antiprune import AntiPrune
from .antinuke.antirlcr import AntiRoleCreate
from .antinuke.antirldl import AntiRoleDelete
from .antinuke.antirlup import AntiRoleUpdate
from .antinuke.antiwebhook import AntiWebhookUpdate
from .antinuke.antiwebhookcr import AntiWebhookCreate
from .antinuke.antiwebhookdl import AntiWebhookDelete

#Extra Optional Events 
# from .antinuke.antiemocr import AntiEmojiCreate
# from .antinuke.antiemodl import AntiEmojiDelete
# from .antinuke.antiemoup import AntiEmojiUpdate
# from .antinuke.antisticker import AntiSticker
# from .antinuke.antiunban import AntiUnban

############ AUTOMOD ############
from .automod.antispam import AntiSpam
from .automod.anticaps import AntiCaps
from .automod.antilink import AntiLink
from .automod.anti_invites import AntiInvite
from .automod.anti_mass_mention import AntiMassMention
from .automod.anti_emoji_spam import AntiEmojiSpam

from .moderation.ban import Ban
from .moderation.unban import Unban
from .moderation.timeout import Mute
from .moderation.unmute import Unmute
from .moderation.lock import Lock
from .moderation.unlock import Unlock
from .moderation.hide import Hide
from .moderation.unhide import Unhide
from .moderation.kick import Kick
from .moderation.warn import Warn
from .moderation.role import Role
from .moderation.message import Message
from .moderation.moderation import Moderation
from .moderation.topcheck import TopCheck
from .moderation.snipe import Snipe
from .moderation.channeldelete import ChannelDelete

async def setup(bot: Strelizia):
    # Load all cogs with error handling
    cogs_to_load = [
        (Help, "Help"),
        (HelpSlash, "HelpSlash"),
        (Leveling, "Leveling"),
        (TrackingCog, "TrackingCog"),
        (Counting, "Counting"),
        (Unblacklist, "Unblacklist"),
        (General, "General"),
        (Music, "Music"),
        (Automod, "Automod"),
        (Backup, "Backup"),
        (Economy, "Economy"),
        (Welcomer, "Welcomer"),
        (Fun, "Fun"),
        (Games, "Games"),
        (Logging, "Logging"),
        (Extra, "Extra"),
        (Voice, "Voice"),
        (Owner, "Owner"),
        (Customrole, "Customrole"),
        (afk, "afk"),
        (Embed, "Embed"),
        (Media, "Media"),
        (Ignore, "Ignore"),
        (Invcrole, "Invcrole"),
        (Giveaway, "Giveaway"),
        (Steal, "Steal"),
        (AdvancedTicketSystem, "AdvancedTicketSystem"),  # Updated: Ship to ShipCog
        (Timer, "Timer"),
        (Staff, "Staff"),
        (Verification, "Verification"),
        (Roleplay, "Roleplay"),
        (Blacklist, "Blacklist"),
        (Block, "Block"),
        (Nightmode, "Nightmode"),
        (AI, "AI"),
        (Badges, "Badges"),
        (Antinuke, "Antinuke"),
        (Whitelist, "Whitelist"),
        (Unwhitelist, "Unwhitelist"),
        (Extraowner, "Extraowner"),
        (Slots, "Slots"),
        (Blackjack, "Blackjack"),
        (Stats, "Stats"),
        (Emergency, "Emergency"),
        (Status, "Status"),
        (NoPrefix, "NoPrefix"),
        (FilterCog, "FilterCog"),
        (Global, "Global"),
        # (Activity, "Activity"),
        (_antinuke, "_antinuke"),
        (_extra, "_extra"),
        (_general, "_general"),
        (_automod, "_automod"),
        (_logging, "_logging"),
        (_moderation, "_moderation"),
        (_leveling, "_leveling"),
        (_tracking, "_tracking"),
        (_music, "_music"),
        (_fun, "_fun"),
        (_games, "_games"),
        (_ignore, "_ignore"),
        (_server, "_server"),
        (_voice, "_voice"),
        (_crew, "_crew"),
        (_welcome, "_welcome"),
        (_giveaway, "_giveaway"),
        (_ai, "_ai"),
        (_counting, "_counting"),
        (_Backup, "_Backup"),
        (VerificationHelp, "VerificationHelp"),
        (RoleplayHelp, "RoleplayHelp"),
        (eco, "eco"),
        (AutoBlacklist, "AutoBlacklist"),
        (Guild, "Guild"),
        (Errors, "Errors"),
        (Autorole2, "Autorole2"),
        (Autorole, "Autorole"),
        (greet, "greet"),
        (AutoResponder, "AutoResponder"),
        (Mention, "Mention"),
        (AutoRole, "AutoRole"),
        (React, "React"),
        (AutoReaction, "AutoReaction"),
        (AutoReactListener, "AutoReactListener"),
        (NotifCommands, "NotifCommands"),
        (AntiMemberUpdate, "AntiMemberUpdate"),
        (AntiBan, "AntiBan"),
        (AntiBotAdd, "AntiBotAdd"),
        (AntiChannelCreate, "AntiChannelCreate"),
        (AntiChannelDelete, "AntiChannelDelete"),
        (AntiChannelUpdate, "AntiChannelUpdate"),
        (AntiEveryone, "AntiEveryone"),
        (AntiGuildUpdate, "AntiGuildUpdate"),
        (AntiIntegration, "AntiIntegration"),
        (AntiKick, "AntiKick"),
        (AntiPrune, "AntiPrune"),
        (AntiRoleCreate, "AntiRoleCreate"),
        (AntiRoleDelete, "AntiRoleDelete"),
        (AntiRoleUpdate, "AntiRoleUpdate"),
        (AntiWebhookUpdate, "AntiWebhookUpdate"),
        (AntiWebhookCreate, "AntiWebhookCreate"),
        (AntiWebhookDelete, "AntiWebhookDelete"),
        (AntiSpam, "AntiSpam"),
        (AntiCaps, "AntiCaps"),
        (AntiLink, "AntiLink"),
        (AntiInvite, "AntiInvite"),
        (AntiMassMention, "AntiMassMention"),
        (AntiEmojiSpam, "AntiEmojiSpam"),
        (Ban, "Ban"),
        (Unban, "Unban"),
        (Mute, "Mute"),
        (Unmute, "Unmute"),
        (Lock, "Lock"),
        (Unlock, "Unlock"),
        (Hide, "Hide"),
        (Unhide, "Unhide"),
        (Kick, "Kick"),
        (Warn, "Warn"),
        (Role, "Role"),
        (Message, "Message"),
        (Moderation, "Moderation"),
        (TopCheck, "TopCheck"),
        (Snipe, "Snipe"),
        (ChannelDelete, "ChannelDelete"),
    ]

    failed_cogs = []
    loaded_cogs = 0
    
    for cog_class, cog_name in cogs_to_load:
        try:
            await bot.add_cog(cog_class(bot))
            loaded_cogs += 1
        except Exception as e:
            failed_cogs.append(cog_name)
            print(f"{Fore.RED}✗ Failed to load cog {cog_name}: {str(e)}{Style.RESET_ALL}")
            # Only print full traceback for critical errors
            if "database" in str(e).lower() or "import" in str(e).lower():
                traceback.print_exc()

    # Only show summary
    if failed_cogs:
        print(f"{Fore.RED}✗ Failed to load {len(failed_cogs)} cogs: {', '.join(failed_cogs)}{Style.RESET_ALL}")
    else:
        print(f"{Fore.GREEN}✓ All {loaded_cogs} cogs loaded successfully{Style.RESET_ALL}")

# This file only handles cog loading for main.py
# Bot startup is handled in main.py
"""
@Author: ! Aegis !
    + Discord: Aegis
    + Community: https://discord.gg/35FqchfVZG (Strelix Studios™)
    + for any queries reach out Community or DM me.
"""
