import discord
from discord.utils import *
from core import Strelizia, Cog
from utils.Tools import getConfig
from utils.config import BotName, serverLink
from discord.ext import commands

class Autorole(Cog):
    def __init__(self, bot: Strelizia):
        self.bot = bot

    @commands.Cog.listener(name="on_guild_join")
    async def send_msg_to_adder(self, guild: discord.Guild):
        data = await getConfig(guild.id)  # Get guild-specific config
        prefix = data.get("prefix", "!")  # Fallback to "!" if not found

        async for entry in guild.audit_logs(limit=3):
            if entry.action == discord.AuditLogAction.bot_add:
                embed = discord.Embed(
                    description=(
                        f"<:icons_saturn:1372375229753593967> **Thanks for adding {BotName}!**\n\n"
                        f"<a:GC_z_icon_rightarrow:1374279174751125534> My default prefix is `{prefix}`\n"
                        f"<a:GC_z_icon_rightarrow:1374279174751125534> Use `{prefix}help` to see a list of commands\n"
                        f"<a:GC_z_icon_rightarrow:1374279174751125534> For detailed guides, FAQ, and information, visit our "
                        f"links below:\n"
                        f"🔗 [Invite Me](https://discord.com/oauth2/authorize?client_id=1387495824195321938) "
                        f"| [Visit Website](https://landing.zyron.fun) "
                        f"| [Support Server](https://discord.gg/2Q9FqYubSf)"
                    ),
                    color=0x0d0d0e
                )

                avatar_url = entry.user.avatar.url if entry.user.avatar else entry.user.default_avatar.url
                embed.set_thumbnail(url=avatar_url)

                if guild.icon:
                    embed.set_author(name=guild.name, icon_url=guild.icon.url)
                else:
                    embed.set_author(name=guild.name)

                try:
                    await entry.user.send(embed=embed)
                except Exception as e:
                    print(f"Failed to send welcome message: {e}")
"""
@Author: ! Aegis !
    + Discord: Aegis
    + Community: https://discord.gg/35FqchfVZG (Strelix Studios™)
    + for any queries reach out Community or DM me.
"""
