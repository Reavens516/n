import os
import asyncio
import traceback
from threading import Thread
from datetime import datetime, timezone, timedelta
import aiohttp
import discord
from discord.ext import commands
from core import Context
from core.Strelizia import Strelizia
from utils.Tools import *
from utils.config import *
import jishaku
import cogs
from status import StatusCog
import status
# Load ReactionRole cog
async def load_reactionrole():
    await bot.add_cog(cogs.ReactionRole(bot))
import aiosqlite
import logging
from dotenv import load_dotenv

# Enhanced ANSI Color codes for Strelizia's elegant console output
class Colors:
    # Main colors
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    PINK = '\033[38;5;213m'
    LAVENDER = '\033[38;5;183m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    WHITE = '\033[97m'
    GRAY = '\033[90m'
    DARK_GRAY = '\033[38;5;240m'
    
    # Special effects
    BOLD = '\033[1m'
    DIM = '\033[2m'
    UNDERLINE = '\033[4m'
    RESET = '\033[0m'
    
    # Strelizia signature colors
    STRELIZIA_PINK = '\033[38;5;219m'
    STRELIZIA_PURPLE = '\033[38;5;141m'
    STRELIZIA_BLUE = '\033[38;5;111m'

def print_strelizia_header():
    """Print Strelizia's elegant startup header"""
    print(f"\n{Colors.STRELIZIA_PINK}╭─────────────────────────────────────────────────────────────╮{Colors.RESET}")
    print(f"{Colors.STRELIZIA_PINK}│{Colors.RESET}                    {Colors.BOLD}{Colors.STRELIZIA_PURPLE}✦ STRELIZIA ✦{Colors.RESET}                     {Colors.STRELIZIA_PINK}│{Colors.RESET}")
    print(f"{Colors.STRELIZIA_PINK}│{Colors.RESET}            {Colors.DIM}{Colors.WHITE}Elegant • Intelligent • Sophisticated{Colors.RESET}           {Colors.STRELIZIA_PINK}│{Colors.RESET}")
    print(f"{Colors.STRELIZIA_PINK}╰─────────────────────────────────────────────────────────────╯{Colors.RESET}\n")

def print_bot_ready(bot_name):
    print(f"\n{Colors.STRELIZIA_BLUE}◆{Colors.RESET} {Colors.BOLD}{Colors.GREEN}Authentication successful{Colors.RESET} {Colors.DIM}→{Colors.RESET} {Colors.STRELIZIA_PURPLE}{bot_name}{Colors.RESET}")

def print_error(message):
    print(f"{Colors.RED}✗{Colors.RESET} {Colors.BOLD}Error:{Colors.RESET} {message}")

def print_loading(message):
    print(f"{Colors.STRELIZIA_BLUE}◆{Colors.RESET} {Colors.DIM}Loading{Colors.RESET} {Colors.WHITE}{message}{Colors.RESET}{Colors.DIM}...{Colors.RESET}")

def print_success(message):
    print(f"{Colors.GREEN}✓{Colors.RESET} {Colors.WHITE}{message}{Colors.RESET}")

def print_info(message):
    print(f"{Colors.STRELIZIA_PURPLE}ⓘ{Colors.RESET} {Colors.WHITE}{message}{Colors.RESET}")

def print_elegant_separator():
    """Print Strelizia's signature separator"""
    separator = f"{Colors.STRELIZIA_PINK}─{Colors.STRELIZIA_PURPLE}─{Colors.STRELIZIA_BLUE}─{Colors.RESET}"
    print(f"   {separator * 20}")

def print_system_ready():
    """Print the final system ready message"""
    print_elegant_separator()
    print(f"\n   {Colors.BOLD}{Colors.STRELIZIA_PURPLE}✦ System Operational ✦{Colors.RESET}")
    print(f"   {Colors.DIM}{Colors.WHITE}Developed with {Colors.STRELIZIA_PINK}♡{Colors.WHITE} by Strelix Studios™{Colors.RESET}")
    print(f"   {Colors.DIM}{Colors.DARK_GRAY}Ready to serve with elegance and precision{Colors.RESET}\n")
    print_elegant_separator()
    print()

def print_status(status, message, color=Colors.WHITE):
    print(f"{color}[{status}]{Colors.RESET} {message}")

# Ticket system is now handled by the advanced ticket system in cogs/commands/ticket.py

# Load environment variables from .env file
load_dotenv()

# Configure logging to show only critical errors
logging.basicConfig(
    level=logging.CRITICAL,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler()
    ]
)

# Set discord.py loggers to CRITICAL level to reduce noise
logging.getLogger('discord').setLevel(logging.CRITICAL)
logging.getLogger('discord.http').setLevel(logging.CRITICAL)
logging.getLogger('discord.gateway').setLevel(logging.CRITICAL)
logging.getLogger('discord.client').setLevel(logging.CRITICAL)
logging.getLogger('wavelink').setLevel(logging.CRITICAL)
logging.getLogger('wavelink.websocket').setLevel(logging.CRITICAL)

# Custom filter to block specific unwanted messages
class DatabaseTestFilter(logging.Filter):
    def filter(self, record):
        message = record.getMessage().lower()
        # Block database connection test messages
        if 'database connection test successful' in message:
            return False
        return True

# Apply the filter to all discord loggers
for logger_name in ['discord', 'discord.http', 'discord.gateway', 'discord.client']:
    logger = logging.getLogger(logger_name)
    logger.addFilter(DatabaseTestFilter())
    for handler in logger.handlers:
        handler.addFilter(DatabaseTestFilter())

# Also apply to root logger to catch any remaining messages
logging.getLogger().addFilter(DatabaseTestFilter())

# Create logger for bot
logger = logging.getLogger('bot')
logger.setLevel(logging.CRITICAL)

os.environ["JISHAKU_NO_DM_TRACEBACK"] = "False"
os.environ["JISHAKU_HIDE"] = "True"
os.environ["JISHAKU_NO_UNDERSCORE"] = "True"
os.environ["JISHAKU_FORCE_PAGINATOR"] = "True"

# Helper function to convert UTC to IST
def utc_to_ist(dt):
    ist_offset = timedelta(hours=5, minutes=30)
    return dt.replace(tzinfo=timezone.utc).astimezone(timezone(ist_offset))

class TicketBot(Strelizia):
    def __init__(self):
        super().__init__()
        self.db = None

    async def setup_hook(self):
        print_strelizia_header()
        print_loading("Initializing database connection")
        try:
            self.db = await aiosqlite.connect("bot_database.db")
            if self.db is None:
                raise Exception("Failed to connect to database")
            
            print_success("Database connection established")

            # Create tickets table with all necessary columns for ship.py
            await self.db.execute("""
                CREATE TABLE IF NOT EXISTS tickets (
                    guild_id INTEGER PRIMARY KEY,
                    channel_id INTEGER,
                    role_id INTEGER,
                    category_id INTEGER,
                    log_channel_id INTEGER,
                    ping_role_id INTEGER,
                    embed_title TEXT DEFAULT 'Create a Ticket',
                    embed_description TEXT DEFAULT 'Need assistance? Select a category below to create a ticket, and our support team will assist you shortly! 📩',
                    embed_footer TEXT DEFAULT 'Powered by Strelix Studios™',
                    embed_image_url TEXT,
                    embed_color INTEGER DEFAULT 16711680,
                    panel_type TEXT DEFAULT 'dropdown'
                )
            """)

            # Schema migration for tickets table
            async with self.db.cursor() as cur:
                await cur.execute("PRAGMA table_info(tickets)")
                columns = [col[1] for col in await cur.fetchall()]
                if "panel_type" not in columns:
                    await cur.execute("ALTER TABLE tickets ADD COLUMN panel_type TEXT DEFAULT 'dropdown'")
                if "ping_role_id" not in columns:
                    await cur.execute("ALTER TABLE tickets ADD COLUMN ping_role_id INTEGER")
                if "embed_color" in columns:
                    await cur.execute("PRAGMA table_info(tickets)")
                    col_info = [col for col in await cur.fetchall() if col[1] == "embed_color"]
                    if col_info and col_info[0][2] == "TEXT":
                        await cur.execute("ALTER TABLE tickets RENAME TO old_tickets")
                        await self.db.execute("""
                            CREATE TABLE tickets (
                                guild_id INTEGER PRIMARY KEY,
                                channel_id INTEGER,
                                role_id INTEGER,
                                category_id INTEGER,
                                log_channel_id INTEGER,
                                ping_role_id INTEGER,
                                embed_title TEXT DEFAULT 'Create a Ticket',
                                embed_description TEXT DEFAULT 'Need assistance? Select a category below to create a ticket, and our support team will assist you shortly! 📩',
                                embed_footer TEXT DEFAULT 'Powered by Strelix Studios™',
                                embed_image_url TEXT,
                                embed_color INTEGER DEFAULT 16711680,
                                panel_type TEXT DEFAULT 'dropdown'
                            )
                        """)
                        await cur.execute("""
                            INSERT INTO tickets (
                                guild_id, channel_id, role_id, category_id, log_channel_id, ping_role_id,
                                embed_title, embed_description, embed_footer, embed_image_url, embed_color, panel_type
                            )
                            SELECT guild_id, channel_id, role_id, category_id, log_channel_id, ping_role_id,
                                   embed_title, embed_description, embed_footer, embed_image_url,
                                   CAST(embed_color AS INTEGER), panel_type
                            FROM old_tickets
                        """)
                        await cur.execute("DROP TABLE old_tickets")
                        await self.db.commit()

            # Create ticket_categories table for ticket category management
            await self.db.execute("""
                CREATE TABLE IF NOT EXISTS ticket_categories (
                    guild_id INTEGER,
                    category_name TEXT,
                    PRIMARY KEY (guild_id, category_name)
                )
            """)

            # Create ticket_panels table for ticket panel message tracking
            await self.db.execute("""
                CREATE TABLE IF NOT EXISTS ticket_panels (
                    guild_id INTEGER,
                    channel_id INTEGER,
                    message_id INTEGER,
                    PRIMARY KEY (guild_id, message_id)
                )
            """)

            # Create blacklist tables if they don't exist
            await self.db.execute("""
                CREATE TABLE IF NOT EXISTS guild_blacklist (
                    guild_id INTEGER PRIMARY KEY,
                    reason TEXT,
                    blacklisted_at TEXT
                )
            """)

            await self.db.execute("""
                CREATE TABLE IF NOT EXISTS user_blacklist (
                    user_id INTEGER PRIMARY KEY,
                    reason TEXT,
                    blacklisted_at TEXT
                )
            """)

            await self.db.commit()
            print_success("Database schema initialized")
        except Exception as e:
            print_error(f"Database setup failed: {str(e)}")
            raise

        print_loading("Loading core modules")
        try:
            await self.load_extension("jishaku")
            print_success("Core utilities loaded")
            await self.load_extension("cogs")
            print_success("Command modules loaded")
            print_info("All modules loaded successfully")
            await self.load_extension("cogs.status")
            
            print_success("Status cog loaded")
        except Exception as e:
            print_error(f"Failed to load extensions: {e}")
            raise

        print_loading("Synchronizing command tree")
        try:
            synced = await self.tree.sync()
            print_success(f"Command synchronization complete ({len(synced)} commands)")
        except Exception as e:
            print_error(f"Failed to sync commands: {e}")
            raise

    async def close(self):
        try:
            # Cancel status rotation task
            if hasattr(self, 'status_rotation'):
                self.status_rotation.cancel()
            
            # Close database connections
            if self.db:
                await self.db.close()
                print_info("Database connection gracefully closed")
                
            # Force close any remaining connections
            import gc
            for obj in gc.get_objects():
                if hasattr(obj, 'close') and 'aiosqlite' in str(type(obj)):
                    try:
                        await obj.close()
                    except:
                        pass
                        
        except Exception as e:
            print_error(f"Failed to close resources: {e}")
        finally:
            await super().close()

client = TicketBot()
tree = client.tree

@client.event
async def on_ready():
    await client.wait_until_ready()
    
    print_bot_ready(client.user.name)
    print_system_ready()

@client.event
async def on_interaction(interaction: discord.Interaction):
    if interaction.type != discord.InteractionType.component:
        return
    try:
        custom_id = interaction.data.get("custom_id")
        if not custom_id:
            print(f"[INTERACTION ERROR] Received interaction without custom_id from user {interaction.user.id}")
            logger.warning("Received interaction without custom_id")
            return

        print(f"[INTERACTION] Processing interaction: {custom_id} from user {interaction.user.id} in guild {interaction.guild.id if interaction.guild else 'DM'}")
        # All ticket interactions are now handled by the advanced ticket system
        # Let Discord.py handle other interactions via registered views
    except Exception as e:
        print(f"[INTERACTION ERROR] Critical error in interaction handler: {str(e)}")
        print(f"[INTERACTION ERROR] User: {interaction.user.id}, Guild: {interaction.guild.id if interaction.guild else 'None'}")
        print(f"[INTERACTION ERROR] Custom ID: {custom_id}")
        print(f"[INTERACTION ERROR] Traceback: {traceback.format_exc()}")
        logger.error(f"Interaction failed: {str(e)}")
        traceback.print_exc()
        try:
            if not interaction.response.is_done():
                await interaction.response.send_message("An error occurred while handling this interaction.", ephemeral=True)
        except Exception as followup_error:
            print(f"[INTERACTION ERROR] Failed to send error message: {followup_error}")

@client.event
async def on_command_completion(context: commands.Context) -> None:
    if context.author.id == 1070619070468214824:
        return

    full_command_name = context.command.qualified_name
    split = full_command_name.split("\n")
    executed_command = str(split[0])
    webhook_url = WEBHOOK_URL
    async with aiohttp.ClientSession() as session:
        webhook = discord.Webhook.from_url(webhook_url, session=session)

        if context.guild is not None:
            try:
                embed = discord.Embed(color=0x000000)
                avatar_url = context.author.avatar.url if context.author.avatar else context.author.default_avatar.url
                embed.set_author(
                    name=f"Executed {executed_command} Command By : {context.author}",
                    icon_url=avatar_url
                )
                embed.add_field(
                    name=" Command Executed By :",
                    value=f"{context.author} | ID: [{context.author.id}](https://discord.com/users/{context.author.id})",
                    inline=False)
                
                embed.add_field(
                    name=" Command Executed In :",
                    value=f"{context.guild.name} | ID: [{context.guild.id}](https://discord.com/guilds/{context.guild.id})",
                    inline=False)
                
                embed.add_field(
                    name=" Command Executed In Channel :",
                    value=f"{context.channel.name} | ID: [{context.channel.id}](https://discord.com/channels/{context.guild.id}/{context.channel.id})",
                    inline=False)
                
                embed.add_field(
                    name=" User :",
                    value=f"{context.author} ({context.author.id})",
                    inline=False
                )
                current_time = utc_to_ist(discord.utils.utcnow())
                embed.timestamp = current_time
                embed.set_footer(text=f"Command Executed at {current_time.strftime('%I:%M %p IST')}")
                await webhook.send(embed=embed)
            except Exception as e:
                logger.error(f"Error sending command completion webhook: {e}")
                traceback.print_exc()

# Removed duplicate error handler - using centralized error handling in Errors.py

# Load environment variables from the .env file
TOKEN = os.getenv("TOKEN")
WEBHOOK_URL = os.getenv("WEBHOOK_URL")
PREFIX = os.getenv("PREFIX")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if TOKEN is None:
    logger.error("TOKEN environment variable not set in .env file. Please ensure your .env file contains the TOKEN.")
    raise ValueError("TOKEN environment variable not set in .env file. Cannot start the bot.")

if WEBHOOK_URL is None:
    logger.error("WEBHOOK_URL environment variable not set in .env file. Please ensure your .env file contains the WEBHOOK_URL.")
    raise ValueError("WEBHOOK_URL environment variable not set in .env file.")

if PREFIX is None:
    logger.error("PREFIX environment variable not set in .env file. Please ensure your .env file contains the PREFIX.")
    raise ValueError("PREFIX environment variable not set in .env file.")

if __name__ == '__main__':
    try:
        print_loading("Establishing connection to Discord")
        client.run(TOKEN)
    except discord.LoginFailure:
        print_error("Authentication failed - Invalid token configuration")
    except Exception as e:
        print_error(f"Startup failed: {e}")
"""
@Author: ! Aegis !
    + Discord: Aegis
    + Community: https://discord.gg/35FqchfVZG (Strelix Studios™)
    + for any queries reach out Community or DM me.
"""
