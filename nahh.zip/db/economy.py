import aiosqlite
import asyncio
from typing import Optional

class EconomyDatabase:
    def __init__(self, db_path='db/economy.db'):
        self.db_path = db_path
        self.db = None

    async def connect(self):
        self.db = await aiosqlite.connect(self.db_path)
        await self.init_tables()

    async def init_tables(self):
        # Create users table with all columns
        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                cowoncy INTEGER DEFAULT 0,
                cookies INTEGER DEFAULT 0,
                luck_points INTEGER DEFAULT 0,
                last_pray TEXT,
                last_curse TEXT,
                zoo_data TEXT,
                last_hunt TEXT,
                gem_data TEXT,
                team_data TEXT,
                last_work TEXT,
                last_beg TEXT,
                last_trivia TEXT,
                last_daily TEXT,
                daily_streak INTEGER DEFAULT 0,
                bank_balance INTEGER DEFAULT 0,
                last_interest TEXT
            )
        ''')

        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS inventory (
                user_id INTEGER,
                item_id INTEGER,
                item_name TEXT,
                PRIMARY KEY (user_id, item_id)
            )
        ''')

        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS marriages (
                user1_id INTEGER,
                user2_id INTEGER,
                ring_id INTEGER,
                married_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user1_id, user2_id)
            )
        ''')

        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS economy_prefixes (
                guild_id INTEGER PRIMARY KEY,
                prefix TEXT NOT NULL
            )
        ''')

        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS stock_prices (
                symbol TEXT PRIMARY KEY,
                current_price REAL NOT NULL,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS stock_history (
                symbol TEXT,
                price REAL,
                date TEXT,
                PRIMARY KEY (symbol, date)
            )
        ''')

        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS tax_data (
                id INTEGER PRIMARY KEY,
                total_tax INTEGER DEFAULT 0
            )
        ''')

        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS crypto_prices (
                symbol TEXT PRIMARY KEY,
                current_price REAL NOT NULL,
                last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        await self.db.execute('''
            CREATE TABLE IF NOT EXISTS loans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                lender_id INTEGER,
                borrower_id INTEGER,
                amount INTEGER,
                repayment_amount INTEGER,
                due_date TEXT,
                active INTEGER DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Ensure all columns exist - get current table structure first
        cursor = await self.db.execute("PRAGMA table_info(users)")
        existing_columns = [row[1] for row in await cursor.fetchall()]

        # Add missing columns if they don't exist
        columns_to_add = [
            ('luck_points', 'INTEGER DEFAULT 0'),
            ('last_pray', 'TEXT'),
            ('last_curse', 'TEXT'),
            ('zoo_data', 'TEXT'),
            ('last_hunt', 'TEXT'),
            ('team_data', 'TEXT'),
            ('gem_data', 'TEXT'),
            ('last_work', 'TEXT'),
            ('last_beg', 'TEXT'),
            ('last_trivia', 'TEXT'),
            ('last_daily', 'TEXT'),
            ('daily_streak', 'INTEGER DEFAULT 0'),
            ('bank_balance', 'INTEGER DEFAULT 0'),
            ('last_interest', 'TEXT'),
            ('current_job', 'TEXT'),
            ('job_stats', 'TEXT'),
            ('last_job_work', 'TEXT'),
            ('last_study', 'TEXT'),
            ('portfolio', 'TEXT'),
            ('watchlist', 'TEXT'),
            ('properties', 'TEXT'),
            ('last_rent_collection', 'TEXT'),
            ('crypto_portfolio', 'TEXT'),
            ('businesses', 'TEXT'),
            ('last_business_collection', 'TEXT'),
            ('achievements', 'TEXT'),
            ('bonds', 'TEXT'),
            ('insurance', 'TEXT'),
            ('last_tax_collection', 'TEXT')
        ]

        for column, column_type in columns_to_add:
            if column not in existing_columns:
                try:
                    await self.db.execute(f'ALTER TABLE users ADD COLUMN {column} {column_type}')
                    print(f"Added missing column: {column}")
                except Exception as e:
                    print(f"Failed to add column {column}: {e}")

        await self.db.commit()

    async def get_user_balance(self, user_id: int) -> int:
        try:
            # Ensure user exists first
            await self.db.execute('''
                INSERT OR IGNORE INTO users (user_id, cowoncy, bank_balance, luck_points, cookies, daily_streak) 
                VALUES (?, 0, 0, 0, 0, 0)
            ''', (user_id,))
            await self.db.commit()
            
            cursor = await self.db.execute('SELECT cowoncy FROM users WHERE user_id = ?', (user_id,))
            result = await cursor.fetchone()
            return result[0] if result and result[0] is not None else 0
        except Exception as e:
            print(f"Error getting user balance for {user_id}: {e}")
            return 0

    async def update_user_balance(self, user_id: int, amount: int):
        try:
            # Ensure amount is valid
            if amount < 0:
                amount = 0
            
            # First ensure user exists with all required fields
            await self.db.execute('''
                INSERT OR IGNORE INTO users (user_id, cowoncy, bank_balance, luck_points, cookies, daily_streak) 
                VALUES (?, 0, 0, 0, 0, 0)
            ''', (user_id,))
            
            # Update balance with safety check
            await self.db.execute('''
                UPDATE users SET cowoncy = ? WHERE user_id = ?
            ''', (int(amount), user_id))
            await self.db.commit()
        except Exception as e:
            print(f"Error updating user balance for {user_id}: {e}")

    async def get_user_inventory(self, user_id: int) -> list:
        cursor = await self.db.execute('SELECT item_id FROM inventory WHERE user_id = ?', (user_id,))
        results = await cursor.fetchall()
        return [row[0] for row in results]

    async def get_user_gems(self, user_id: int) -> dict:
        try:
            cursor = await self.db.execute('SELECT gem_data FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            if row and row[0]:
                import json
                return json.loads(row[0])
            return {}
        except Exception as e:
            print(f"Error getting user gems: {e}")
            return {}

    async def update_user_gems(self, user_id: int, gem_data: dict):
        try:
            import json
            gem_json = json.dumps(gem_data)
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, gem_data) 
                VALUES (?, ?)
            ''', (user_id, gem_json))
            await self.db.commit()
        except Exception as e:
            print(f"Error updating user gems: {e}")

    async def add_to_inventory(self, user_id: int, item_id: int, item_name: str):
        await self.db.execute('''
            INSERT OR REPLACE INTO inventory (user_id, item_id, item_name) VALUES (?, ?, ?)
        ''', (user_id, item_id, item_name))
        await self.db.commit()

    async def remove_from_inventory(self, user_id: int, item_id: int):
        await self.db.execute('DELETE FROM inventory WHERE user_id = ? AND item_id = ?', (user_id, item_id))
        await self.db.commit()

    async def get_marriage_status(self, user_id: int) -> Optional[tuple]:
        cursor = await self.db.execute('''
            SELECT user1_id, user2_id, ring_id FROM marriages 
            WHERE user1_id = ? OR user2_id = ?
        ''', (user_id, user_id))
        result = await cursor.fetchone()
        return result

    async def create_marriage(self, user1_id: int, user2_id: int, ring_id: int):
        await self.db.execute('''
            INSERT INTO marriages (user1_id, user2_id, ring_id) VALUES (?, ?, ?)
        ''', (user1_id, user2_id, ring_id))
        await self.db.commit()

    async def set_economy_prefix(self, guild_id: int, prefix: str):
        await self.db.execute('''
            INSERT OR REPLACE INTO economy_prefixes (guild_id, prefix) VALUES (?, ?)
        ''', (guild_id, prefix))
        await self.db.commit()

    async def get_economy_prefix(self, guild_id: int) -> Optional[str]:
        cursor = await self.db.execute('SELECT prefix FROM economy_prefixes WHERE guild_id = ?', (guild_id,))
        result = await cursor.fetchone()
        return result[0] if result else None

    async def get_all_economy_prefixes(self) -> list:
        try:
            cursor = await self.db.execute('SELECT guild_id, prefix FROM economy_prefixes')
            rows = await cursor.fetchall()
            return [(row[0], row[1]) for row in rows]
        except Exception as e:
            print(f"Error getting economy prefixes: {e}")
            return []

    async def get_user_luck(self, user_id: int) -> int:
        cursor = await self.db.execute('SELECT luck_points FROM users WHERE user_id = ?', (user_id,))
        result = await cursor.fetchone()
        if result and result[0] is not None:
            return result[0]
        else:
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, luck_points) VALUES (?, ?)
            ''', (user_id, 0))
            await self.db.commit()
            return 0

    async def update_user_luck(self, user_id: int, luck_points: int):
        await self.db.execute('''
            INSERT OR REPLACE INTO users (user_id, luck_points) VALUES (?, ?)
        ''', (user_id, luck_points))
        await self.db.commit()

    async def get_last_pray_time(self, user_id: int) -> Optional[str]:
        cursor = await self.db.execute('SELECT last_pray FROM users WHERE user_id = ?', (user_id,))
        result = await cursor.fetchone()
        return result[0] if result else None

    async def set_last_pray_time(self, user_id: int, timestamp: str):
        await self.db.execute('''
            INSERT OR REPLACE INTO users (user_id, last_pray) VALUES (?, ?)
        ''', (user_id, timestamp))
        await self.db.commit()

    async def get_last_curse_time(self, user_id: int) -> Optional[str]:
        cursor = await self.db.execute('SELECT last_curse FROM users WHERE user_id = ?', (user_id,))
        result = await cursor.fetchone()
        return result[0] if result else None

    async def set_last_curse_time(self, user_id: int, timestamp: str):
        await self.db.execute('''
            INSERT OR REPLACE INTO users (user_id, last_curse) VALUES (?, ?)
        ''', (user_id, timestamp))
        await self.db.commit()

    async def get_user_cookies(self, user_id: int) -> int:
        cursor = await self.db.execute('SELECT cookies FROM users WHERE user_id = ?', (user_id,))
        result = await cursor.fetchone()
        if result and result[0] is not None:
            return result[0]
        else:
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, cookies) VALUES (?, ?)
            ''', (user_id, 0))
            await self.db.commit()
            return 0

    async def update_user_cookies(self, user_id: int, cookies: int):
        await self.db.execute('''
            INSERT OR REPLACE INTO users (user_id, cookies) VALUES (?, ?)
        ''', (user_id, cookies))
        await self.db.commit()

    async def get_user_zoo(self, user_id):
        try:
            cursor = await self.db.execute('SELECT zoo_data FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            if row and row[0]:
                import json
                return json.loads(row[0])
            return None
        except Exception as e:
            print(f"Error getting user zoo: {e}")
            return None

    async def update_user_zoo(self, user_id, zoo_data):
        try:
            import json
            zoo_json = json.dumps(zoo_data)
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, zoo_data) VALUES (?, ?)
            ''', (user_id, zoo_json))
            await self.db.commit()
        except Exception as e:
            print(f"Error updating user zoo: {e}")

    async def get_last_hunt_time(self, user_id):
        try:
            cursor = await self.db.execute('SELECT last_hunt FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            return row[0] if row else None
        except Exception as e:
            print(f"Error getting last hunt time: {e}")
            return None

    async def set_last_hunt_time(self, user_id, hunt_time):
        try:
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, last_hunt) VALUES (?, ?)
            ''', (user_id, hunt_time))
            await self.db.commit()
        except Exception as e:
            print(f"Error setting hunt time: {e}")

    async def get_user_team(self, user_id):
        try:
            cursor = await self.db.execute('SELECT team_data FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            if row and row[0]:
                import json
                return json.loads(row[0])
            return []
        except Exception as e:
            print(f"Error getting user team: {e}")
            return []

    async def update_user_team(self, user_id, team_data):
        try:
            import json
            team_json = json.dumps(team_data)
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, team_data) VALUES (?, ?)
            ''', (user_id, team_json))
            await self.db.commit()
        except Exception as e:
            print(f"Error updating user team: {e}")

    async def get_last_work_time(self, user_id):
        try:
            cursor = await self.db.execute('SELECT last_work FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            return row[0] if row else None
        except Exception as e:
            print(f"Error getting last work time: {e}")
            return None

    async def set_last_work_time(self, user_id, work_time):
        try:
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, last_work) VALUES (?, ?)
            ''', (user_id, work_time))
            await self.db.commit()
        except Exception as e:
            print(f"Error setting work time: {e}")

    async def get_last_beg_time(self, user_id):
        try:
            cursor = await self.db.execute('SELECT last_beg FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            return row[0] if row else None
        except Exception as e:
            print(f"Error getting last beg time: {e}")
            return None

    async def set_last_beg_time(self, user_id, beg_time):
        try:
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, last_beg) VALUES (?, ?)
            ''', (user_id, beg_time))
            await self.db.commit()
        except Exception as e:
            print(f"Error setting beg time: {e}")

    async def get_last_trivia_time(self, user_id):
        try:
            cursor = await self.db.execute('SELECT last_trivia FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            return row[0] if row else None
        except Exception as e:
            print(f"Error getting last trivia time: {e}")
            return None

    async def set_last_trivia_time(self, user_id, trivia_time):
        try:
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, last_trivia) VALUES (?, ?)
            ''', (user_id, trivia_time))
            await self.db.commit()
        except Exception as e:
            print(f"Error setting trivia time: {e}")

    async def get_last_daily_time(self, user_id):
        try:
            # Ensure user exists first
            await self.db.execute('''
                INSERT OR IGNORE INTO users (user_id, cowoncy, last_daily) VALUES (?, 0, NULL)
            ''', (user_id,))

            cursor = await self.db.execute('SELECT last_daily FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            return row[0] if row and row[0] else None
        except Exception as e:
            print(f"Error getting last daily time for user {user_id}: {e}")
            return None

    async def set_last_daily_time(self, user_id, daily_time):
        try:
            # Ensure user exists first
            await self.db.execute('''
                INSERT OR IGNORE INTO users (user_id, cowoncy) VALUES (?, 0)
            ''', (user_id,))

            # Update the daily time
            await self.db.execute('''
                UPDATE users SET last_daily = ? WHERE user_id = ?
            ''', (daily_time, user_id))
            await self.db.commit()
        except Exception as e:
            print(f"Error setting daily time for user {user_id}: {e}")

    async def get_daily_streak(self, user_id):
        try:
            cursor = await self.db.execute('SELECT daily_streak FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            return row[0] if row and row[0] is not None else 0
        except Exception as e:
            print(f"Error getting daily streak: {e}")
            return 0

    async def update_daily_streak(self, user_id, streak):
        try:
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, daily_streak) VALUES (?, ?)
            ''', (user_id, streak))
            await self.db.commit()
        except Exception as e:
            print(f"Error updating daily streak: {e}")

    async def get_bank_balance(self, user_id):
        try:
            # Ensure user exists first
            await self.db.execute('''
                INSERT OR IGNORE INTO users (user_id, cowoncy, bank_balance, luck_points, cookies, daily_streak) 
                VALUES (?, 0, 0, 0, 0, 0)
            ''', (user_id,))
            await self.db.commit()
            
            cursor = await self.db.execute('SELECT bank_balance FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            return row[0] if row and row[0] is not None else 0
        except Exception as e:
            print(f"Error getting bank balance: {e}")
            return 0

    async def update_bank_balance(self, user_id, balance):
        try:
            # Ensure balance is valid
            if balance < 0:
                balance = 0
                
            # First ensure user exists with all required fields
            await self.db.execute('''
                INSERT OR IGNORE INTO users (user_id, cowoncy, bank_balance, luck_points, cookies, daily_streak) 
                VALUES (?, 0, 0, 0, 0, 0)
            ''', (user_id,))
            
            # Update bank balance safely
            await self.db.execute('''
                UPDATE users SET bank_balance = ? WHERE user_id = ?
            ''', (int(balance), user_id))
            await self.db.commit()
        except Exception as e:
            print(f"Error updating bank balance: {e}")

    async def get_user_team(self, user_id):
        try:
            cursor = await self.db.execute('SELECT team_data FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            if row and row[0]:
                import json
                return json.loads(row[0])
            return []
        except Exception as e:
            print(f"Error getting user team: {e}")
            return []

    async def update_user_team(self, user_id, team_data):
        try:
            import json
            team_json = json.dumps(team_data)
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, team_data) VALUES (?, ?)
            ''', (user_id, team_json))
            await self.db.commit()
        except Exception as e:
            print(f"Error updating user team: {e}")

    # Job system methods
    async def get_user_job(self, user_id):
        try:
            cursor = await self.db.execute('SELECT current_job FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            return row[0] if row and row[0] else None
        except Exception as e:
            print(f"Error getting user job: {e}")
            return None

    async def set_user_job(self, user_id, job_type):
        try:
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, current_job) VALUES (?, ?)
            ''', (user_id, job_type))
            await self.db.commit()
        except Exception as e:
            print(f"Error setting user job: {e}")

    async def get_user_job_stats(self, user_id):
        try:
            cursor = await self.db.execute('SELECT job_stats FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            if row and row[0]:
                import json
                return json.loads(row[0])
            return {'experience': 0, 'education': 0, 'times_worked': 0}
        except Exception as e:
            print(f"Error getting user job stats: {e}")
            return {'experience': 0, 'education': 0, 'times_worked': 0}

    async def update_user_job_stats(self, user_id, experience=None, education=None, times_worked=None):
        try:
            current_stats = await self.get_user_job_stats(user_id)

            if experience is not None:
                current_stats['experience'] = experience
            if education is not None:
                current_stats['education'] = education
            if times_worked is not None:
                current_stats['times_worked'] = times_worked

            import json
            stats_json = json.dumps(current_stats)
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, job_stats) VALUES (?, ?)
            ''', (user_id, stats_json))
            await self.db.commit()
        except Exception as e:
            print(f"Error updating user job stats: {e}")

    async def get_last_job_work_time(self, user_id):
        try:
            cursor = await self.db.execute('SELECT last_job_work FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            return row[0] if row else None
        except Exception as e:
            print(f"Error getting last job work time: {e}")
            return None

    async def set_last_job_work_time(self, user_id, work_time):
        try:
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, last_job_work) VALUES (?, ?)
            ''', (user_id, work_time))
            await self.db.commit()
        except Exception as e:
            print(f"Error setting job work time: {e}")

    async def get_last_study_time(self, user_id):
        try:
            cursor = await self.db.execute('SELECT last_study FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            return row[0] if row else None
        except Exception as e:
            print(f"Error getting last study time: {e}")
            return None

    async def set_last_study_time(self, user_id, study_time):
        try:
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, last_study) VALUES (?, ?)
            ''', (user_id, study_time))
            await self.db.commit()
        except Exception as e:
            print(f"Error setting study time: {e}")

    # Stock market methods
    async def get_stock_price(self, symbol):
        try:
            cursor = await self.db.execute('SELECT current_price FROM stock_prices WHERE symbol = ?', (symbol,))
            row = await cursor.fetchone()
            return row[0] if row else None
        except Exception as e:
            print(f"Error getting stock price: {e}")
            return None

    async def set_stock_price(self, symbol, price):
        try:
            await self.db.execute('''
                INSERT OR REPLACE INTO stock_prices (symbol, current_price, last_updated) 
                VALUES (?, ?, CURRENT_TIMESTAMP)
            ''', (symbol, price))
            await self.db.commit()
        except Exception as e:
            print(f"Error setting stock price: {e}")

    async def get_user_portfolio(self, user_id):
        try:
            cursor = await self.db.execute('SELECT portfolio FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            if row and row[0]:
                import json
                return json.loads(row[0])
            return {}
        except Exception as e:
            print(f"Error getting user portfolio: {e}")
            return {}

    async def update_user_portfolio(self, user_id, symbol, shares_change):
        try:
            portfolio = await self.get_user_portfolio(user_id)
            current_shares = portfolio.get(symbol, 0)
            new_shares = current_shares + shares_change

            if new_shares <= 0:
                portfolio.pop(symbol, None)
            else:
                portfolio[symbol] = new_shares

            import json
            portfolio_json = json.dumps(portfolio)
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, portfolio) VALUES (?, ?)
            ''', (user_id, portfolio_json))
            await self.db.commit()
        except Exception as e:
            print(f"Error updating user portfolio: {e}")

    async def add_stock_price_history(self, symbol, price):
        try:
            from datetime import datetime
            date_str = datetime.now().strftime('%Y-%m-%d')
            await self.db.execute('''
                INSERT OR REPLACE INTO stock_history (symbol, price, date) VALUES (?, ?, ?)
            ''', (symbol, price, date_str))
            await self.db.commit()
        except Exception as e:
            print(f"Error adding stock price history: {e}")

    async def get_stock_price_history(self, symbol, days):
        try:
            cursor = await self.db.execute('''
                SELECT price FROM stock_history 
                WHERE symbol = ? 
                ORDER BY date DESC 
                LIMIT ?
            ''', (symbol, days))
            rows = await cursor.fetchall()
            return [row[0] for row in rows]
        except Exception as e:
            print(f"Error getting stock price history: {e}")
            return []

    async def get_user_watchlist(self, user_id):
        try:
            cursor = await self.db.execute('SELECT watchlist FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            if row and row[0]:
                import json
                return json.loads(row[0])
            return []
        except Exception as e:
            print(f"Error getting user watchlist: {e}")
            return []

    async def add_to_watchlist(self, user_id, symbol):
        try:
            watchlist = await self.get_user_watchlist(user_id)
            if symbol not in watchlist:
                watchlist.append(symbol)
                import json
                watchlist_json = json.dumps(watchlist)
                await self.db.execute('''
                    INSERT OR REPLACE INTO users (user_id, watchlist) VALUES (?, ?)
                ''', (user_id, watchlist_json))
                await self.db.commit()
        except Exception as e:
            print(f"Error adding to watchlist: {e}")

    async def remove_from_watchlist(self, user_id, symbol):
        try:
            watchlist = await self.get_user_watchlist(user_id)
            if symbol in watchlist:
                watchlist.remove(symbol)
                import json
                watchlist_json = json.dumps(watchlist)
                await self.db.execute('''
                    INSERT OR REPLACE INTO users (user_id, watchlist) VALUES (?, ?)
                ''', (user_id, watchlist_json))
                await self.db.commit()
        except Exception as e:
            print(f"Error removing from watchlist: {e}")

    # Tax system methods
    async def get_total_tax_collected(self):
        try:
            # Ensure tax_data table exists and has a record
            await self.db.execute('''
                INSERT OR IGNORE INTO tax_data (id, total_tax) VALUES (1, 0)
            ''')
            await self.db.commit()

            cursor = await self.db.execute('SELECT total_tax FROM tax_data WHERE id = 1')
            row = await cursor.fetchone()
            return row[0] if row else 0
        except Exception as e:
            print(f"Error getting total tax: {e}")
            return 0

    async def add_to_total_tax_collected(self, amount):
        try:
            current_total = await self.get_total_tax_collected()
            new_total = current_total + amount
            await self.db.execute('''
                INSERT OR REPLACE INTO tax_data (id, total_tax) VALUES (1, ?)
            ''', (new_total,))
            await self.db.commit()
        except Exception as e:
            print(f"Error updating total tax: {e}")

    # Property system methods
    async def get_user_properties(self, user_id):
        try:
            cursor = await self.db.execute('SELECT properties FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            if row and row[0]:
                import json
                return json.loads(row[0])
            return []
        except Exception as e:
            print(f"Error getting user properties: {e}")
            return []

    async def add_user_property(self, user_id, property_id):
        try:
            properties = await self.get_user_properties(user_id)
            if property_id not in properties:
                properties.append(property_id)
                import json
                properties_json = json.dumps(properties)
                await self.db.execute('''
                    INSERT OR REPLACE INTO users (user_id, properties) VALUES (?, ?)
                ''', (user_id, properties_json))
                await self.db.commit()
        except Exception as e:
            print(f"Error adding user property: {e}")

    async def remove_user_property(self, user_id, property_id):
        try:
            properties = await self.get_user_properties(user_id)
            if property_id in properties:
                properties.remove(property_id)
                import json
                properties_json = json.dumps(properties)
                await self.db.execute('''
                    INSERT OR REPLACE INTO users (user_id, properties) VALUES (?, ?)
                ''', (user_id, properties_json))
                await self.db.commit()
        except Exception as e:
            print(f"Error removing user property: {e}")

    async def get_last_rent_collection(self, user_id):
        try:
            cursor = await self.db.execute('SELECT last_rent_collection FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            return row[0] if row else None
        except Exception as e:
            print(f"Error getting last rent collection: {e}")
            return None

    async def set_last_rent_collection(self, user_id, timestamp):
        try:
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, last_rent_collection) VALUES (?, ?)
            ''', (user_id, timestamp))
            await self.db.commit()
        except Exception as e:
            print(f"Error setting rent collection time: {e}")

    # Crypto methods
    async def get_crypto_price(self, symbol):
        try:
            cursor = await self.db.execute('SELECT current_price FROM crypto_prices WHERE symbol = ?', (symbol,))
            row = await cursor.fetchone()
            return row[0] if row else None
        except Exception as e:
            print(f"Error getting crypto price: {e}")
            return None

    async def set_crypto_price(self, symbol, price):
        try:
            await self.db.execute('''
                INSERT OR REPLACE INTO crypto_prices (symbol, current_price) VALUES (?, ?)
            ''', (symbol, price))
            await self.db.commit()
        except Exception as e:
            print(f"Error setting crypto price: {e}")

    async def get_user_crypto_portfolio(self, user_id):
        try:
            cursor = await self.db.execute('SELECT crypto_portfolio FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            if row and row[0]:
                import json
                return json.loads(row[0])
            return {}
        except Exception as e:
            print(f"Error getting crypto portfolio: {e}")
            return {}

    async def update_user_crypto_portfolio(self, user_id, symbol, amount_change):
        try:
            portfolio = await self.get_user_crypto_portfolio(user_id)
            current_amount = portfolio.get(symbol, 0)
            new_amount = current_amount + amount_change

            if new_amount <= 0:
                portfolio.pop(symbol, None)
            else:
                portfolio[symbol] = new_amount

            import json
            portfolio_json = json.dumps(portfolio)
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, crypto_portfolio) VALUES (?, ?)
            ''', (user_id, portfolio_json))
            await self.db.commit()
        except Exception as e:
            print(f"Error updating crypto portfolio: {e}")

    # Business methods
    async def get_user_businesses(self, user_id):
        try:
            cursor = await self.db.execute('SELECT businesses FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            if row and row[0]:
                import json
                return json.loads(row[0])
            return {}
        except Exception as e:
            print(f"Error getting user businesses: {e}")
            return {}

    async def add_user_business(self, user_id, business_type, level):
        try:
            businesses = await self.get_user_businesses(user_id)
            businesses[business_type] = level
            import json
            businesses_json = json.dumps(businesses)
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, businesses) VALUES (?, ?)
            ''', (user_id, businesses_json))
            await self.db.commit()
        except Exception as e:
            print(f"Error adding user business: {e}")

    async def get_last_business_collection(self, user_id):
        try:
            cursor = await self.db.execute('SELECT last_business_collection FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            return row[0] if row else None
        except Exception as e:
            print(f"Error getting last business collection: {e}")
            return None

    async def set_last_business_collection(self, user_id, timestamp):
        try:
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, last_business_collection) VALUES (?, ?)
            ''', (user_id, timestamp))
            await self.db.commit()
        except Exception as e:
            print(f"Error setting business collection time: {e}")

    # Achievement methods
    async def get_user_achievements(self, user_id):
        try:
            cursor = await self.db.execute('SELECT achievements FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            if row and row[0]:
                import json
                return json.loads(row[0])
            return []
        except Exception as e:
            print(f"Error getting user achievements: {e}")
            return []

    # Bonds methods
    async def get_user_bonds(self, user_id):
        try:
            cursor = await self.db.execute('SELECT bonds FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            if row and row[0]:
                import json
                return json.loads(row[0])
            return []
        except Exception as e:
            print(f"Error getting user bonds: {e}")
            return []

    async def add_user_bond(self, user_id, amount, mature_date):
        try:
            bonds = await self.get_user_bonds(user_id)
            bond_id = len(bonds) + 1
            bonds.append({
                'id': bond_id,
                'amount': amount,
                'mature_date': mature_date
            })
            import json
            bonds_json = json.dumps(bonds)
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, bonds) VALUES (?, ?)
            ''', (user_id, bonds_json))
            await self.db.commit()
        except Exception as e:
            print(f"Error adding user bond: {e}")

    async def redeem_user_bonds(self, user_id, bond_ids):
        try:
            bonds = await self.get_user_bonds(user_id)
            bonds = [bond for bond in bonds if bond['id'] not in bond_ids]
            import json
            bonds_json = json.dumps(bonds)
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, bonds) VALUES (?, ?)
            ''', (user_id, bonds_json))
            await self.db.commit()
        except Exception as e:
            print(f"Error redeeming user bonds: {e}")

    # Insurance methods
    async def get_user_insurance(self, user_id):
        try:
            cursor = await self.db.execute('SELECT insurance FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            if row and row[0]:
                import json
                return json.loads(row[0])
            return None
        except Exception as e:
            print(f"Error getting user insurance: {e}")
            return None

    # Loan methods
    async def get_user_loan(self, lender_id, borrower_id):
        try:
            cursor = await self.db.execute('SELECT * FROM loans WHERE lender_id = ? AND borrower_id = ? AND active = 1', (lender_id, borrower_id))
            row = await cursor.fetchone()
            return row if row else None
        except Exception as e:
            print(f"Error getting user loan: {e}")
            return None

    async def create_loan(self, lender_id, borrower_id, amount, repayment_amount, due_date):
        try:
            await self.db.execute('''
                INSERT INTO loans (lender_id, borrower_id, amount, repayment_amount, due_date, active) 
                VALUES (?, ?, ?, ?, ?, 1)
            ''', (lender_id, borrower_id, amount, repayment_amount, due_date))
            await self.db.commit()
        except Exception as e:
            print(f"Error creating loan: {e}")

    # Autotax methods
    async def get_last_tax_collection_time(self, user_id):
        try:
            cursor = await self.db.execute('SELECT last_tax_collection FROM users WHERE user_id = ?', (user_id,))
            row = await cursor.fetchone()
            return row[0] if row else None
        except Exception as e:
            print(f"Error getting last tax collection time: {e}")
            return None

    async def set_last_tax_collection_time(self, user_id, timestamp):
        try:
            await self.db.execute('''
                INSERT OR REPLACE INTO users (user_id, last_tax_collection) VALUES (?, ?)
            ''', (user_id, timestamp))
            await self.db.commit()
        except Exception as e:
            print(f"Error setting tax collection time: {e}")

    async def get_all_users_for_tax(self):
        try:
            cursor = await self.db.execute('SELECT user_id, cowoncy, bank_balance FROM users WHERE cowoncy > 0 OR bank_balance > 0')
            rows = await cursor.fetchall()
            return [(row[0], row[1] or 0, row[2] or 0) for row in rows]
        except Exception as e:
            print(f"Error getting users for tax: {e}")
            return []

    # Crypto history methods
    async def add_crypto_price_history(self, symbol, price):
        try:
            from datetime import datetime
            date_str = datetime.now().strftime('%Y-%m-%d %H:%M')
            await self.db.execute('''
                CREATE TABLE IF NOT EXISTS crypto_history (
                    symbol TEXT,
                    price REAL,
                    timestamp TEXT,
                    PRIMARY KEY (symbol, timestamp)
                )
            ''')
            await self.db.execute('''
                INSERT OR REPLACE INTO crypto_history (symbol, price, timestamp) VALUES (?, ?, ?)
            ''', (symbol, price, date_str))
            await self.db.commit()
        except Exception as e:
            print(f"Error adding crypto price history: {e}")

    async def get_crypto_price_history(self, symbol, hours=24):
        try:
            cursor = await self.db.execute('''
                SELECT price, timestamp FROM crypto_history 
                WHERE symbol = ? 
                ORDER BY timestamp DESC 
                LIMIT ?
            ''', (symbol, hours))
            rows = await cursor.fetchall()
            return [(row[0], row[1]) for row in rows]
        except Exception as e:
            print(f"Error getting crypto price history: {e}")
            return []

    async def close(self):
        if self.db:
            await self.db.close()
"""
@Author: ! Aegis !
    + Discord: Aegis
    + Community: https://discord.gg/35FqchfVZG (Strelix Studios™)
    + for any queries reach out Community or DM me.
"""
